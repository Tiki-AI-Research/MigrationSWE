from __future__ import annotations

import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from ._git import run_git
from .repository import commit_exists, is_git_repository


@dataclass(frozen=True)
class ChangedFile:
    status: str
    path: str
    old_path: str | None = None


def _pathspecs(exclude_paths: Iterable[str]) -> list[str]:
    return [".", *[f":(exclude){path}" for path in exclude_paths]]


def _parse_name_status_z(data: bytes) -> tuple[ChangedFile, ...]:
    fields = data.split(b"\0")
    if fields and fields[-1] == b"":
        fields.pop()
    result: list[ChangedFile] = []
    index = 0
    while index < len(fields):
        status = fields[index].decode("ascii", errors="replace")
        index += 1
        if status.startswith(("R", "C")):
            if index + 1 >= len(fields):
                raise ValueError("malformed rename/copy name-status output")
            old_path = fields[index].decode("utf-8", errors="surrogateescape")
            new_path = fields[index + 1].decode("utf-8", errors="surrogateescape")
            index += 2
            result.append(ChangedFile(status=status, path=new_path, old_path=old_path))
        else:
            if index >= len(fields):
                raise ValueError("malformed name-status output")
            path = fields[index].decode("utf-8", errors="surrogateescape")
            index += 1
            result.append(ChangedFile(status=status, path=path))
    return tuple(result)


def _snapshot_diff(
    repo: Path,
    base_commit: str,
    *,
    exclude_paths: Iterable[str],
    timeout_sec: int,
) -> tuple[bytes, tuple[ChangedFile, ...]]:
    repo = Path(repo).resolve()
    if not is_git_repository(repo):
        raise ValueError("not a Git worktree")
    if not commit_exists(repo, base_commit):
        raise ValueError("base commit does not exist")
    pathspecs = _pathspecs(exclude_paths)
    with tempfile.TemporaryDirectory(prefix="harbor-patch-index-") as directory:
        env = {"GIT_INDEX_FILE": str(Path(directory) / "index")}
        for args in (["read-tree", base_commit], ["add", "-A", "--", "."]):
            result = run_git(repo, args, env=env, timeout_sec=timeout_sec)
            if not result.succeeded:
                raise RuntimeError(
                    f"git {' '.join(args)} failed: "
                    f"{result.stderr.decode('utf-8', errors='replace').strip()}"
                )
        names = run_git(
            repo,
            [
                "diff",
                "--cached",
                "--name-status",
                "--find-renames",
                "-z",
                base_commit,
                "--",
                *pathspecs,
            ],
            env=env,
            timeout_sec=timeout_sec,
        )
        diff = run_git(
            repo,
            [
                "diff",
                "--cached",
                "--binary",
                "--full-index",
                "--find-renames",
                "--no-ext-diff",
                base_commit,
                "--",
                *pathspecs,
            ],
            env=env,
            timeout_sec=timeout_sec,
        )
        if not names.succeeded or not diff.succeeded:
            raise RuntimeError("git diff failed")
        return diff.stdout, _parse_name_status_z(names.stdout)


def export_patch(
    repo: Path,
    base_commit: str,
    output_path: Path,
    *,
    exclude_paths: Iterable[str] = (),
    timeout_sec: int = 60,
) -> Path:
    """Export the final worktree state relative to ``base_commit``.

    The real Git index is never changed. An empty worktree produces an empty
    patch file, which lets the caller apply its own empty-patch policy.
    """

    output_path = Path(output_path).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.unlink(missing_ok=True)
    patch_bytes, _changed_files = _snapshot_diff(
        repo,
        base_commit,
        exclude_paths=exclude_paths,
        timeout_sec=timeout_sec,
    )
    output_path.write_bytes(patch_bytes)
    return output_path


def get_changed_files(
    repo: Path,
    base_commit: str,
    *,
    exclude_paths: Iterable[str] = (),
    timeout_sec: int = 60,
) -> tuple[ChangedFile, ...]:
    """Return changed files from the same temporary-index snapshot as export."""

    _patch_bytes, changed_files = _snapshot_diff(
        repo,
        base_commit,
        exclude_paths=exclude_paths,
        timeout_sec=timeout_sec,
    )
    return changed_files
