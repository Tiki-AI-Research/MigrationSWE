"""Deterministic helpers for Harbor migration task evaluation."""

from .evaluation_patch import build_evaluation_test_patch
from .patch_apply import PatchCheckResult, apply_patch, check_patch_applicable, patch_applies
from .patch_export import ChangedFile, export_patch, get_changed_files
from .patch_input import patch_is_empty, patch_sha256, read_patch
from .protected_paths import (
    ProtectedPathsCheckResult,
    ProtectedPathViolation,
    check_protected_paths,
    protected_paths_unchanged,
)
from .repository import commit_exists, is_git_repository, resolve_commit, tree_hash

__all__ = [
    "ChangedFile",
    "PatchCheckResult",
    "ProtectedPathViolation",
    "ProtectedPathsCheckResult",
    "apply_patch",
    "build_evaluation_test_patch",
    "check_patch_applicable",
    "check_protected_paths",
    "commit_exists",
    "export_patch",
    "get_changed_files",
    "is_git_repository",
    "patch_applies",
    "patch_is_empty",
    "patch_sha256",
    "protected_paths_unchanged",
    "read_patch",
    "resolve_commit",
    "tree_hash",
]
