from __future__ import annotations

import re
from pathlib import Path

from ._git import run_git


_COMMIT_RE = re.compile(r"^[0-9a-fA-F]{4,64}$")


def is_git_repository(repo: Path) -> bool:
    result = run_git(repo, ["rev-parse", "--is-inside-work-tree"], timeout_sec=30)
    return result.succeeded and result.stdout.strip() == b"true"


def _valid_commit_argument(commit: str) -> bool:
    return bool(commit and _COMMIT_RE.fullmatch(commit))


def resolve_commit(repo: Path, commit: str) -> str | None:
    if not is_git_repository(repo) or not _valid_commit_argument(commit):
        return None
    result = run_git(repo, ["rev-parse", "--verify", "--quiet", f"{commit}^{{commit}}"])
    if not result.succeeded:
        return None
    return result.stdout.decode("ascii", errors="strict").strip()


def commit_exists(repo: Path, commit: str) -> bool:
    return resolve_commit(repo, commit) is not None


def tree_hash(repo: Path, commit: str) -> str | None:
    if not is_git_repository(repo) or not _valid_commit_argument(commit):
        return None
    result = run_git(repo, ["rev-parse", "--verify", "--quiet", f"{commit}^{{tree}}"])
    if not result.succeeded:
        return None
    return result.stdout.decode("ascii", errors="strict").strip()
