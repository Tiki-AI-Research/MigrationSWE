from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence


@dataclass(frozen=True)
class GitResult:
    returncode: int | None
    stdout: bytes
    stderr: bytes
    timed_out: bool = False
    error: str | None = None

    @property
    def succeeded(self) -> bool:
        return self.returncode == 0 and not self.timed_out and self.error is None


def run_git(
    repo: Path | None,
    args: Sequence[str],
    *,
    env: Mapping[str, str] | None = None,
    timeout_sec: int = 60,
) -> GitResult:
    command = ["git"]
    if repo is not None:
        command.extend(["-C", str(repo)])
    command.extend(args)
    merged_env = os.environ.copy()
    if env is not None:
        merged_env.update(env)
    try:
        completed = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=merged_env,
            timeout=timeout_sec,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout if isinstance(exc.stdout, bytes) else b""
        stderr = exc.stderr if isinstance(exc.stderr, bytes) else b""
        return GitResult(None, stdout, stderr, timed_out=True, error=str(exc))
    except OSError as exc:
        return GitResult(None, b"", b"", error=str(exc))
    return GitResult(completed.returncode, completed.stdout, completed.stderr)


def decode_output(value: bytes, limit: int = 4000) -> str:
    return value[-limit:].decode("utf-8", errors="replace")
