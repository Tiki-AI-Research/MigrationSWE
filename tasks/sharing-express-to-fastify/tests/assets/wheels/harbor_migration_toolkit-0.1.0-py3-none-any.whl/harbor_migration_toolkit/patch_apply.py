from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from ._git import decode_output, run_git
from .patch_input import PatchInput, patch_is_empty, read_patch
from .repository import commit_exists, is_git_repository


PatchStatus = Literal["passed", "candidate_failure", "infrastructure_error"]


@dataclass(frozen=True)
class PatchCheckResult:
    passed: bool
    status: PatchStatus
    reason: str | None = None
    command: tuple[str, ...] = ()
    exit_code: int | None = None
    stdout: str = ""
    stderr: str = ""


def _input_error(reason: str) -> PatchCheckResult:
    return PatchCheckResult(False, "infrastructure_error", reason=reason)


def _git_result(
    result,
    command: tuple[str, ...],
    *,
    failure_status: PatchStatus,
    reason: str,
) -> PatchCheckResult:
    if result.error is not None or result.timed_out:
        return PatchCheckResult(
            False,
            "infrastructure_error",
            reason=result.error or "git command timed out",
            command=command,
            exit_code=result.returncode,
            stdout=decode_output(result.stdout),
            stderr=decode_output(result.stderr),
        )
    if result.returncode == 0:
        return PatchCheckResult(
            True,
            "passed",
            command=command,
            exit_code=0,
            stdout=decode_output(result.stdout),
            stderr=decode_output(result.stderr),
        )
    return PatchCheckResult(
        False,
        failure_status,
        reason=reason,
        command=command,
        exit_code=result.returncode,
        stdout=decode_output(result.stdout),
        stderr=decode_output(result.stderr),
    )


def apply_patch(
    repo: Path,
    patch: PatchInput,
    *,
    check_only: bool = False,
    timeout_sec: int = 60,
) -> PatchCheckResult:
    """Apply a patch to an explicitly selected worktree.

    ``check_only=True`` performs a dry run. With the default, the target
    worktree is modified; callers that need isolation should use
    ``check_patch_applicable`` instead.
    """

    repo = Path(repo).resolve()
    try:
        patch_bytes = read_patch(patch)
    except (OSError, TypeError, UnicodeError) as exc:
        return _input_error(f"unable to read patch: {exc}")
    if not is_git_repository(repo):
        return PatchCheckResult(False, "candidate_failure", reason="not a Git worktree")
    if not patch_bytes:
        return PatchCheckResult(True, "passed", reason="empty patch")

    temporary_patch: Path | None = None
    if isinstance(patch, (Path, os.PathLike)):
        patch_path = Path(patch).resolve()
    elif isinstance(patch, str):
        candidate_path = Path(patch)
        patch_path = candidate_path.resolve() if candidate_path.is_file() else None
    else:
        patch_path = None
    if patch_path is None:
        temporary_patch = Path(tempfile.mkstemp(prefix="harbor-patch-", suffix=".patch")[1])
        temporary_patch.write_bytes(patch_bytes)
        patch_path = temporary_patch

    args = ["apply"]
    if check_only:
        args.append("--check")
    args.extend(["--binary", str(patch_path)])
    command = tuple(["git", "apply", *args[1:]])
    try:
        result = run_git(repo, args, timeout_sec=timeout_sec)
        return _git_result(
            result,
            command,
            failure_status="candidate_failure",
            reason="git apply rejected the patch",
        )
    finally:
        if temporary_patch is not None:
            temporary_patch.unlink(missing_ok=True)


def _clone_at_base(repo: Path, base_commit: str, target: Path, timeout_sec: int) -> PatchCheckResult:
    clone_command = ("git", "clone", "--no-local", str(repo), str(target))
    cloned = run_git(
        None,
        ["clone", "--quiet", "--no-local", str(repo), str(target)],
        timeout_sec=timeout_sec,
    )
    clone_result = _git_result(
        cloned,
        clone_command,
        failure_status="infrastructure_error",
        reason="unable to create a temporary clean repository",
    )
    if not clone_result.passed:
        return clone_result
    checkout_command = ("git", "checkout", "--detach", "--quiet", base_commit)
    checked_out = run_git(
        target,
        ["checkout", "--detach", "--quiet", base_commit],
        timeout_sec=timeout_sec,
    )
    return _git_result(
        checked_out,
        checkout_command,
        failure_status="candidate_failure",
        reason="base commit cannot be checked out",
    )


def check_patch_applicable(
    repo: Path,
    base_commit: str,
    patch: PatchInput,
    *,
    allow_empty: bool = True,
    timeout_sec: int = 60,
) -> PatchCheckResult:
    """Check a patch against a clean copy of ``base_commit``.

    The source worktree, index, and HEAD are never modified. Empty patches are
    considered applicable by default; task-specific policy can reject them by
    passing ``allow_empty=False``.
    """

    repo = Path(repo).resolve()
    try:
        patch_bytes = read_patch(patch)
    except (OSError, TypeError, UnicodeError) as exc:
        return _input_error(f"unable to read patch: {exc}")
    if not is_git_repository(repo):
        return PatchCheckResult(False, "candidate_failure", reason="not a Git worktree")
    if not commit_exists(repo, base_commit):
        return PatchCheckResult(False, "candidate_failure", reason="base commit does not exist")
    if patch_is_empty(patch_bytes):
        if allow_empty:
            return PatchCheckResult(True, "passed", reason="empty patch")
        return PatchCheckResult(False, "candidate_failure", reason="empty patch is not allowed")

    temporary_patch: Path | None = None
    if isinstance(patch, (Path, os.PathLike)):
        patch_path = Path(patch).resolve()
    elif isinstance(patch, str):
        candidate_path = Path(patch)
        patch_path = candidate_path.resolve() if candidate_path.is_file() else None
    else:
        patch_path = None
    if patch_path is None:
        fd, raw_path = tempfile.mkstemp(prefix="harbor-patch-", suffix=".patch")
        os.close(fd)
        temporary_patch = Path(raw_path)
        temporary_patch.write_bytes(patch_bytes)
        patch_path = temporary_patch

    try:
        with tempfile.TemporaryDirectory(prefix="harbor-patch-check-") as directory:
            clean_repo = Path(directory) / "repo"
            prepared = _clone_at_base(repo, base_commit, clean_repo, timeout_sec)
            if not prepared.passed:
                return prepared
            args = ["apply", "--check", "--binary", str(patch_path)]
            result = run_git(clean_repo, args, timeout_sec=timeout_sec)
            return _git_result(
                result,
                tuple(["git", *args]),
                failure_status="candidate_failure",
                reason="git apply rejected the patch",
            )
    finally:
        if temporary_patch is not None:
            temporary_patch.unlink(missing_ok=True)


def patch_applies(
    repo: Path,
    base_commit: str,
    patch: PatchInput,
    *,
    allow_empty: bool = True,
    timeout_sec: int = 60,
) -> bool:
    return check_patch_applicable(
        repo,
        base_commit,
        patch,
        allow_empty=allow_empty,
        timeout_sec=timeout_sec,
    ).passed
