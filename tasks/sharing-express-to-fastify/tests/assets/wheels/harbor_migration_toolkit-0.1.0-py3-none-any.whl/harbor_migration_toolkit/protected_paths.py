from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass
from typing import Literal

from .patch_export import ChangedFile


ProtectedPathType = Literal["file", "directory"]
ChangedPathRole = Literal["path", "old_path"]
ProtectedPathsStatus = Literal[
    "passed",
    "policy_violation",
    "configuration_error",
    "infrastructure_error",
]

_WINDOWS_DRIVE_RE = re.compile(r"^[A-Za-z]:")
_VALID_CHANGE_CODES = frozenset("ACDMRTUXB")


@dataclass(frozen=True)
class ProtectedPathViolation:
    change: str
    changed_path: str
    path_role: ChangedPathRole
    protected_path: str
    protected_type: ProtectedPathType


@dataclass(frozen=True)
class ProtectedPathsCheckResult:
    passed: bool
    status: ProtectedPathsStatus
    violations: tuple[ProtectedPathViolation, ...] = ()
    reason: str | None = None


def _normalize_repo_path(value: str, source: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{source} must be a string")
    normalized = value.replace("\\", "/").rstrip("/")
    if not normalized:
        raise ValueError(f"{source} must not be empty")
    if "\0" in normalized:
        raise ValueError(f"{source} must not contain NUL")
    if normalized.startswith("/") or _WINDOWS_DRIVE_RE.match(normalized):
        raise ValueError(f"{source} must be repository-relative")
    if any(part in {"", ".", ".."} for part in normalized.split("/")):
        raise ValueError(f"{source} contains an unsafe path segment")
    return normalized


def _normalize_rules(paths: Iterable[str], label: str) -> tuple[str, ...]:
    if isinstance(paths, (str, bytes)):
        raise ValueError(f"{label} must be a collection of paths")
    try:
        normalized = (
            _normalize_repo_path(path, f"{label}[{index}]")
            for index, path in enumerate(paths)
        )
        return tuple(dict.fromkeys(normalized))
    except TypeError as exc:
        raise ValueError(f"{label} must be a collection of paths") from exc


def _affected_paths(changed_file: ChangedFile) -> tuple[tuple[ChangedPathRole, str], ...]:
    if not isinstance(changed_file, ChangedFile):
        raise ValueError("changed_files must contain ChangedFile values")
    if (
        not isinstance(changed_file.status, str)
        or not changed_file.status
        or changed_file.status[0] not in _VALID_CHANGE_CODES
    ):
        raise ValueError("changed file has an invalid Git status")

    current = _normalize_repo_path(changed_file.path, "changed file path")
    result: list[tuple[ChangedPathRole, str]] = [("path", current)]
    if changed_file.status.startswith("R"):
        if changed_file.old_path is None:
            raise ValueError("rename changed file is missing old_path")
        old = _normalize_repo_path(changed_file.old_path, "changed file old_path")
        result.append(("old_path", old))
    return tuple(result)


def _directory_contains(directory: str, path: str) -> bool:
    return path == directory or path.startswith(f"{directory}/")


def check_protected_paths(
    changed_files: Iterable[ChangedFile],
    *,
    protected_files: Iterable[str] = (),
    protected_directories: Iterable[str] = (),
) -> ProtectedPathsCheckResult:
    """Compare canonical candidate changes with frozen protected repository paths."""

    try:
        files = _normalize_rules(protected_files, "protected_files")
        directories = _normalize_rules(
            protected_directories,
            "protected_directories",
        )
    except (TypeError, ValueError) as exc:
        return ProtectedPathsCheckResult(
            False,
            "configuration_error",
            reason=str(exc),
        )

    if isinstance(changed_files, (str, bytes)):
        return ProtectedPathsCheckResult(
            False,
            "infrastructure_error",
            reason="changed_files must be a collection of ChangedFile values",
        )

    violations: list[ProtectedPathViolation] = []
    try:
        for changed_file in changed_files:
            for path_role, changed_path in _affected_paths(changed_file):
                for protected_path in files:
                    if changed_path == protected_path:
                        violations.append(
                            ProtectedPathViolation(
                                change=changed_file.status,
                                changed_path=changed_path,
                                path_role=path_role,
                                protected_path=protected_path,
                                protected_type="file",
                            )
                        )
                for protected_path in directories:
                    if _directory_contains(protected_path, changed_path):
                        violations.append(
                            ProtectedPathViolation(
                                change=changed_file.status,
                                changed_path=changed_path,
                                path_role=path_role,
                                protected_path=protected_path,
                                protected_type="directory",
                            )
                        )
    except (TypeError, ValueError) as exc:
        return ProtectedPathsCheckResult(
            False,
            "infrastructure_error",
            reason=str(exc),
        )

    if violations:
        return ProtectedPathsCheckResult(
            False,
            "policy_violation",
            violations=tuple(violations),
            reason="candidate patch touches protected repository paths",
        )
    return ProtectedPathsCheckResult(True, "passed")


def protected_paths_unchanged(
    changed_files: Iterable[ChangedFile],
    *,
    protected_files: Iterable[str] = (),
    protected_directories: Iterable[str] = (),
) -> bool:
    return check_protected_paths(
        changed_files,
        protected_files=protected_files,
        protected_directories=protected_directories,
    ).passed
