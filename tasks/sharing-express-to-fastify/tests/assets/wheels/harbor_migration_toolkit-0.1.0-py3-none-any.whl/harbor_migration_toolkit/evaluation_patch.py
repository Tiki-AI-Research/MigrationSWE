from __future__ import annotations

import os
import re
import shutil
import stat
import tempfile
from pathlib import Path

from ._git import decode_output, run_git


_TASK_ID_RE = re.compile(r"^[A-Za-z0-9._-]+$")
_RESERVED_ROOT = ".harbor_eval"


def _validate_task_id(task_id: str) -> None:
    if (
        not isinstance(task_id, str)
        or task_id in {"", ".", ".."}
        or _TASK_ID_RE.fullmatch(task_id) is None
    ):
        raise ValueError(
            "task_id must be a non-empty path segment containing only ASCII "
            "letters, digits, '.', '_' or '-'"
        )


def _is_link_like(path: Path) -> bool:
    details = path.lstat()
    if stat.S_ISLNK(details.st_mode):
        return True
    reparse_flag = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
    return bool(getattr(details, "st_file_attributes", 0) & reparse_flag)


def _validate_source_directory(source: Path, label: str) -> Path:
    unresolved = Path(source)
    if not unresolved.is_dir():
        raise ValueError(f"{label} directory does not exist or is not a directory")
    if _is_link_like(unresolved):
        raise ValueError(f"{label} directory must not be a symbolic link")

    resolved = unresolved.resolve()
    file_count = 0
    pending = [resolved]
    while pending:
        directory = pending.pop()
        with os.scandir(directory) as entries:
            for entry in entries:
                path = Path(entry.path)
                if entry.name.casefold() == ".git":
                    raise ValueError(f"{label} directory must not contain .git content")
                if _is_link_like(path):
                    raise ValueError(f"{label} directory must not contain a symbolic link")
                if entry.is_dir(follow_symlinks=False):
                    pending.append(path)
                elif entry.is_file(follow_symlinks=False):
                    file_count += 1
                else:
                    raise ValueError(f"{label} directory contains a non-regular file")

    if file_count == 0:
        raise ValueError(f"{label} directory must contain at least one file")
    return resolved


def _require_git_success(result, operation: str) -> None:
    if result.succeeded:
        return
    detail = result.error or decode_output(result.stderr).strip() or "unknown Git error"
    raise RuntimeError(f"{operation} failed: {detail}")


def _validate_staged_paths(data: bytes, task_id: str) -> None:
    fields = data.split(b"\0")
    if fields and fields[-1] == b"":
        fields.pop()
    if len(fields) % 2 != 0:
        raise RuntimeError("git produced malformed staged path output")

    expected_prefixes = (
        f"{_RESERVED_ROOT}/{task_id}/p2p/",
        f"{_RESERVED_ROOT}/{task_id}/f2p/",
    )
    seen_prefixes: set[str] = set()
    for index in range(0, len(fields), 2):
        status = fields[index].decode("ascii", errors="replace")
        path = fields[index + 1].decode("utf-8", errors="surrogateescape")
        if status != "A":
            raise RuntimeError(f"evaluation patch contains non-addition status: {status}")
        matching_prefix = next(
            (prefix for prefix in expected_prefixes if path.startswith(prefix)),
            None,
        )
        if matching_prefix is None:
            raise RuntimeError(f"evaluation patch contains an unexpected path: {path}")
        seen_prefixes.add(matching_prefix)

    if seen_prefixes != set(expected_prefixes):
        raise RuntimeError("evaluation patch must contain both P2P and F2P files")


def _write_atomically(output_path: Path, content: bytes) -> Path:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            dir=output_path.parent,
            prefix=f".{output_path.name}.",
            suffix=".tmp",
            delete=False,
        ) as stream:
            temporary_path = Path(stream.name)
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary_path, output_path)
        temporary_path = None
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)
    return output_path


def build_evaluation_test_patch(
    p2p_dir: Path,
    f2p_dir: Path,
    output_path: Path,
    *,
    task_id: str,
    timeout_sec: int = 60,
) -> Path:
    """Package validated P2P/F2P assets as an additions-only Git patch."""

    _validate_task_id(task_id)
    p2p_source = _validate_source_directory(p2p_dir, "P2P")
    f2p_source = _validate_source_directory(f2p_dir, "F2P")
    if p2p_source == f2p_source:
        raise ValueError("P2P and F2P directories must be different")

    destination = Path(output_path).resolve()
    with tempfile.TemporaryDirectory(prefix="harbor-evaluation-patch-") as directory:
        repo = Path(directory) / "repo"
        repo.mkdir()
        reserved = repo / _RESERVED_ROOT / task_id
        reserved.mkdir(parents=True)
        shutil.copytree(p2p_source, reserved / "p2p")
        shutil.copytree(f2p_source, reserved / "f2p")

        initialized = run_git(repo, ["init", "--quiet"], timeout_sec=timeout_sec)
        _require_git_success(initialized, "git init")
        staged = run_git(
            repo,
            [
                "-c",
                "core.autocrlf=false",
                "add",
                "--all",
                "--force",
                "--",
                _RESERVED_ROOT,
            ],
            timeout_sec=timeout_sec,
        )
        _require_git_success(staged, "git add")

        names = run_git(
            repo,
            ["diff", "--cached", "--name-status", "--no-renames", "-z"],
            timeout_sec=timeout_sec,
        )
        _require_git_success(names, "git diff --name-status")
        _validate_staged_paths(names.stdout, task_id)

        patch = run_git(
            repo,
            [
                "diff",
                "--cached",
                "--binary",
                "--full-index",
                "--no-ext-diff",
                "--no-textconv",
                "--no-renames",
                "--src-prefix=a/",
                "--dst-prefix=b/",
            ],
            timeout_sec=timeout_sec,
        )
        _require_git_success(patch, "git diff")
        if not patch.stdout:
            raise RuntimeError("git produced an empty evaluation patch")

    return _write_atomically(destination, patch.stdout)
