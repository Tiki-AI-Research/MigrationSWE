from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import TypeAlias


PatchInput: TypeAlias = Path | bytes | str | os.PathLike[str]


def read_patch(patch: PatchInput) -> bytes:
    if isinstance(patch, bytes):
        return patch
    if isinstance(patch, (Path, os.PathLike)):
        return Path(patch).read_bytes()
    if isinstance(patch, str):
        try:
            path = Path(patch)
            if path.is_file():
                return path.read_bytes()
        except OSError:
            # A long or multiline string is patch content, not a path.
            pass
        return patch.encode("utf-8")
    raise TypeError(f"unsupported patch input: {type(patch).__name__}")


def patch_sha256(patch: PatchInput) -> str:
    return hashlib.sha256(read_patch(patch)).hexdigest()


def patch_is_empty(patch: PatchInput) -> bool:
    return len(read_patch(patch)) == 0
