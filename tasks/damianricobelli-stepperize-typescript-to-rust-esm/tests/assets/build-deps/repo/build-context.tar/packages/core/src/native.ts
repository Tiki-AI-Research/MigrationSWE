import { createRequire } from "node:module";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import type { Step } from "./types";

type NativeSteps = readonly Step[];

export interface PreparedValidation {
	pending: boolean;
	result: unknown;
}

export interface NativeBindings {
	stepIds(steps: NativeSteps): string[];
	stepGet(steps: NativeSteps, id: unknown): unknown;
	stepAt(steps: NativeSteps, index: number): unknown;
	stepIndexOf(steps: NativeSteps, id: unknown): number;
	stepHas(steps: NativeSteps, id: unknown): boolean;
	stepFirst(steps: NativeSteps): unknown;
	stepLast(steps: NativeSteps): unknown;
	stepNext(steps: NativeSteps, id: unknown): unknown;
	stepPrev(steps: NativeSteps, id: unknown): unknown;
	stepNeighbors(steps: NativeSteps, id: unknown): { prev: unknown; next: unknown };
	getInitialStepIndex(steps: NativeSteps, initial: unknown): number;
	parseStep(steps: NativeSteps, value: unknown): unknown;
	getInitialData(data: object | undefined): object;
	validateStepPrepare(steps: NativeSteps, id: unknown, value: unknown): PreparedValidation;
	validateStepFinish(resolved: unknown): unknown;
	getStepStatus(steps: NativeSteps, currentIndex: number, id: unknown): string;
	getStepStatuses(steps: NativeSteps, currentIndex: number): Record<string, string>;
	matchStep(steps: NativeSteps, id: unknown, handlers: object): unknown;
}

const require = createRequire(import.meta.url);
const target =
	process.platform === "linux" ? `${process.platform}-${process.arch}-gnu` : `${process.platform}-${process.arch}`;
const artifact = resolve(dirname(fileURLToPath(import.meta.url)), `../native/stepperize_core_native.${target}.node`);

export const native = require(artifact) as NativeBindings;
