import { copyFileSync, mkdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const packageDir = join(dirname(fileURLToPath(import.meta.url)), "..");
const nativeDir = join(packageDir, "native");
const target =
	process.platform === "linux" ? `${process.platform}-${process.arch}-gnu` : `${process.platform}-${process.arch}`;
const library =
	process.platform === "win32"
		? "stepperize_core_native.dll"
		: process.platform === "darwin"
			? "libstepperize_core_native.dylib"
			: "libstepperize_core_native.so";
const source = join(nativeDir, "target", "release", library);
const destination = join(nativeDir, `stepperize_core_native.${target}.node`);

mkdirSync(nativeDir, { recursive: true });
copyFileSync(source, destination);
console.log(`copied ${source} -> ${destination}`);
