import { describe, expect, it } from "vitest";
import {
	createStepMap,
	getInitialData,
	getInitialStepIndex,
	getStepStatus,
	getStepStatuses,
	matchStep,
	parseStep,
	validateStep,
} from "../utils";

type TestStep = { id: "first"; label: string } | { id: "second"; label: string } | { id: "third"; label: string };

const steps: TestStep[] = [
	{ id: "first", label: "Step 1" },
	{ id: "second", label: "Step 2" },
	{ id: "third", label: "Step 3" },
];

describe("createStepMap", () => {
	const stepMap = createStepMap(steps);

	it("returns steps and ids", () => {
		expect(stepMap.steps).toEqual(steps);
		expect(stepMap.ids).toEqual(["first", "second", "third"]);
	});

	it("gets steps by id and index", () => {
		expect(stepMap.get("second")).toEqual({ id: "second", label: "Step 2" });
		expect(stepMap.at(0)).toEqual(steps[0]);
		expect(stepMap.get("missing" as any)).toBeUndefined();
		expect(stepMap.at(9)).toBeUndefined();
	});

	it("returns positions and neighbors", () => {
		expect(stepMap.indexOf("third")).toBe(2);
		expect(stepMap.has("second")).toBe(true);
		expect(stepMap.has("missing")).toBe(false);
		expect(stepMap.first()).toEqual(steps[0]);
		expect(stepMap.last()).toEqual(steps[2]);
		expect(stepMap.next("first")).toEqual(steps[1]);
		expect(stepMap.prev("third")).toEqual(steps[1]);
		expect(stepMap.next("missing" as any)).toBeUndefined();
		expect(stepMap.prev("missing" as any)).toBeUndefined();
		expect(stepMap.neighbors("second")).toEqual({
			prev: steps[0],
			next: steps[2],
		});
		expect(stepMap.neighbors("first")).toEqual({
			prev: undefined,
			next: steps[1],
		});
	});
});

describe("getInitialStepIndex", () => {
	it("returns 0 by default or when the id is not found", () => {
		expect(getInitialStepIndex(steps)).toBe(0);
		expect(getInitialStepIndex(steps, "missing" as any)).toBe(0);
	});

	it("returns the matching index", () => {
		expect(getInitialStepIndex(steps, "second")).toBe(1);
	});
});

describe("getInitialData", () => {
	it("returns a defensive copy", () => {
		const data = { first: { saved: true } };
		expect(getInitialData<typeof steps>(data)).toEqual(data);
		expect(getInitialData<typeof steps>(data)).not.toBe(data);
	});
});

describe("validateStep", () => {
	const schema = {
		"~standard": {
			version: 1 as const,
			vendor: "test",
			validate: (value: unknown) =>
				typeof value === "string" && value.length > 0 ? { value } : { issues: [{ message: "Required" }] },
		},
	};
	const withSchema = [{ id: "name", schema }, { id: "done" }] as const;

	it("succeeds for a step without a schema, passing the value through", async () => {
		const result = await validateStep(withSchema, "done", { anything: true });
		expect(result).toEqual({ success: true, data: { anything: true } });
	});

	it("returns success with the parsed value when the schema passes", async () => {
		const result = await validateStep(withSchema, "name", "Ada");
		expect(result).toEqual({ success: true, data: "Ada" });
	});

	it("returns issues when the schema fails", async () => {
		const result = await validateStep(withSchema, "name", "");
		expect(result.success).toBe(false);
		if (!result.success) expect(result.issues[0].message).toBe("Required");
	});

	it("throws for an unknown step id", async () => {
		await expect(validateStep(withSchema, "missing" as never, null)).rejects.toThrow(/not found/);
	});
});

describe("step statuses", () => {
	it("uses active/previous/upcoming", () => {
		expect(getStepStatus(steps, 1, "first")).toBe("previous");
		expect(getStepStatus(steps, 1, "second")).toBe("active");
		expect(getStepStatus(steps, 1, "third")).toBe("upcoming");
		expect(getStepStatuses(steps, 1)).toEqual({
			first: "previous",
			second: "active",
			third: "upcoming",
		});
	});
});

describe("parseStep", () => {
	it("returns the value when it matches a known step id", () => {
		expect(parseStep(steps, "second")).toBe("second");
	});

	it("returns undefined for unknown or malformed values", () => {
		expect(parseStep(steps, "missing")).toBeUndefined();
		expect(parseStep(steps, null)).toBeUndefined();
		expect(parseStep(steps, undefined)).toBeUndefined();
		expect(parseStep(steps, 42)).toBeUndefined();
	});
});

describe("matchStep", () => {
	it("runs the handler for the provided id", () => {
		expect(
			matchStep(steps, "second", {
				first: (step) => step.label,
				second: (step) => step.label,
				third: (step) => step.label,
			}),
		).toBe("Step 2");
	});

	it("throws when no exhaustive handler exists", () => {
		expect(() => matchStep(steps, "third", { first: (step: any) => step.label } as any)).toThrow(/No match handler/);
	});
});

describe("createStepMap boundaries", () => {
	it("returns undefined for first and last of an empty sequence", () => {
		const empty = createStepMap([] as const);
		expect(empty.first()).toBeUndefined();
		expect(empty.last()).toBeUndefined();
	});

	it("returns undefined at sequence edges", () => {
		const stepMap = createStepMap(steps);
		expect(stepMap.next("third")).toBeUndefined();
		expect(stepMap.prev("first")).toBeUndefined();
		expect(stepMap.neighbors("third")).toEqual({ prev: steps[1], next: undefined });
	});
});

describe("getInitialData boundaries", () => {
	it("returns an empty object when data is omitted", () => {
		expect(getInitialData()).toEqual({});
	});

	it("copies top-level entries while preserving nested references", () => {
		const nested = { saved: true };
		const data = { first: nested };
		const copy = getInitialData<typeof steps>(data as never);
		expect(copy).not.toBe(data);
		expect(copy.first).toBe(nested);
	});

	it("preserves an own __proto__ entry without changing the prototype", () => {
		const data = { ["__proto__"]: { polluted: true } };
		const copy = getInitialData<typeof steps>(data as never);
		expect(Object.prototype.hasOwnProperty.call(copy, "__proto__")).toBe(true);
		expect(Object.getPrototypeOf(copy)).toBe(Object.prototype);
		expect(Object.getOwnPropertyDescriptor(copy, "__proto__")?.value).toEqual({ polluted: true });
	});

	it("preserves own enumerable symbol-keyed entries", () => {
		const key = Symbol("meta");
		const data = { first: { saved: true }, [key]: "symbol" };
		const copy = getInitialData<typeof steps>(data as never);
		expect((copy as Record<PropertyKey, unknown>)[key]).toBe("symbol");
	});
});

describe("validateStep async schemas", () => {
	const asyncSchema = {
		"~standard": {
			version: 1 as const,
			vendor: "async-test",
			validate: async (value: unknown) =>
				value === "valid" ? { value: "parsed" } : { issues: [{ message: "Invalid" }] },
		},
	};
	const asyncSteps = [{ id: "async", schema: asyncSchema }] as const;

	it("awaits a Promise-returning schema and returns its value", async () => {
		await expect(validateStep(asyncSteps, "async", "valid")).resolves.toEqual({
			success: true,
			data: "parsed",
		});
	});

	it("awaits a Promise-returning schema and returns its issues", async () => {
		const result = await validateStep(asyncSteps, "async", "invalid");
		expect(result.success).toBe(false);
		if (!result.success) expect(result.issues[0].message).toBe("Invalid");
	});

	it("invokes validate with the standard schema object as its receiver", async () => {
		const receiverSchema = {
			"~standard": {
				version: 1 as const,
				vendor: "receiver-test",
				expected: "ok",
				validate(value: unknown) {
					return value === this.expected ? { value } : { issues: [{ message: "Unexpected" }] };
				},
			},
		};
		const receiverSteps = [{ id: "receiver", schema: receiverSchema }] as const;

		await expect(validateStep(receiverSteps, "receiver", "ok")).resolves.toEqual({
			success: true,
			data: "ok",
		});
	});
});

describe("step statuses for unknown ids", () => {
	it("returns upcoming for a step id that does not exist", () => {
		expect(getStepStatus(steps, 1, "missing" as never)).toBe("upcoming");
	});
});

describe("matchStep isolation", () => {
	it("does not invoke other handlers when the step id is unknown", () => {
		const calls: string[] = [];
		const handlers = {
			first: (step: TestStep) => {
				calls.push(step.id);
				return step.label;
			},
			second: (step: TestStep) => {
				calls.push(step.id);
				return step.label;
			},
			third: (step: TestStep) => {
				calls.push(step.id);
				return step.label;
			},
		};
		expect(() => matchStep(steps, "missing" as never, handlers as never)).toThrow(/not found/);
		expect(calls).toEqual([]);
	});

	it("does not invoke other handlers when the selected handler is missing", () => {
		const calls: string[] = [];
		const handlers = {
			first: (step: TestStep) => {
				calls.push(step.id);
				return step.label;
			},
			second: (step: TestStep) => {
				calls.push(step.id);
				return step.label;
			},
		};
		expect(() => matchStep(steps, "third", handlers as never)).toThrow(/No match handler/);
		expect(calls).toEqual([]);
	});
});
