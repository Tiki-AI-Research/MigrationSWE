import { native } from "./native";
import type { FlowData, Get, OutputOf, Step, StepMap, StepStatus, ValidationResult } from "./types";

type NativeSteps = readonly Step[];

/**
 * Create pure step access helpers without state, safe for Node, SSR,
 * validation code, tests, and framework adapters.
 */
export function createStepMap<const Steps extends readonly Step[]>(steps: Steps): StepMap<Steps> {
	const nativeSteps = steps as NativeSteps;

	return {
		steps,
		ids: native.stepIds(nativeSteps) as Get.Id<Steps>[],
		get(id) {
			return native.stepGet(nativeSteps, id) as Get.StepById<Steps, typeof id> | undefined;
		},
		at(index) {
			return native.stepAt(nativeSteps, index) as Steps[typeof index] | undefined;
		},
		indexOf(id) {
			return native.stepIndexOf(nativeSteps, id);
		},
		has(id) {
			return native.stepHas(nativeSteps, id);
		},
		first() {
			return native.stepFirst(nativeSteps) as Steps[number] | undefined;
		},
		last() {
			return native.stepLast(nativeSteps) as Steps[number] | undefined;
		},
		next(id) {
			return native.stepNext(nativeSteps, id) as Steps[number] | undefined;
		},
		prev(id) {
			return native.stepPrev(nativeSteps, id) as Steps[number] | undefined;
		},
		neighbors(id) {
			return native.stepNeighbors(nativeSteps, id) as {
				prev: Steps[number] | undefined;
				next: Steps[number] | undefined;
			};
		},
	};
}

/**
 * Resolve the initial step index.
 *
 * Returns `0` when no initial id is provided or when the id is not found.
 */
export function getInitialStepIndex<Steps extends readonly Step[]>(steps: Steps, initial?: Get.Id<Steps>) {
	return native.getInitialStepIndex(steps as NativeSteps, initial) as number;
}

/**
 * Narrow an arbitrary value to a known step id.
 *
 * Useful at the boundary between Stepperize and external state such as URL
 * params, router state, or persisted flow snapshots.
 */
export function parseStep<const Steps extends readonly Step[]>(
	steps: Steps,
	value: unknown,
): Get.Id<Steps> | undefined {
	return native.parseStep(steps as NativeSteps, value) as Get.Id<Steps> | undefined;
}

export function getInitialData<Steps extends readonly Step[]>(data?: FlowData<Steps>) {
	return native.getInitialData(data as object | undefined) as FlowData<Steps>;
}

/**
 * Validate a value against a step's `schema` (any Standard Schema). Steps without
 * a schema always succeed with the value unchanged, so non-form steps stay
 * first-class. Always resolves to a {@link ValidationResult}.
 */
export async function validateStep<const Steps extends readonly Step[], Id extends Get.Id<Steps>>(
	steps: Steps,
	id: Id,
	value: unknown,
): Promise<ValidationResult<OutputOf<Steps, Id>>> {
	const prepared = native.validateStepPrepare(steps as NativeSteps, id, value);
	if (!prepared.pending) {
		return prepared.result as ValidationResult<OutputOf<Steps, Id>>;
	}
	const resolved = await prepared.result;
	return native.validateStepFinish(resolved) as ValidationResult<OutputOf<Steps, Id>>;
}

/**
 * Get the positional status for one step id.
 *
 * This is based only on `currentIndex`; explicit completion is tracked by the
 * React stepper instance.
 */
export function getStepStatus<Steps extends readonly Step[]>(
	steps: Steps,
	currentIndex: number,
	id: Get.Id<Steps>,
): StepStatus {
	return native.getStepStatus(steps as NativeSteps, currentIndex, id) as StepStatus;
}

export function getStepStatuses<Steps extends readonly Step[]>(
	steps: Steps,
	currentIndex: number,
): Record<Get.Id<Steps>, StepStatus> {
	return native.getStepStatuses(steps as NativeSteps, currentIndex) as Record<Get.Id<Steps>, StepStatus>;
}

export function matchStep<const Steps extends readonly Step[], Result>(
	steps: Steps,
	id: Get.Id<Steps>,
	handlers: Get.Match<Steps, Result>,
): Result;

export function matchStep<const Steps extends readonly Step[], Result>(
	steps: Steps,
	id: Get.Id<Steps>,
	handlers: Get.Match<Steps, Result>,
): Result {
	return native.matchStep(steps as NativeSteps, id, handlers as object) as Result;
}
