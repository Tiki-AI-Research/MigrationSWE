use napi::bindgen_prelude::*;
use napi::{Env, JsBoolean, JsFunction, JsNumber, JsObject, JsString, JsUnknown, NapiRaw, NapiValue, Status};
use napi_derive::napi;

fn undefined(env: &Env) -> Result<JsUnknown> {
    Ok(env.get_undefined()?.into_unknown())
}

fn check_status(status: sys::napi_status) -> Result<()> {
    if status == sys::Status::napi_ok {
        Ok(())
    } else {
        Err(Error::new(
            Status::GenericFailure,
            format!("Node-API call failed with status {}", status),
        ))
    }
}

fn value_from_object(env: &Env, object: &JsObject) -> Result<JsUnknown> {
    unsafe { Ok(JsUnknown::from_raw_unchecked(env.raw(), object.raw())) }
}

fn as_id_string(value: &JsUnknown) -> Result<Option<String>> {
    if value.get_type()? != ValueType::String {
        return Ok(None);
    }
    let string: JsString = unsafe { value.cast() };
    Ok(Some(string.into_utf8()?.into_owned()?))
}

fn step_id(step: &JsObject) -> Result<Option<String>> {
    let id: JsUnknown = step.get_named_property_unchecked("id")?;
    as_id_string(&id)
}

fn find_index(steps: &[JsObject], id: &JsUnknown) -> Result<Option<usize>> {
    let Some(target) = as_id_string(id)? else {
        return Ok(None);
    };
    for (index, step) in steps.iter().enumerate() {
        if step_id(step)?.as_deref() == Some(target.as_str()) {
            return Ok(Some(index));
        }
    }
    Ok(None)
}

fn is_truthy(value: &JsUnknown) -> Result<bool> {
    match value.get_type()? {
        ValueType::Undefined | ValueType::Null => Ok(false),
        ValueType::Boolean => {
            let boolean: JsBoolean = unsafe { value.cast() };
            boolean.get_value()
        }
        ValueType::Number => {
            let number: JsNumber = unsafe { value.cast() };
            let value = number.get_double()?;
            Ok(!(value == 0.0 || value.is_nan()))
        }
        ValueType::String => {
            let string: JsString = unsafe { value.cast() };
            Ok(string.utf8_len()? > 0)
        }
        _ => Ok(true),
    }
}

fn id_display(value: &JsUnknown) -> String {
    match as_id_string(value) {
        Ok(Some(id)) => id,
        _ => match value.get_type() {
            Ok(ValueType::Undefined) => "undefined".to_owned(),
            Ok(ValueType::Null) => "null".to_owned(),
            _ => String::new(),
        },
    }
}

fn status_for(index: i64, current_index: f64) -> &'static str {
    if (index as f64) == current_index {
        "active"
    } else if index >= 0 && (index as f64) < current_index {
        "previous"
    } else {
        "upcoming"
    }
}

#[napi]
pub fn step_ids(steps: Vec<JsObject>) -> Result<Vec<String>> {
    let mut ids = Vec::with_capacity(steps.len());
    for step in &steps {
        ids.push(step_id(step)?.unwrap_or_default());
    }
    Ok(ids)
}

#[napi]
pub fn step_get(env: Env, steps: Vec<JsObject>, id: JsUnknown) -> Result<JsUnknown> {
    match find_index(&steps, &id)? {
        Some(index) => value_from_object(&env, &steps[index]),
        None => undefined(&env),
    }
}

#[napi]
pub fn step_at(env: Env, steps: Vec<JsObject>, index: f64) -> Result<JsUnknown> {
    if !index.is_finite()
        || index < 0.0
        || index.fract() != 0.0
        || index >= steps.len() as f64
    {
        return undefined(&env);
    }
    value_from_object(&env, &steps[index as usize])
}

#[napi]
pub fn step_index_of(steps: Vec<JsObject>, id: JsUnknown) -> Result<i64> {
    Ok(find_index(&steps, &id)?
        .map(|index| index as i64)
        .unwrap_or(-1))
}

#[napi]
pub fn step_has(steps: Vec<JsObject>, id: JsUnknown) -> Result<bool> {
    Ok(find_index(&steps, &id)?.is_some())
}

#[napi]
pub fn step_first(env: Env, steps: Vec<JsObject>) -> Result<JsUnknown> {
    match steps.first() {
        Some(step) => value_from_object(&env, step),
        None => undefined(&env),
    }
}

#[napi]
pub fn step_last(env: Env, steps: Vec<JsObject>) -> Result<JsUnknown> {
    match steps.last() {
        Some(step) => value_from_object(&env, step),
        None => undefined(&env),
    }
}

#[napi]
pub fn step_next(env: Env, steps: Vec<JsObject>, id: JsUnknown) -> Result<JsUnknown> {
    match find_index(&steps, &id)? {
        Some(index) if index + 1 < steps.len() => value_from_object(&env, &steps[index + 1]),
        _ => undefined(&env),
    }
}

#[napi]
pub fn step_prev(env: Env, steps: Vec<JsObject>, id: JsUnknown) -> Result<JsUnknown> {
    match find_index(&steps, &id)? {
        Some(index) if index > 0 => value_from_object(&env, &steps[index - 1]),
        _ => undefined(&env),
    }
}

#[napi]
pub fn step_neighbors(env: Env, steps: Vec<JsObject>, id: JsUnknown) -> Result<JsObject> {
    let index = find_index(&steps, &id)?;
    let prev = match index {
        Some(index) if index > 0 => value_from_object(&env, &steps[index - 1])?,
        _ => undefined(&env)?,
    };
    let next = match index {
        Some(index) if index + 1 < steps.len() => value_from_object(&env, &steps[index + 1])?,
        _ => undefined(&env)?,
    };
    let mut neighbors = env.create_object()?;
    neighbors.set_named_property("prev", prev)?;
    neighbors.set_named_property("next", next)?;
    Ok(neighbors)
}

#[napi]
pub fn get_initial_step_index(steps: Vec<JsObject>, initial: Option<JsUnknown>) -> Result<u32> {
    let Some(initial) = initial else {
        return Ok(0);
    };
    Ok(find_index(&steps, &initial)?.map(|index| index as u32).unwrap_or(0))
}

#[napi]
pub fn parse_step(env: Env, steps: Vec<JsObject>, value: JsUnknown) -> Result<JsUnknown> {
    if find_index(&steps, &value)?.is_some() {
        Ok(value)
    } else {
        undefined(&env)
    }
}

#[napi]
pub fn get_initial_data(env: Env, data: Option<JsObject>) -> Result<JsObject> {
    let copy = env.create_object()?;
    let Some(data) = data else {
        return Ok(copy);
    };

    let mut names = std::ptr::null_mut();
    check_status(unsafe {
        sys::napi_get_all_property_names(
            env.raw(),
            data.raw(),
            sys::KeyCollectionMode::own_only,
            sys::KeyFilter::enumerable,
            sys::KeyConversion::numbers_to_strings,
            &mut names,
        )
    })?;

    let mut length: u32 = 0;
    check_status(unsafe { sys::napi_get_array_length(env.raw(), names, &mut length) })?;

    for index in 0..length {
        let mut key = std::ptr::null_mut();
        check_status(unsafe { sys::napi_get_element(env.raw(), names, index, &mut key) })?;

        let mut value = std::ptr::null_mut();
        check_status(unsafe { sys::napi_get_property(env.raw(), data.raw(), key, &mut value) })?;

        let descriptor = sys::napi_property_descriptor {
            utf8name: std::ptr::null(),
            name: key,
            method: None,
            getter: None,
            setter: None,
            value,
            attributes: sys::PropertyAttributes::writable
                | sys::PropertyAttributes::enumerable
                | sys::PropertyAttributes::configurable,
            data: std::ptr::null_mut(),
        };
        check_status(unsafe { sys::napi_define_properties(env.raw(), copy.raw(), 1, &descriptor) })?;
    }
    Ok(copy)
}

#[napi]
pub fn validate_step_prepare(
    env: Env,
    steps: Vec<JsObject>,
    id: JsUnknown,
    value: JsUnknown,
) -> Result<JsObject> {
    let Some(index) = find_index(&steps, &id)? else {
        return Err(Error::new(
            Status::GenericFailure,
            format!("Step \"{}\" not found.", id_display(&id)),
        ));
    };
    let step = &steps[index];
    let schema: JsUnknown = step.get_named_property_unchecked("schema")?;
    let mut prepared = env.create_object()?;

    if !is_truthy(&schema)? {
        let mut result = env.create_object()?;
        result.set_named_property("success", true)?;
        result.set_named_property("data", value)?;
        prepared.set_named_property("pending", false)?;
        prepared.set_named_property("result", result)?;
        return Ok(prepared);
    }

    let schema_object: JsObject = unsafe { schema.cast() };
    let standard: JsObject = schema_object.get_named_property_unchecked("~standard")?;
    let validate: JsFunction = standard.get_named_property_unchecked("validate")?;
    let result = validate.call(Some(&standard), &[&value])?;
    prepared.set_named_property("pending", true)?;
    prepared.set_named_property("result", result)?;
    Ok(prepared)
}

#[napi]
pub fn validate_step_finish(env: Env, resolved: JsUnknown) -> Result<JsObject> {
    let resolved_object: JsObject = unsafe { resolved.cast() };
    let issues: JsUnknown = resolved_object.get_named_property_unchecked("issues")?;
    let mut result = env.create_object()?;
    if is_truthy(&issues)? {
        result.set_named_property("success", false)?;
        result.set_named_property("issues", issues)?;
    } else {
        let value: JsUnknown = resolved_object.get_named_property_unchecked("value")?;
        result.set_named_property("success", true)?;
        result.set_named_property("data", value)?;
    }
    Ok(result)
}

#[napi]
pub fn get_step_status(steps: Vec<JsObject>, current_index: f64, id: JsUnknown) -> Result<String> {
    let index = find_index(&steps, &id)?
        .map(|index| index as i64)
        .unwrap_or(-1);
    Ok(status_for(index, current_index).to_owned())
}

#[napi]
pub fn get_step_statuses(
    env: Env,
    steps: Vec<JsObject>,
    current_index: f64,
) -> Result<JsObject> {
    let mut statuses = env.create_object()?;
    for (index, step) in steps.iter().enumerate() {
        let id = step_id(step)?.unwrap_or_default();
        statuses.set_named_property(&id, status_for(index as i64, current_index))?;
    }
    Ok(statuses)
}

#[napi]
pub fn match_step(
    steps: Vec<JsObject>,
    id: JsUnknown,
    handlers: JsObject,
) -> Result<JsUnknown> {
    let Some(index) = find_index(&steps, &id)? else {
        return Err(Error::new(
            Status::GenericFailure,
            format!("Step \"{}\" not found.", id_display(&id)),
        ));
    };
    let id = as_id_string(&id)?.unwrap_or_default();
    let handler: JsUnknown = handlers.get_named_property_unchecked(&id)?;

    if !is_truthy(&handler)? {
        return Err(Error::new(
            Status::GenericFailure,
            format!("No match handler found for step \"{}\".", id),
        ));
    }

    if handler.get_type()? != ValueType::Function {
        return Err(Error::new(
            Status::InvalidArg,
            format!("Match handler for step \"{}\" is not a function.", id),
        ));
    }

    let handler: JsFunction = unsafe { handler.cast() };
    handler.call(None, &[&steps[index]])
}
