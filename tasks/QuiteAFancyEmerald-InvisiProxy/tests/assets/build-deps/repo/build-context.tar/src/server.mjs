import express from 'express';
import { createServer } from 'node:http';
import { Mrrowisp } from "mrrowisp";
import helmet from 'helmet';
import {
  config,
  serverUrl,
  pages,
  externalPages,
  flatAltPaths,
  getAltPrefix,
} from './routes.mjs';
import { tryReadFile, preloaded404 } from './templates.mjs';
import { fileURLToPath } from 'node:url';
import { existsSync, unlinkSync } from 'node:fs';

/* Record the server's location as a URL object, including its host and port.
 * The host can be modified at /src/config.json, whereas the ports can be modified
 * at /ecosystem.config.js.
 */
console.log(serverUrl);

// Wisp Configuration: Refer to the documentation at https://www.npmjs.com/package/mrrowisp

const wisp = new Mrrowisp({
  port: 6001,
  logLevel: 'none',

  allowTCP: true,
  allowUDP: false,
  enableV2: true,
  enableTwisp: false,
  websocketPermessageDeflate: false,

  allowDirectIP: true,
  allowPrivateIPs: false,
  allowLoopbackIPs: true,

  parseRealIP: true,
  trustedHeaders: ['CF-Connecting-IP', 'X-Forwarded-For'],

  whitelist: {
    ports: [
      80,
      443,
      9050,
      7000,
      7001
    ],
  },

  connectionsLimitPerIP: 64,
  connectionWindowSeconds: 10,
  tcpBufferSize: 458752,
  bufferRemainingLength: 458752,
  tcpNoDelay: true,
  maxMessageSize: 28 * 1024 * 1024,

  passwordAuth: false,

  floodProtection: {
    enabled: true,
    maxConnectsPerSourceIPPerSecond: 60,
    maxConnectsPerDestPerSecond: 150,
    maxConnectsPerDestPerMinute: 3000,
    maxInFlightSyns: 768,
    maxConcurrentStreamsPerConnection: 1024,
    maxConcurrentConnections: 6144, 
    synFloodSignature: {
      enabled: true,
      windowMs: 3000,
      minSamples: 40,
      failedHandshakeRatio: 0.75,
    },
    wsCloseAfterViolations: 16,
    logBlockedDials: true,
  },

  reputation: {
    enabled: true,
    storePath: './data/mrrowisp-reputation.json',
    saveIntervalSeconds: 30,
    scoreDecayPerHour: 2,
    evictAfterDays: 7,
    thresholds: { warn: 25, throttle: 55, strict: 85 },
    weights: {
      privateEgress: 20,
      synSignature: 25,
      twispNoAuth: 40,
      burstRate: 5,
      successfulStream: -2,
      requestKnownBadDest: 3,
    },
    destinationWeights: {
      privateEgress: 25,
      synSignature: 30,
      distinctSourcesEscalation: 1,
    },
  },
});

// Modify for parallel instances
wisp.start(1);

// The server will check for the existence of this file when a shutdown is requested.
// The shutdown script in run-command.js will temporarily produce this file.
const shutdown = fileURLToPath(new URL('./.shutdown', import.meta.url));

// Set logger to true for logs.
const app = express();

// The server must not advertise the framework it runs on.
app.disable('x-powered-by');

// Match duplicate-slash and trailing-slash request paths as if they were
// normalized. This is registered first so it precedes every static mount and
// route, exactly like the previous router's ignoreDuplicateSlashes and
// ignoreTrailingSlash options.
app.use((req, res, next) => {
  const queryIndex = req.url.indexOf('?'),
    pathname = queryIndex === -1 ? req.url : req.url.slice(0, queryIndex),
    search = queryIndex === -1 ? '' : req.url.slice(queryIndex);
  let normalized = pathname.replace(/\/+/g, '/');
  if (normalized.length > 1 && normalized.endsWith('/'))
    normalized = normalized.slice(0, -1);
  req.url = normalized + search;
  next();
});

// Apply Helmet middleware for security.
app.use(
  helmet({
    contentSecurityPolicy: false, // Disable CSP
  })
);

// When a document request carries the HistoryHide cookie, the response status
// must be changed to 404. This is registered before the disguise middleware and
// every route handler so it covers static and dynamic responses alike.
app.use((req, res, next) => {
  const cookieHeader = req.headers['cookie'] || '';
  const historyHide = cookieHeader
    .split('; ')
    .find((c) => c.startsWith('HistoryHide='))
    ?.split('=')[1];

  if (historyHide === 'true' && req.headers['sec-fetch-dest'] === 'document') {
    const writeHead = res.writeHead;
    res.writeHead = function (statusCode, ...rest) {
      return writeHead.call(this, 404, ...rest);
    };
  }
  next();
});

const supportedTypes = {
    default: config.disguiseFiles ? 'image/vnd.microsoft.icon' : 'text/html',
    html: 'text/html',
    txt: 'text/plain',
    xml: 'application/xml',
    ico: 'image/vnd.microsoft.icon',
  },
  disguise = 'ico';

if (config.disguiseFiles) {
  const getActualPath = (path) =>
      path.slice(0, path.length - 1 - disguise.length),
    shouldNotHandle = new RegExp(`\\.(?!html$|${disguise}$)[\\w-]+$`, 'i'),
    loaderFile = tryReadFile(
      '../views/dist/pages/misc/deobf/loader.html',
      import.meta.url,
      false
    );
  let exemptDirs = [
      'assets',
      'uv',
      'scram',
      'epoxy',
      'libcurl',
      'baremux',
      'wisp',
    ].map((dir) => getAltPrefix(dir, serverUrl.pathname).slice(1, -1)),
    exemptPages = ['login', 'test-shutdown', 'favicon.ico'];
  for (const [key, value] of Object.entries(externalPages))
    if ('string' === typeof value) exemptPages.push(key);
    else exemptDirs.push(key);
  exemptPages = exemptPages.concat(exemptDirs);
  if (pages.default === 'login') exemptPages.push('');

  // Registered immediately after normalization so it precedes every static
  // mount and route, mirroring the previous global preHandler hook.
  app.use((req, res, next) => {
    if (req.modified) return next();
    const actualPath = new URL(req.url, serverUrl).pathname;
    if (!actualPath.startsWith(serverUrl.pathname)) return next();
    const reqPath = actualPath.slice(serverUrl.pathname.length);
    if (
      shouldNotHandle.test(reqPath) ||
      exemptDirs.some((dir) => reqPath.indexOf(dir + '/') === 0) ||
      exemptPages.includes(reqPath)
    )
      return next();

    if (!reqPath.endsWith('.' + disguise)) {
      res.type(supportedTypes.html).send(loaderFile);
      return;
    } else if (!(reqPath in pages) && !reqPath.endsWith('favicon.ico')) {
      const queryIndex = req.url.indexOf('?'),
        urlPath = queryIndex === -1 ? req.url : req.url.slice(0, queryIndex),
        urlSearch = queryIndex === -1 ? '' : req.url.slice(queryIndex);
      req.modified = true;
      req.url = getActualPath(urlPath) + urlSearch;
      res.type(supportedTypes[disguise]);
      res.header('Access-Control-Allow-Origin', 'null');
    }
    return next();
  });
}

// All entry points in the dist folder are created with source rewrites.
['sw.js', 'sw-blacklist.js'].forEach((swFile) => {
  const distName = flatAltPaths['files/' + swFile] || swFile;
  app.get(serverUrl.pathname + distName, (req, res) => {
    res
      .type('application/javascript')
      .header('Service-Worker-Allowed', serverUrl.pathname)
      .send(tryReadFile('../views/dist/' + distName, import.meta.url));
  });
});

/* If you are trying to add pages or assets in the root folder and
 * NOT entire folders, check ./src/routes.mjs and add it manually.
 *
 * All website files are stored in the /views directory.
 * This takes one of those files and displays it for a site visitor.
 * Paths like /browsing are converted into paths like /views/dist/pages/surf.html
 * back here. Which path converts to what is defined in routes.mjs.
 */
const servePage = (req, res, reqPath) => {
  // Ignore browsers' automatic requests to favicon.ico, since it does not exist.
  // This approach is needed for certain pages to not have an icon.
  if (reqPath === 'favicon.ico') {
    res.send();
    return;
  }

  if (reqPath in externalPages) {
    if (req.modified)
      return res.status(404).type(supportedTypes.html).send(preloaded404);
    let externalRoute = externalPages[reqPath];
    if (typeof externalRoute !== 'string')
      externalRoute = externalRoute.default;
    return res.redirect(externalRoute);
  }

  // If a GET request is sent to /test-shutdown and a script-generated shutdown file
  // is present, gracefully shut the server down.
  if (reqPath === 'test-shutdown' && existsSync(shutdown)) {
    console.log('InvisiProxy is shutting down.');
    wisp.stop();
    server.close();
    unlinkSync(shutdown);
    process.exitCode = 0;
  }

  // Return the error page if the query is not found in routes.mjs.
  if (reqPath && !(reqPath in pages))
    return res.status(404).type(supportedTypes.default).send(preloaded404);

  // Serve the default page if the path is the default path.
  const fileName = reqPath ? pages[reqPath] : pages[pages.default],
    type =
      supportedTypes[fileName.slice(fileName.lastIndexOf('.') + 1)] ||
      supportedTypes.default;

  if (req.modified) res.type(supportedTypes[disguise]);
  else res.type(type);
  res.send(tryReadFile('../views/dist/' + fileName, import.meta.url));
};

app.get(serverUrl.pathname + 'github/:redirect', (req, res) => {
  if (req.params.redirect in externalPages.github)
    res.redirect(externalPages.github[req.params.redirect]);
  else res.status(404).type(supportedTypes.default).send(preloaded404);
});

if (serverUrl.pathname === '/')
  // Serve the default page for the root path. Express 5's ':path' parameter does
  // not match '/', so an explicit root route is required.
  app.get(serverUrl.pathname, (req, res) => {
    servePage(req, res, '');
  });
else {
  // Apply the following patch(es) if the server URL has a prefix.

  // Patch to fix serving index.html.
  app.get(serverUrl.pathname, (req, res) => {
    res
      .type(supportedTypes.default)
      .send(tryReadFile('../views/dist/' + pages.index, import.meta.url));
  });
}

app.get(serverUrl.pathname + ':path', (req, res) => {
  // Testing for future features that need cookies to deliver alternate source files.
  /*
  if (req.raw.rawHeaders.includes('Cookie'))
    console.log(
      'cookie:',
      req.raw.rawHeaders[req.raw.rawHeaders.indexOf('Cookie') + 1]
    );
  */

  servePage(req, res, req.params.path);
});

// Serve static files after the route handlers so page routing keeps precedence,
// matching the previous router's static-over-parametric behavior.
app.use(
  serverUrl.pathname,
  express.static(
    fileURLToPath(new URL('../views/dist/pages', import.meta.url))
  )
);

// All entries in the dist folder are created with source rewrites.
// Minified scripts are also served here, if minification is enabled.
[
  'assets',
  'uv',
  'scram',
  'epoxy',
  'libcurl',
  'baremux',
].forEach((prefix) => {
  app.use(
    getAltPrefix(prefix, serverUrl.pathname),
    express.static(
      fileURLToPath(new URL('../views/dist/' + prefix, import.meta.url))
    )
  );
});

if (serverUrl.pathname === '/')
  // Set an error page for invalid paths outside the query string system.
  // If the server URL has a prefix, then avoid doing this for stealth reasons.
  app.use((req, res) => {
    res.status(404).type(supportedTypes.default).send(preloaded404);
  });

// Create the single shared HTTP server that serves both HTTP requests and the
// mrrowisp WebSocket upgrades.
const server = createServer(app);
server.on('upgrade', (req, socket, head) => {
  if (req.url.endsWith(getAltPrefix('wisp', serverUrl.pathname)))
    wisp.route(req, socket, head);
});

server.listen(serverUrl.port, serverUrl.hostname);
console.log(`InvisiProxy is listening on port ${serverUrl.port}.`);
console.log(`When hosting with a reverse proxy please ensure you are using NGINX only.\nCaddy and Apache have security risks due to mrrowisp and loopbacks. Please configure them correctly.\nNGINX is recommended and used for production. Ports are whitelisted and security is maintained with NGINX only.`);
if (config.disguiseFiles)
  console.log(
    'disguiseFiles is enabled. Visit src/routes.mjs to see the entry point, listed within the pages variable.'
  );
