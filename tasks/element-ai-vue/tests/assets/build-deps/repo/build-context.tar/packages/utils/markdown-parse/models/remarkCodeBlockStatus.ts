import type MarkdownIt from 'markdown-it'

const isClosedFence = (token: any, lines: string[]) => {
  if (!token.map) return false
  const endLine = token.map[1]
  if (!endLine || endLine > lines.length) return false

  const lastLine = lines[endLine - 1].trim()
  const marker = token.markup ? token.markup[0] : '`'
  const pattern = new RegExp(`^\\${marker}{3,}\\s*$`)
  return pattern.test(lastLine)
}

export const remarkCodeBlockStatus = (md: MarkdownIt) => {
  md.core.ruler.after('inline', 'remark-code-block-status', (state: any) => {
    const lines = state.src.split(/\r?\n/)

    state.tokens.forEach((token: any) => {
      if (token.type === 'fence') {
        const info = (token.info || '').trim()
        const firstWord = info.split(/\s+/)[0] || ''
        const language = firstWord.replace(/^language-/, '')
        token.info = language
        token.meta = token.meta || {}
        token.meta.language = language
        token.meta.loading = !isClosedFence(token, lines)
        if (token.content && !token.content.endsWith('\n')) {
          token.content += '\n'
        }
        token.meta.code = token.content
      } else if (token.type === 'code_block') {
        token.meta = token.meta || {}
        token.meta.language = ''
        token.meta.loading = true
        token.meta.code = token.content
      }
    })
  })
}
