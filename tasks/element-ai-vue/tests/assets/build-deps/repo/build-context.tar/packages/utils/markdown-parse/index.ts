import MarkdownIt from 'markdown-it'
import { katexConfig } from '@element-ai-vue/constants'
import {
  markdownItHtmlPassthrough,
  markdownItKatex,
  markdownItMath,
  markdownItTaskList,
  remarkAbbr,
  remarkATargetBlank,
  remarkCodeBlockStatus,
  remarkMarkHighlight,
  remarkSubSuper,
} from './models'
import { markdownTokensToHast } from './tokens-to-hast'
import { transformToVNode } from './hast-to-vnode'
import type { VNode } from 'vue'

export interface ProcessMarkdownOptions {
  onError?: (error: Error) => void
}

export interface MiddlewarePluginItem {
  key: string
  plugin: any
  options?: any
}

export const defaultCustomPlugins: MiddlewarePluginItem[] = [
  {
    key: 'remark-math',
    plugin: markdownItMath,
  },
  {
    key: 'remark-a-target-blank',
    plugin: remarkATargetBlank,
  },
  {
    key: 'remark-mark-highlight',
    plugin: remarkMarkHighlight,
  },
  {
    key: 'remark-sub-super',
    plugin: remarkSubSuper,
  },
  {
    key: 'remark-abbr',
    plugin: remarkAbbr,
  },
  {
    key: 'remark-code-block-status',
    plugin: remarkCodeBlockStatus,
  },
  {
    key: 'remark-rehype',
    plugin: markdownItHtmlPassthrough,
    options: { allowDangerousHtml: true },
  },
  {
    key: 'rehype-katex',
    plugin: markdownItKatex,
    options: katexConfig,
  },
]

const normalizeToken = (token: any) => {
  if (token.type === 's_open' || token.type === 's_close') {
    token.tag = 'del'
  }

  if (token.type === 'th_open' || token.type === 'td_open') {
    const style = token.attrGet('style')
    const align = style && /text-align:\s*(left|center|right)/.exec(style)
    if (align) {
      const index = token.attrIndex('style')
      if (index >= 0 && token.attrs) token.attrs.splice(index, 1)
      token.attrSet('align', align[1])
    }
  }

  if (token.children) token.children.forEach(normalizeToken)
}

const normalizeTokens = (state: any) => {
  state.tokens.forEach(normalizeToken)
}

export const createBaseProcessor = (
  middlewarePlugins: MiddlewarePluginItem[]
) => {
  const baseProcessor = new MarkdownIt({
    html: true,
    breaks: true,
    linkify: false,
    typographer: false,
  })

  baseProcessor.enable('table')
  baseProcessor.enable('strikethrough')
  baseProcessor.use(markdownItTaskList)
  baseProcessor.core.ruler.after(
    'inline',
    'normalize-markdown-tokens',
    normalizeTokens
  )

  middlewarePlugins.forEach((item) => {
    baseProcessor.use(item.plugin, item.options)
  })
  return baseProcessor
}

export interface MarkdownPart {
  type: 'html' | 'code'
  content: string | VNode | null | any
  language?: string
  loading?: boolean
}

export type ProcessorType = ReturnType<typeof createBaseProcessor>

const fenceLoading = (token: any, source: string) => {
  if (!token.map) return false
  const lines = source.split(/\r?\n/)
  const endLine = token.map[1]
  if (!endLine || endLine > lines.length) return false
  const lastLine = lines[endLine - 1].trim()
  const marker = token.markup ? token.markup[0] : '`'
  return !new RegExp(`^\\${marker}{3,}\\s*$`).test(lastLine)
}

export const processMarkdownToParts = async (
  content: string,
  processor: ProcessorType
): Promise<MarkdownPart[]> => {
  if (!content) return []

  const tokens = processor.parse(content, {})
  const parts: MarkdownPart[] = []
  let currentTokens: any[] = []

  const flushHtml = () => {
    if (currentTokens.length > 0) {
      const root = markdownTokensToHast(currentTokens)
      const vnode = transformToVNode(root as any)
      parts.push({
        type: 'html',
        content: vnode,
      })
      currentTokens = []
    }
  }

  tokens.forEach((token) => {
    const isTopLevelCode =
      (token.type === 'fence' || token.type === 'code_block') &&
      token.level === 0

    if (!isTopLevelCode) {
      currentTokens.push(token)
      return
    }

    flushHtml()

    const meta = token.meta || {}
    const language = (
      typeof meta.language === 'string'
        ? meta.language
        : token.info
          ? String(token.info).trim().split(/\s+/)[0]
          : ''
    ).replace(/^language-/, '')
    const code =
      typeof meta.code === 'string' ? meta.code : token.content || ''
    const loading =
      typeof meta.loading === 'boolean'
        ? meta.loading
        : fenceLoading(token, content)

    parts.push({ type: 'code', content: code, language, loading })
  })

  flushHtml()
  return parts
}

export const katexProcess = (content: string): string => {
  let resultContent = content
  // 将 \[...\] 转换为 $$...$$
  resultContent = resultContent.replace(
    /\\\[([\s\S]*?)\\\]/g,
    (match, formula) => {
      return `$$${formula}$$`
    }
  )
  // 将 \(...\) 转换为 $...$
  resultContent = resultContent.replace(
    /\\\(([\s\S]*?)\\\)/g,
    (match, formula) => {
      return `$${formula}$`
    }
  )
  // 识别 $...$ 中包含换行的公式，将其转换为 $$...$$
  resultContent = resultContent.replace(
    /(\$\$[\s\S]*?\$\$)|(\$([\s\S]*?)\$)/g,
    (match, doubleDollar, singleDollar, singleContent) => {
      if (doubleDollar) {
        return match
      }
      if (singleContent && singleContent.includes('\n')) {
        return `$$${singleContent}$$`
      }
      return match
    }
  )
  // 确保块级公式 $$...$$ 前后有换行，以便正确解析
  resultContent = resultContent.replace(
    /\$\$([\s\S]*?)\$\$/g,
    (match, formula) => {
      if (formula.includes('\n')) {
        return `\n$$${formula}$$\n`
      }
      return match
    }
  )
  return resultContent
}

/**
 * 将 Markdown 字符串转换为 HTML 字符串
 * @param content - Markdown 原始文本
 * @param processor - 通过 createBaseProcessor 创建的 markdown-it 处理器
 * @returns HTML 字符串
 */
export const processMarkdownToHtml = async (
  content: string,
  processor: ProcessorType
): Promise<string> => {
  return processor.render(content, {})
}
