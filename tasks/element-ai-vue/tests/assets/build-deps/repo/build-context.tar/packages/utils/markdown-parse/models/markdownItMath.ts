// @ts-ignore katex ships types through package exports
import katex from 'katex'
import { katexConfig } from '@element-ai-vue/constants'
import type MarkdownIt from 'markdown-it'

const mathInline = (state: any, silent: boolean) => {
  const start = state.pos
  const max = state.posMax
  const src = state.src

  if (src.charCodeAt(start) !== 0x24) return false

  let sizeOpen = 0
  while (start + sizeOpen < max && src.charCodeAt(start + sizeOpen) === 0x24) {
    sizeOpen += 1
  }

  let pos = start + sizeOpen
  while (pos < max) {
    const code = src.charCodeAt(pos)
    if (code === 0x5c) {
      pos += 2
      continue
    }
    if (code === 0x24) {
      let sizeClose = 0
      while (
        pos + sizeClose < max &&
        src.charCodeAt(pos + sizeClose) === 0x24
      ) {
        sizeClose += 1
      }

      if (sizeClose === sizeOpen) {
        let content = src.slice(start + sizeOpen, pos)
        if (/^[ \t\r\n]/.test(content) && /[ \t\r\n]$/.test(content)) {
          content = content.trim()
        }
        if (!silent) {
          const token = state.push('math_inline', 'math', 0)
          token.markup = src.slice(start, start + sizeOpen)
          token.content = content
          token.block = false
        }
        state.pos = pos + sizeClose
        return true
      }

      pos += sizeClose
      continue
    }
    pos += 1
  }
  return false
}

const mathBlock = (
  state: any,
  startLine: number,
  endLine: number,
  silent: boolean
) => {
  const start = state.bMarks[startLine] + state.tShift[startLine]
  const max = state.eMarks[startLine]

  if (start + 2 > max) return false
  if (state.src.slice(start, start + 2) !== '$$') return false

  let sizeOpen = 0
  while (
    start + sizeOpen < max &&
    state.src.charCodeAt(start + sizeOpen) === 0x24
  ) {
    sizeOpen += 1
  }

  const restStart = start + sizeOpen
  const rest = state.src.slice(restStart, max)
  const sameLineClose = rest.indexOf('$$')

  // A complete formula on the opening line, such as `$$x$$`, is a block.
  if (sameLineClose !== -1) {
    const closeStart = restStart + sameLineClose
    let sizeClose = 0
    while (
      closeStart + sizeClose < max &&
      state.src.charCodeAt(closeStart + sizeClose) === 0x24
    ) {
      sizeClose += 1
    }

    if (state.src.slice(closeStart + sizeClose, max).trim() !== '') {
      return false
    }

    if (silent) return true

    const token = state.push('math_block', 'math', 0)
    token.block = true
    token.markup = state.src.slice(start, start + sizeOpen)
    token.content = state.src.slice(restStart, closeStart).trim()
    token.map = [startLine, startLine + 1]

    state.line = startLine + 1
    return true
  }

  // A multi-line block closes on a later `$$` and stops at a blank line so an
  // unmatched opening cannot consume unrelated paragraphs or blocks.
  let closeLine = -1
  let closeStart = -1

  for (let line = startLine + 1; line < endLine; line += 1) {
    const lineStart = state.bMarks[line] + state.tShift[line]
    const lineEnd = state.eMarks[line]
    const lineText = state.src.slice(lineStart, lineEnd)

    if (lineText.trim() === '') break

    let searchFrom = 0
    while (searchFrom < lineText.length) {
      const index = lineText.indexOf('$$', searchFrom)
      if (index === -1) break

      const candidate = lineStart + index
      let sizeClose = 0
      while (
        candidate + sizeClose < lineEnd &&
        state.src.charCodeAt(candidate + sizeClose) === 0x24
      ) {
        sizeClose += 1
      }

      searchFrom = index + Math.max(sizeClose, 1)

      if (sizeClose < sizeOpen) continue
      if (state.src.slice(candidate + sizeClose, lineEnd).trim() !== '') {
        continue
      }

      closeLine = line
      closeStart = candidate
      break
    }

    if (closeLine !== -1) break
  }

  if (closeLine === -1) return false
  if (silent) return true

  const end = Math.min(closeLine + 1, endLine)

  const token = state.push('math_block', 'math', 0)
  token.block = true
  token.markup = state.src.slice(start, start + sizeOpen)
  token.content = state.src.slice(restStart, closeStart).trim()
  token.map = [startLine, end]

  state.line = end
  return true
}

export const markdownItMath = (md: MarkdownIt) => {
  md.inline.ruler.after('escape', 'remark-math-inline', mathInline)
  md.block.ruler.before('fence', 'remark-math-block', mathBlock, {
    alt: ['paragraph', 'reference', 'blockquote', 'list'],
  })
}

const escapeHtml = (value: string) =>
  value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')

export const markdownItKatex = (md: MarkdownIt, options?: any) => {
  const config = options
    ? {
        ...katexConfig,
        ...options,
        macros: {
          ...(katexConfig as any).macros,
          ...options.macros,
        },
      }
    : katexConfig

  const renderMath = (token: any) => {
    if (token.meta && token.meta.mathHtml) return token.meta.mathHtml
    const displayMode = token.type === 'math_block'
    let html = ''
    try {
      html = katex.renderToString(token.content, {
        ...config,
        displayMode,
      })
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      const errorColor = (config as any).errorColor || '#cc0000'
      const rendered = `<span class="katex-error" style="color:${errorColor}">${escapeHtml(
        message
      )}</span>`
      html = displayMode
        ? `<span class="katex-display">${rendered}</span>`
        : rendered
    }
    token.meta = token.meta || {}
    token.meta.mathHtml = html
    return html
  }

  const renderTokens = (tokens: any[]) => {
    tokens.forEach((token) => {
      if (
        token.type === 'math_inline' ||
        token.type === 'math_block'
      ) {
        renderMath(token)
      }
      if (token.children) renderTokens(token.children)
    })
  }

  md.core.ruler.after('inline', 'remark-katex-render', (state: any) => {
    renderTokens(state.tokens)
  })

  md.renderer.rules.math_inline = (tokens: any[], idx: number) =>
    renderMath(tokens[idx])
  md.renderer.rules.math_block = (tokens: any[], idx: number) =>
    renderMath(tokens[idx])
}
