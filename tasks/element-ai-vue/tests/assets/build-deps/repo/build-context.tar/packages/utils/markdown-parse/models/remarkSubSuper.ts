import type MarkdownIt from 'markdown-it'

const markers: Record<string, string> = {
  '~': 'sub',
  '^': 'sup',
}

const subSuper = (state: any, silent: boolean) => {
  const start = state.pos
  const src = state.src
  const marker = src[start]

  if (marker !== '~' && marker !== '^') return false
  if (start + 2 >= state.posMax) return false
  if (src[start + 1] === marker) return false
  if (src[start + 1] === '\n' || src[start + 1] === '\r') return false
  if (src[start + 2] !== marker) return false

  if (!silent) {
    const tag = markers[marker]
    const token = state.push('html_inline', '', 0)
    token.content = `<${tag}>${src[start + 1]}</${tag}>`
  }

  state.pos = start + 3
  return true
}

export const remarkSubSuper = (md: MarkdownIt) => {
  md.inline.ruler.after('emphasis', 'remark-sub-super', subSuper)
}
