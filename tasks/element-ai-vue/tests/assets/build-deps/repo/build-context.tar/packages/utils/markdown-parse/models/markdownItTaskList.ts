import type MarkdownIt from 'markdown-it'

const taskMarker = /^\[([ xX])\](?:\s+|$)/

export const markdownItTaskList = (md: MarkdownIt) => {
  md.core.ruler.after('inline', 'remark-task-list', (state: any) => {
    const tokens = state.tokens
    for (let i = 0; i < tokens.length; i += 1) {
      if (tokens[i].type !== 'list_item_open') continue

      let inline: any = null
      for (let j = i + 1; j < tokens.length; j += 1) {
        if (tokens[j].type === 'list_item_close') break
        if (tokens[j].type === 'inline') {
          inline = tokens[j]
          break
        }
      }
      if (!inline || !inline.children) continue

      const first = inline.children.find((child: any) => child.type === 'text')
      if (!first) continue

      const match = taskMarker.exec(first.content)
      if (!match) continue

      first.content = first.content.slice(match[0].length)

      const checkbox = new state.Token('task_checkbox', 'input', 0)
      checkbox.meta = {
        checked: match[1].toLowerCase() === 'x',
      }
      checkbox.attrs = [
        ['type', 'checkbox'],
        ['class', 'task-list-item-checkbox'],
        ['disabled', ''],
      ]
      if (checkbox.meta.checked) checkbox.attrs.push(['checked', ''])
      inline.children.unshift(checkbox)

      tokens[i].attrJoin('class', 'task-list-item')
    }
  })

  md.renderer.rules.task_checkbox = (tokens: any[], idx: number) => {
    const checked = tokens[idx].meta && tokens[idx].meta.checked
    return `<input type="checkbox" class="task-list-item-checkbox" disabled${
      checked ? ' checked' : ''
    }>`
  }
}
