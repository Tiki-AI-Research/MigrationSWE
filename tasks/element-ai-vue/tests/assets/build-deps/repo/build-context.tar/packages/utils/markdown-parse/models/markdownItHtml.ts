import type MarkdownIt from 'markdown-it'

export interface MarkdownItHtmlOptions {
  allowDangerousHtml?: boolean
}

export const markdownItHtmlPassthrough = (
  md: MarkdownIt,
  options?: MarkdownItHtmlOptions
) => {
  if (options && options.allowDangerousHtml === false) {
    md.set({ html: false })
  } else {
    md.set({ html: true })
  }
}
