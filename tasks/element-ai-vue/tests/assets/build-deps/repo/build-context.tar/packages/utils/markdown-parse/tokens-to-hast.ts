export interface MarkdownHastElement {
  type: 'element'
  tagName: string
  properties: Record<string, any>
  children: MarkdownHastNode[]
}

export interface MarkdownHastText {
  type: 'text'
  value: string
}

export interface MarkdownHastRaw {
  type: 'raw'
  value: string
}

export interface MarkdownHastRoot {
  type: 'root'
  children: MarkdownHastNode[]
}

export type MarkdownHastNode =
  | MarkdownHastElement
  | MarkdownHastText
  | MarkdownHastRaw

const booleanAttributes = new Set([
  'checked',
  'disabled',
  'selected',
  'multiple',
  'required',
  'autofocus',
  'novalidate',
  'readonly',
  'hidden',
])

const attrsToProps = (attrs: Array<[string, string]> | null) => {
  const properties: Record<string, any> = {}
  if (!attrs) return properties

  attrs.forEach(([name, value]) => {
    if (name === 'class' && properties.class) {
      properties.class = `${properties.class} ${value}`
      return
    }
    if (booleanAttributes.has(name)) {
      properties[name] = true
      return
    }
    properties[name] = value
  })

  return properties
}

const element = (
  tagName: string,
  properties: Record<string, any> = {},
  children: MarkdownHastNode[] = []
): MarkdownHastElement => ({
  type: 'element',
  tagName,
  properties,
  children,
})

const text = (value: string): MarkdownHastText => ({ type: 'text', value })
const raw = (value: string): MarkdownHastRaw => ({ type: 'raw', value })

const convertCode = (token: any): MarkdownHastElement => {
  const language = (
    (token.meta && token.meta.language) ||
    (token.info ? String(token.info).trim().split(/\s+/)[0] : '')
  ).replace(/^language-/, '')
  const codeProps: Record<string, any> = {}
  if (language) codeProps.class = `language-${language}`

  const content =
    token.meta && typeof token.meta.code === 'string'
      ? token.meta.code
      : token.content || ''

  return element('pre', {}, [
    element('code', codeProps, content ? [text(content)] : []),
  ])
}

const convertTokens = (
  tokens: any[],
  parent: MarkdownHastElement | MarkdownHastRoot
) => {
  let current: MarkdownHastElement | MarkdownHastRoot = parent
  const stack: Array<MarkdownHastElement | MarkdownHastRoot> = [parent]

  tokens.forEach((token) => {
    if (token.type === 'inline') {
      convertTokens(token.children || [], current)
      return
    }

    if (token.type === 'text' || token.type === 'text_special') {
      current.children.push(text(token.content || ''))
      return
    }

    if (token.type === 'softbreak') {
      current.children.push(element('br'))
      return
    }

    if (token.type === 'hardbreak') {
      current.children.push(element('br'))
      return
    }

    if (token.type === 'html_block' || token.type === 'html_inline') {
      current.children.push(raw(token.content || ''))
      return
    }

    if (token.type === 'code_inline') {
      current.children.push(
        element('code', {}, token.content ? [text(token.content)] : [])
      )
      return
    }

    if (token.type === 'fence' || token.type === 'code_block') {
      current.children.push(convertCode(token))
      return
    }

    if (token.type === 'math_inline' || token.type === 'math_block') {
      const html = token.meta && token.meta.mathHtml
      current.children.push(raw(html || token.content || ''))
      return
    }

    if (token.type === 'image') {
      const properties = attrsToProps(token.attrs)
      properties.alt = token.content || ''
      current.children.push(element('img', properties))
      return
    }

    if (token.type === 'task_checkbox') {
      current.children.push(
        element('input', {
          type: 'checkbox',
          class: 'task-list-item-checkbox',
          disabled: true,
          checked: !!(token.meta && token.meta.checked),
        })
      )
      return
    }

    if (
      (token.type === 'paragraph_open' || token.type === 'paragraph_close') &&
      token.hidden
    ) {
      return
    }

    if (token.type === 's_open' || token.type === 's_close') {
      token.tag = 'del'
    }

    if (token.nesting === 1) {
      const node = element(token.tag, attrsToProps(token.attrs))
      current.children.push(node)
      stack.push(node)
      current = node
      return
    }

    if (token.nesting === -1) {
      if (stack.length > 1) {
        stack.pop()
        current = stack[stack.length - 1]
      }
      return
    }

    if (token.tag) {
      current.children.push(element(token.tag, attrsToProps(token.attrs)))
    }
  })
}

export const markdownTokensToHast = (tokens: any[]): MarkdownHastRoot => {
  const root: MarkdownHastRoot = { type: 'root', children: [] }
  convertTokens(tokens, root)
  return root
}
