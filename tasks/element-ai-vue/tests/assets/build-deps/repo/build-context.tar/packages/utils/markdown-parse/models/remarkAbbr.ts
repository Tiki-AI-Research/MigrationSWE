import type MarkdownIt from 'markdown-it'

const definitionPattern = /^\*\[([^\]]+)\]:[ \t]*(.+?)\s*$/

const escapeRegExp = (value: string) =>
  value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')

const abbrDefinition = (
  state: any,
  startLine: number,
  _endLine: number,
  silent: boolean
) => {
  const start = state.bMarks[startLine] + state.tShift[startLine]
  const max = state.eMarks[startLine]
  const line = state.src.slice(start, max)

  const match = definitionPattern.exec(line)
  if (!match) return false
  if (silent) return true

  const env = state.env as any
  if (!env.__abbrDefinitions) env.__abbrDefinitions = new Map<string, string>()
  env.__abbrDefinitions.set(match[1], match[2])

  state.line = startLine + 1
  return true
}

const replaceAbbreviations = (state: any) => {
  const definitions = state.env.__abbrDefinitions as
    | Map<string, string>
    | undefined
  if (!definitions || definitions.size === 0) return

  const abbreviations = Array.from(definitions.keys()).sort(
    (a, b) => b.length - a.length
  )
  if (abbreviations.length === 0) return

  const pattern = new RegExp(
    `\\b(${abbreviations.map(escapeRegExp).join('|')})\\b`,
    'g'
  )

  state.tokens.forEach((token: any) => {
    if (token.type !== 'inline' || !token.children) return

    const children: any[] = []
    token.children.forEach((child: any) => {
      if (child.type !== 'text' || !child.content) {
        children.push(child)
        return
      }

      const value = child.content
      let lastIndex = 0
      let match: RegExpExecArray | null
      pattern.lastIndex = 0

      while ((match = pattern.exec(value)) !== null) {
        if (match.index > lastIndex) {
          const text = new state.Token('text', '', 0)
          text.content = value.slice(lastIndex, match.index)
          children.push(text)
        }

        const abbr = match[1]
        const html = new state.Token('html_inline', '', 0)
        html.content = `<abbr title="${definitions.get(abbr) || ''}">${abbr}</abbr>`
        children.push(html)
        lastIndex = match.index + match[0].length
      }

      if (lastIndex === 0) {
        children.push(child)
      } else if (lastIndex < value.length) {
        const text = new state.Token('text', '', 0)
        text.content = value.slice(lastIndex)
        children.push(text)
      }
    })

    token.children = children
  })
}

export const remarkAbbr = (md: MarkdownIt) => {
  md.block.ruler.before('paragraph', 'remark-abbr', abbrDefinition, {
    alt: ['paragraph', 'reference', 'blockquote', 'list'],
  })
  md.core.ruler.after('inline', 'remark-abbr-replace', (state: any) => {
    replaceAbbreviations(state)
  })
}
