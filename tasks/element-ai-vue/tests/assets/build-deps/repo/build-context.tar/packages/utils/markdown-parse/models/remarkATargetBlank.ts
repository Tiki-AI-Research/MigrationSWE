import type MarkdownIt from 'markdown-it'

const applyTargetBlank = (tokens: any[]) => {
  tokens.forEach((token) => {
    if (token.type === 'link_open') {
      token.attrSet('target', '_blank')
    }
    if (token.children) applyTargetBlank(token.children)
  })
}

export const remarkATargetBlank = (md: MarkdownIt) => {
  md.core.ruler.after('inline', 'remark-a-target-blank', (state: any) => {
    applyTargetBlank(state.tokens)
  })
}
