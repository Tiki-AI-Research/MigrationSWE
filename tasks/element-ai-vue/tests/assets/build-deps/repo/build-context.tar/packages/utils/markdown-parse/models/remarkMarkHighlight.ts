import type MarkdownIt from 'markdown-it'

const markHighlight = (state: any, silent: boolean) => {
  const start = state.pos
  const src = state.src

  if (src.slice(start, start + 2) !== '==') return false

  const close = src.indexOf('==', start + 2)
  if (close === -1 || close >= state.posMax) return false

  if (!silent) {
    const token = state.push('html_inline', '', 0)
    token.content = `<mark>${src.slice(start + 2, close)}</mark>`
  }

  state.pos = close + 2
  return true
}

export const remarkMarkHighlight = (md: MarkdownIt) => {
  md.inline.ruler.before('emphasis', 'remark-mark-highlight', markHighlight)
}
