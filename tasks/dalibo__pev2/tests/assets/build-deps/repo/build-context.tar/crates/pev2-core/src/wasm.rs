//! WebAssembly bindings exposing the same public entry points as the TypeScript
//! services. All functions are synchronous and return JSON-serializable values.

use wasm_bindgen::prelude::*;

use crate::model::JsonMap;
use crate::{help, metrics, parse_text, source};

fn to_js(value: &impl serde::Serialize) -> Result<JsValue, JsValue> {
    serde_wasm_bindgen::to_value(value).map_err(|e| JsValue::from_str(&e.to_string()))
}

fn parse_map(json: &str) -> Result<JsonMap, JsValue> {
    let value: serde_json::Value =
        serde_json::from_str(json).map_err(|e| JsValue::from_str(&e.to_string()))?;
    match value {
        serde_json::Value::Object(m) => Ok(m),
        _ => Err(JsValue::from_str("Invalid plan")),
    }
}

#[wasm_bindgen]
pub fn from_source(source_str: &str) -> Result<JsValue, JsValue> {
    let content = source::from_source(source_str).map_err(|e| JsValue::from_str(&e))?;
    to_js(&content)
}

#[wasm_bindgen]
pub fn from_text(text: &str) -> Result<JsValue, JsValue> {
    let content = parse_text::from_text(text).map_err(|e| JsValue::from_str(&e))?;
    to_js(&content)
}

#[wasm_bindgen]
pub fn from_json(source_str: &str) -> Result<JsValue, JsValue> {
    let content = source::from_json(source_str).map_err(|e| JsValue::from_str(&e))?;
    to_js(&content)
}

#[wasm_bindgen]
pub fn cleanup_source(source_str: &str) -> String {
    source::cleanup_source(source_str)
}

#[wasm_bindgen]
pub fn split_into_lines(text: &str) -> Result<JsValue, JsValue> {
    let lines = source::split_into_lines(text);
    to_js(&lines)
}

#[wasm_bindgen]
pub fn create_plan(json: &str, plan_name: &str, plan_query: &str) -> Result<JsValue, JsValue> {
    let content = parse_map(json)?;
    let plan = metrics::create_plan(plan_name, content, plan_query).map_err(|e| JsValue::from_str(&e))?;
    to_js(&plan)
}

#[wasm_bindgen]
pub fn split_balanced(input: &str, split: &str) -> Result<JsValue, JsValue> {
    let result = help::split_balanced(input, split);
    to_js(&result)
}

#[wasm_bindgen]
pub fn find_node_by_id(plan_json: &str, id: i64) -> Result<JsValue, JsValue> {
    let plan = parse_map(plan_json)?;
    match help::find_node_by_id(&plan, id) {
        Some(node) => to_js(&node),
        None => Ok(JsValue::NULL),
    }
}

#[wasm_bindgen]
pub fn find_node_by_subplan_name(plan_json: &str, subplan_name: &str) -> Result<JsValue, JsValue> {
    let plan = parse_map(plan_json)?;
    match help::find_node_by_subplan_name(&plan, subplan_name) {
        Some(node) => to_js(&node),
        None => Ok(JsValue::NULL),
    }
}

#[wasm_bindgen]
pub fn should_show_prop(key: &str, value_json: &str) -> Result<bool, JsValue> {
    let value: serde_json::Value =
        serde_json::from_str(value_json).map_err(|e| JsValue::from_str(&e.to_string()))?;
    Ok(help::should_show_prop(key, &value))
}
