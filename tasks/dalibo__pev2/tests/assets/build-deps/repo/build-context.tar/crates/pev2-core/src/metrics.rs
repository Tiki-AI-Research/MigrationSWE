//! Port of `createPlan` and the metric computation helpers.

use std::sync::OnceLock;

use fancy_regex::Regex as FancyRegex;
use regex::Regex;
use serde_json::{Map, Value};

use crate::help::{find_output_property, js_truthy};
use crate::model::{
    get_arr, get_f64, get_obj, get_str, set_i64, set_num, set_str, to_fixed3, JsonMap, Plan,
};
use crate::property as P;

type FlatEntry = (usize, Vec<usize>);

fn has(node: &JsonMap, key: &str) -> bool {
    node.contains_key(key)
}

fn normalize_query(query: &str) -> String {
    static RE: OnceLock<FancyRegex> = OnceLock::new();
    let re = RE.get_or_init(|| FancyRegex::new(r"(?m)(\S)(?!$)(\s{2,})").unwrap());
    re.replace_all(query, "$1 ").into_owned()
}

/// `createPlan`: normalise the query and compute every plan-level derived field.
pub fn create_plan(plan_name: &str, mut content: JsonMap, plan_query: &str) -> Result<Plan, String> {
    let query = normalize_query(plan_query);

    // process nodes in place
    let root = content
        .remove("Plan")
        .ok_or_else(|| "Invalid plan".to_string())?;
    let mut root_obj = match root {
        Value::Object(m) => m,
        _ => return Err("Invalid plan".to_string()),
    };
    let mut ctes: Vec<JsonMap> = Vec::new();
    let mut node_id: i64 = 1;

    // Like the TypeScript implementation, evaluate the plan-level flags before
    // `processNode` detaches CTE subtrees from the tree.
    let is_analyze = has(&root_obj, P::ACTUAL_ROWS);
    let is_verbose = find_output_property(&root_obj);

    process_node(&mut root_obj, &mut ctes, &mut node_id);

    content.insert("Plan".to_string(), Value::Object(root_obj));

    if let Some(Value::Object(planning)) = content.get_mut("Planning") {
        calculate_io_timings_average(planning);
    }

    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0);
    let created_on = format!("{}", now);

    let mut plan = Map::new();
    plan.insert("id".to_string(), Value::from(format!("{}{}", P::PEV_PLAN_TAG, now)));
    let name = if plan_name.is_empty() {
        format!("plan created on {}", created_on)
    } else {
        plan_name.to_string()
    };
    plan.insert("name".to_string(), Value::from(name));
    plan.insert("createdOn".to_string(), Value::from(created_on));
    plan.insert("content".to_string(), Value::Object(content));
    plan.insert("query".to_string(), Value::from(query));
    plan.insert("planStats".to_string(), Value::Object(Map::new()));
    plan.insert(
        "ctes".to_string(),
        Value::Array(ctes.into_iter().map(Value::Object).collect()),
    );
    plan.insert("isAnalyze".to_string(), Value::Bool(is_analyze));
    plan.insert("isVerbose".to_string(), Value::Bool(is_verbose));

    let flat = build_flat(&plan);
    fix_cte_scans_duration(&mut plan, &flat);
    fix_init_plan_usage_duration(&mut plan, &flat);
    calculate_maximums(&mut plan, &flat);

    Ok(plan)
}

fn build_flat(plan: &Map<String, Value>) -> Vec<FlatEntry> {
    let mut flat: Vec<FlatEntry> = Vec::new();
    if let Some(content) = get_obj(plan, "content") {
        if let Some(root) = content.get("Plan") {
            let mut paths = Vec::new();
            collect_paths(root, &mut Vec::new(), &mut paths);
            for p in paths {
                flat.push((0, p));
            }
        }
    }
    if let Some(ctes) = get_arr(plan, "ctes") {
        for (k, cte) in ctes.iter().enumerate() {
            let mut paths = Vec::new();
            collect_paths(cte, &mut Vec::new(), &mut paths);
            for p in paths {
                flat.push((k + 1, p));
            }
        }
    }
    flat
}

fn collect_paths(node: &Value, prefix: &mut Vec<usize>, out: &mut Vec<Vec<usize>>) {
    out.push(prefix.clone());
    if let Some(plans) = node.get(P::PLANS).and_then(|v| v.as_array()) {
        for (i, child) in plans.iter().enumerate() {
            prefix.push(i);
            collect_paths(child, prefix, out);
            prefix.pop();
        }
    }
}

fn root_value_mut<'a>(plan: &'a mut JsonMap, container: usize) -> &'a mut Value {
    if container == 0 {
        plan.get_mut("content")
            .unwrap()
            .get_mut("Plan")
            .unwrap()
    } else {
        &mut plan
            .get_mut("ctes")
            .unwrap()
            .as_array_mut()
            .unwrap()[container - 1]
    }
}

fn node_at_mut<'a>(value: &'a mut Value, path: &[usize]) -> &'a mut JsonMap {
    if path.is_empty() {
        return value.as_object_mut().unwrap();
    }
    let plans = value
        .as_object_mut()
        .unwrap()
        .get_mut(P::PLANS)
        .unwrap()
        .as_array_mut()
        .unwrap();
    node_at_mut(&mut plans[path[0]], &path[1..])
}

fn node_at<'a>(value: &'a Value, path: &[usize]) -> Option<&'a JsonMap> {
    if path.is_empty() {
        return value.as_object();
    }
    let child = value.get(P::PLANS)?.as_array()?.get(path[0])?;
    node_at(child, &path[1..])
}

fn flat_node<'a>(plan: &'a JsonMap, entry: &FlatEntry) -> Option<&'a JsonMap> {
    let content = get_obj(plan, "content")?;
    if entry.0 == 0 {
        let root = content.get("Plan")?;
        node_at(root, &entry.1)
    } else {
        let cte = get_arr(plan, "ctes")?.get(entry.0 - 1)?;
        node_at(cte, &entry.1)
    }
}

fn is_cte_node(node: &JsonMap) -> bool {
    get_str(node, P::PARENT_RELATIONSHIP) == Some("InitPlan")
        && get_str(node, P::SUBPLAN_NAME)
            .map(|s| s.starts_with("CTE"))
            .unwrap_or(false)
}

fn process_node(node: &mut JsonMap, ctes: &mut Vec<JsonMap>, node_id: &mut i64) {
    set_i64(node, P::NODE_ID, *node_id);
    *node_id += 1;
    calculate_planner_estimate(node);

    let planned = node
        .get(P::WORKERS_PLANNED)
        .filter(|v| js_truthy(v))
        .cloned()
        .or_else(|| {
            node.get(P::WORKERS_PLANNED_BY_GATHER)
                .filter(|v| js_truthy(v))
                .cloned()
        });
    let launched = node
        .get(P::WORKERS_LAUNCHED)
        .filter(|v| js_truthy(v))
        .cloned()
        .or_else(|| {
            node.get(P::WORKERS_LAUNCHED_BY_GATHER)
                .filter(|v| js_truthy(v))
                .cloned()
        });

    let child_count = node
        .get(P::PLANS)
        .and_then(|v| v.as_array())
        .map(|a| a.len())
        .unwrap_or(0);

    for i in 0..child_count {
        let plans = match node.get_mut(P::PLANS).and_then(|v| v.as_array_mut()) {
            Some(p) => p,
            None => break,
        };
        if i >= plans.len() {
            break;
        }
        let cobj = match plans[i].as_object_mut() {
            Some(o) => o,
            None => continue,
        };
        let is_cte = is_cte_node(cobj);
        let parent_rel = get_str(cobj, P::PARENT_RELATIONSHIP).map(|s| s.to_string());
        if !is_cte && parent_rel.as_deref() != Some("InitPlan") && parent_rel.as_deref() != Some("SubPlan")
        {
            if let Some(v) = &planned {
                cobj.insert(P::WORKERS_PLANNED_BY_GATHER.to_string(), v.clone());
            }
            if let Some(v) = &launched {
                cobj.insert(P::WORKERS_LAUNCHED_BY_GATHER.to_string(), v.clone());
            }
        }
        let slot = if is_cte {
            let s = ctes.len();
            ctes.push(Map::new());
            Some(s)
        } else {
            None
        };
        process_node(cobj, ctes, node_id);
        if let Some(s) = slot {
            ctes[s] = cobj.clone();
            cobj.insert("\u{0}remove".to_string(), Value::Bool(true));
        }
    }

    if let Some(plans) = node.get_mut(P::PLANS).and_then(|v| v.as_array_mut()) {
        plans.retain(|c| c.get("\u{0}remove") != Some(&Value::Bool(true)));
    }

    calculate_exclusives(node);
    calculate_buffers_io_exclusives(node);
    calculate_io_timings_average(node);
    convert_node_type(node);
}

fn calculate_planner_estimate(node: &mut JsonMap) {
    if has(node, P::ACTUAL_ROWS) && has(node, P::PLAN_ROWS) {
        let actual = get_f64(node, P::ACTUAL_ROWS);
        let plan = get_f64(node, P::PLAN_ROWS);
        if let (Some(actual), Some(plan)) = (actual, plan) {
            let mut factor = actual / plan;
            let mut direction: i64 = 3; // none
            if actual > plan {
                direction = 2; // under
            }
            if actual < plan {
                direction = 1; // over
                factor = plan / actual;
            }
            set_num(node, P::PLANNER_ESTIMATE_FACTOR, factor);
            set_i64(node, P::PLANNER_ESTIMATE_DIRECTION, direction);
        }
    }
}

fn children_duration(node: &JsonMap, mut duration: f64) -> f64 {
    if let Some(children) = get_arr(node, P::PLANS) {
        for child in children {
            if let Value::Object(c) = child {
                let rel = get_str(c, P::PARENT_RELATIONSHIP);
                if rel != Some("InitPlan") || (rel == Some("InitPlan") && get_str(node, P::NODE_TYPE) == Some("Result"))
                {
                    duration += get_f64(c, P::ACTUAL_TOTAL_TIME_REVISED).unwrap_or(0.0);
                }
            }
        }
    }
    duration
}

fn calculate_exclusives(node: &mut JsonMap) {
    if has(node, P::ACTUAL_TOTAL_TIME) {
        let workers = get_f64(node, P::WORKERS_LAUNCHED_BY_GATHER).unwrap_or(0.0) + 1.0;
        let total_time = get_f64(node, P::ACTUAL_TOTAL_TIME).unwrap_or(f64::NAN);
        let loops = get_f64(node, P::ACTUAL_LOOPS).unwrap_or(f64::NAN);
        let startup = get_f64(node, P::ACTUAL_STARTUP_TIME).unwrap_or(f64::NAN);
        let total_revised = total_time * loops / workers;
        set_num(node, P::ACTUAL_STARTUP_TIME_REVISED, startup * loops / workers);
        set_num(node, P::ACTUAL_TOTAL_TIME_REVISED, total_revised);
        let duration = total_revised - children_duration(node, 0.0);
        set_num(node, P::EXCLUSIVE_DURATION, if duration > 0.0 { duration } else { 0.0 });
    }

    if has(node, P::TOTAL_COST) {
        if let Some(tc) = get_f64(node, P::TOTAL_COST) {
            set_num(node, P::EXCLUSIVE_COST, tc);
        }
        let child_costs: Vec<f64> = get_arr(node, P::PLANS)
            .map(|children| {
                children
                    .iter()
                    .filter_map(|child| {
                        let c = child.as_object()?;
                        let cc = get_f64(c, P::TOTAL_COST)?;
                        if js_truthy(&Value::from(cc)) {
                            Some(cc)
                        } else {
                            None
                        }
                    })
                    .collect()
            })
            .unwrap_or_default();
        for cc in child_costs {
            let cur = get_f64(node, P::EXCLUSIVE_COST).unwrap_or(f64::NAN);
            set_num(node, P::EXCLUSIVE_COST, cur - cc);
        }
        if let Some(ec) = get_f64(node, P::EXCLUSIVE_COST) {
            if ec < 0.0 {
                set_num(node, P::EXCLUSIVE_COST, 0.0);
            }
        }
    }

    let revised_map: [(&str, &str); 5] = [
        (P::ACTUAL_ROWS, P::ACTUAL_ROWS_REVISED),
        (P::PLAN_ROWS, P::PLAN_ROWS_REVISED),
        (P::ROWS_REMOVED_BY_FILTER, P::ROWS_REMOVED_BY_FILTER_REVISED),
        (P::ROWS_REMOVED_BY_JOIN_FILTER, P::ROWS_REMOVED_BY_JOIN_FILTER_REVISED),
        (
            P::ROWS_REMOVED_BY_INDEX_RECHECK,
            P::ROWS_REMOVED_BY_INDEX_RECHECK_REVISED,
        ),
    ];
    for (prop, revised_prop) in revised_map {
        if has(node, prop) {
            let loops = get_f64(node, P::ACTUAL_LOOPS).filter(|v| js_truthy(&Value::from(*v))).unwrap_or(1.0);
            if let Some(v) = get_f64(node, prop) {
                set_num(node, revised_prop, v * loops);
            }
        }
    }
}

fn calculate_buffers_io_exclusives(node: &mut JsonMap) {
    const PROPS: [&str; 18] = [
        "SHARED_HIT_BLOCKS",
        "SHARED_READ_BLOCKS",
        "SHARED_DIRTIED_BLOCKS",
        "SHARED_WRITTEN_BLOCKS",
        "TEMP_READ_BLOCKS",
        "TEMP_WRITTEN_BLOCKS",
        "LOCAL_HIT_BLOCKS",
        "LOCAL_READ_BLOCKS",
        "LOCAL_DIRTIED_BLOCKS",
        "LOCAL_WRITTEN_BLOCKS",
        "IO_READ_TIME",
        "IO_WRITE_TIME",
        "SHARED_IO_READ_TIME",
        "SHARED_IO_WRITE_TIME",
        "LOCAL_IO_READ_TIME",
        "LOCAL_IO_WRITE_TIME",
        "TEMP_IO_READ_TIME",
        "TEMP_IO_WRITE_TIME",
    ];
    for name in PROPS {
        let prop = P::lookup(name).unwrap();
        let mut sum = 0.0f64;
        if let Some(children) = get_arr(node, P::PLANS) {
            for child in children {
                if let Value::Object(c) = child {
                    let has_subplan = c
                        .get(P::SUBPLAN_NAME)
                        .map(js_truthy)
                        .unwrap_or(false);
                    if !has_subplan {
                        sum += get_f64(c, prop).unwrap_or(0.0);
                    }
                }
            }
        }
        let sum = to_fixed3(sum);
        let exclusive_name = format!("EXCLUSIVE_{}", name);
        let exclusive_prop = P::lookup(&exclusive_name).unwrap();
        let value = match get_f64(node, prop) {
            Some(v) => to_fixed3(v - sum),
            None => f64::NAN,
        };
        set_num(node, exclusive_prop, value);
    }
}

fn calculate_io_timings_average(node: &mut JsonMap) {
    // scopesMatrix: Vec<(timingScope, Vec<bufferScope>)>
    let scopes_matrix: Vec<(&str, Vec<&str>)>;
    if !has(node, P::TEMP_IO_READ_TIME) {
        scopes_matrix = vec![("", vec!["shared", "local", "temp"])];
    } else if has(node, P::IO_READ_TIME) {
        scopes_matrix = vec![("", vec!["shared", "local"]), ("temp", vec!["temp"])];
    } else {
        scopes_matrix = vec![
            ("shared", vec!["shared"]),
            ("local", vec!["local"]),
            ("temp", vec!["temp"]),
        ];
    }
    let operations = ["read", "write"];
    let buffers_operations = ["read", "written"];

    for (timing_scope, buffers_scopes) in &scopes_matrix {
        for (index, operation) in operations.iter().enumerate() {
            for prefix in ["exclusive_", ""] {
                let time_name = format!(
                    "{}{}io_{}_time",
                    prefix.to_uppercase(),
                    if timing_scope.is_empty() {
                        "".to_string()
                    } else {
                        format!("{}_", timing_scope)
                    },
                    operation
                )
                .to_uppercase();
                let speed_name = format!(
                    "{}average_{}io_{}_speed",
                    prefix.to_uppercase(),
                    if timing_scope.is_empty() {
                        "".to_string()
                    } else {
                        format!("{}_", timing_scope)
                    },
                    operation
                )
                .to_uppercase();
                let time = P::lookup(&time_name)
                    .and_then(|p| get_f64(node, p))
                    .unwrap_or(0.0);
                let buffers_operation = buffers_operations[index];
                let mut buffers = 0.0f64;
                for buffer_scope in buffers_scopes {
                    let buffer_name = format!(
                        "{}{}_{}_blocks",
                        prefix.to_uppercase(),
                        buffer_scope,
                        buffers_operation
                    )
                    .to_uppercase();
                    buffers += P::lookup(&buffer_name)
                        .and_then(|p| get_f64(node, p))
                        .unwrap_or(0.0);
                }
                let buffers_name =
                    format!("{}{}_blocks", prefix.to_uppercase(), buffers_operation).to_uppercase();
                if let Some(p) = P::lookup(&buffers_name) {
                    set_num(node, p, buffers);
                }
                if time != 0.0 {
                    if let Some(p) = P::lookup(&speed_name) {
                        set_num(node, p, to_fixed3(buffers / (time / 1000.0)));
                    }
                }
            }
        }
    }

    for (index, operation) in operations.iter().enumerate() {
        for prefix in ["exclusive_", ""] {
            let sum_time_name =
                format!("{}sum_io_{}_time", prefix.to_uppercase(), operation).to_uppercase();
            let speed_name = format!(
                "{}average_sum_io_{}_speed",
                prefix.to_uppercase(),
                operation
            )
            .to_uppercase();
            let mut time = 0.0f64;
            let mut buffers = 0.0f64;
            for (timing_scope, buffers_scopes) in &scopes_matrix {
                let time_name = format!(
                    "{}{}io_{}_time",
                    prefix.to_uppercase(),
                    if timing_scope.is_empty() {
                        "".to_string()
                    } else {
                        format!("{}_", timing_scope)
                    },
                    operation
                )
                .to_uppercase();
                time += P::lookup(&time_name)
                    .and_then(|p| get_f64(node, p))
                    .unwrap_or(0.0);
                let buffers_operation = buffers_operations[index];
                for buffer_scope in buffers_scopes {
                    let buffer_name = format!(
                        "{}{}_{}_blocks",
                        prefix.to_uppercase(),
                        buffer_scope,
                        buffers_operation
                    )
                    .to_uppercase();
                    buffers += P::lookup(&buffer_name)
                        .and_then(|p| get_f64(node, p))
                        .unwrap_or(0.0);
                }
            }
            if let Some(p) = P::lookup(&sum_time_name) {
                set_num(node, p, to_fixed3(time));
            }
            if time != 0.0 {
                if let Some(p) = P::lookup(&speed_name) {
                    set_num(node, p, to_fixed3(buffers / (time / 1000.0)));
                }
            }
        }
    }
}

fn convert_node_type(node: &mut JsonMap) {
    if get_str(node, P::NODE_TYPE) == Some("ModifyTable") {
        if let Some(op) = get_str(node, P::OPERATION).map(|s| s.to_string()) {
            set_str(node, P::NODE_TYPE, op);
        }
    }
}

fn fix_cte_scans_duration(plan: &mut JsonMap, flat: &[FlatEntry]) {
    if get_bool_opt(plan, "isAnalyze") != Some(true) {
        return;
    }
    let cte_count = get_arr(plan, "ctes").map(|c| c.len()).unwrap_or(0);
    for ci in 0..cte_count {
        let cte_snapshot = match get_arr(plan, "ctes").and_then(|a| a.get(ci)) {
            Some(c) => c.clone(),
            None => continue,
        };
        let cte_duration = get_f64_obj(&cte_snapshot, P::ACTUAL_TOTAL_TIME_REVISED).unwrap_or(0.0);
        let subplan_name = get_str_obj(&cte_snapshot, P::SUBPLAN_NAME).unwrap_or("");
        let matches: Vec<&FlatEntry> = flat
            .iter()
            .filter(|e| {
                flat_node(plan, e)
                    .map(|n| {
                        let cte_name = get_str(n, P::CTE_NAME).unwrap_or("");
                        format!("CTE {}", cte_name) == subplan_name
                    })
                    .unwrap_or(false)
            })
            .collect();
        let sum: f64 = matches
            .iter()
            .filter_map(|e| flat_node(plan, e).and_then(|n| get_f64(n, P::EXCLUSIVE_DURATION)))
            .sum();
        if sum == 0.0 {
            // Original would divide by zero -> NaN; skip to keep values sane.
            // (Only reachable when there are matching scans with zero total.)
        }
        for e in matches {
            let entry = e.clone();
            let node = node_at_mut(root_value_mut(plan, entry.0), &entry.1);
            let cur = get_f64(node, P::EXCLUSIVE_DURATION).unwrap_or(0.0);
            let revised = get_f64(node, P::ACTUAL_TOTAL_TIME_REVISED).unwrap_or(0.0);
            let new_val = if sum == 0.0 {
                cur
            } else {
                (cur - cte_duration * revised / sum).max(0.0)
            };
            set_num(node, P::EXCLUSIVE_DURATION, new_val);
        }
    }
}

fn fix_init_plan_usage_duration(plan: &mut JsonMap, flat: &[FlatEntry]) {
    if get_bool_opt(plan, "isAnalyze") != Some(true) {
        return;
    }
    let init_plan_entries: Vec<FlatEntry> = flat
        .iter()
        .filter(|e| {
            flat_node(plan, e)
                .map(|n| get_str(n, P::PARENT_RELATIONSHIP) == Some("InitPlan"))
                .unwrap_or(false)
        })
        .cloned()
        .collect();

    for entry in init_plan_entries {
        let (subplan_name, sub_duration) = {
            let node = flat_node(plan, &entry).unwrap();
            let name = match get_str(node, P::SUBPLAN_NAME) {
                Some(n) => n.to_string(),
                None => continue,
            };
            (
                name,
                get_f64(node, P::ACTUAL_TOTAL_TIME_REVISED).unwrap_or(0.0),
            )
        };
        let re = name_regex();
        let caps = match re.captures(&subplan_name) {
            Ok(Some(c)) => c,
            _ => continue,
        };
        let name = caps
            .get(2)
            .or_else(|| caps.get(1))
            .map(|m| m.as_str().to_string())
            .unwrap_or_default();
        let escaped: String = name
            .chars()
            .map(|c| {
                if c.is_ascii_alphanumeric() {
                    c.to_string()
                } else {
                    format!("\\{}", c)
                }
            })
            .collect();
        let pattern = format!(".*{}[0-9]?", escaped);
        let value_re = match Regex::new(&pattern) {
            Ok(r) => r,
            Err(_) => continue,
        };

        for consumer in flat {
            let target = match flat_node(plan, consumer) {
                Some(n) => n,
                None => continue,
            };
            if get_str(target, P::PARENT_RELATIONSHIP) == Some("InitPlan") {
                continue;
            }
            let exclusive_truthy = target
                .get(P::EXCLUSIVE_DURATION)
                .map(js_truthy)
                .unwrap_or(false);
            if !exclusive_truthy {
                continue;
            }
            let matches = target.values().any(|v| match v {
                Value::String(s) => value_re.is_match(s),
                _ => false,
            });
            if matches {
                let node = node_at_mut(root_value_mut(plan, consumer.0), &consumer.1);
                let cur = get_f64(node, P::EXCLUSIVE_DURATION).unwrap_or(0.0);
                set_num(node, P::EXCLUSIVE_DURATION, cur - sub_duration);
            }
        }
    }
}

fn name_regex() -> &'static FancyRegex {
    // No fancy features needed, but keep the exact source for parity.
    static RE: OnceLock<FancyRegex> = OnceLock::new();
    RE.get_or_init(|| FancyRegex::new(r"(InitPlan\s+[1-9]+)(?:\s+\(returns (\$[0-9]+)\))*").unwrap())
}

fn max_by(plan: &JsonMap, flat: &[FlatEntry], key: &str) -> Option<f64> {
    let mut best: Option<f64> = None;
    for e in flat {
        if let Some(v) = flat_node(plan, e).and_then(|n| get_f64(n, key)) {
            if v.is_nan() {
                continue;
            }
            best = Some(match best {
                Some(b) if b >= v => b,
                _ => v,
            });
        }
    }
    best
}

fn max_by_sum<F: Fn(&JsonMap) -> f64>(plan: &JsonMap, flat: &[FlatEntry], f: F) -> Option<f64> {
    let mut best: Option<f64> = None;
    for e in flat {
        if let Some(n) = flat_node(plan, e) {
            let v = f(n);
            if v.is_nan() {
                continue;
            }
            best = Some(match best {
                Some(b) if b >= v => b,
                _ => v,
            });
        }
    }
    best
}

fn sum_props(node: &JsonMap, keys: &[&str]) -> f64 {
    let mut sum = 0.0;
    let mut any_missing = false;
    for k in keys {
        match get_f64(node, k) {
            Some(v) => sum += v,
            None => any_missing = true,
        }
    }
    if any_missing {
        f64::NAN
    } else {
        sum
    }
}

fn calculate_maximums(plan: &mut JsonMap, flat: &[FlatEntry]) {
    let largest = max_by(plan, flat, P::ACTUAL_ROWS_REVISED);
    let costliest = max_by(plan, flat, P::EXCLUSIVE_COST);
    let total_costliest = max_by(plan, flat, P::TOTAL_COST);
    let slowest = max_by(plan, flat, P::EXCLUSIVE_DURATION);

    let shared = max_by_sum(plan, flat, |n| {
        sum_props(
            n,
            &[
                P::EXCLUSIVE_SHARED_HIT_BLOCKS,
                P::EXCLUSIVE_SHARED_READ_BLOCKS,
                P::EXCLUSIVE_SHARED_DIRTIED_BLOCKS,
                P::EXCLUSIVE_SHARED_WRITTEN_BLOCKS,
            ],
        )
    });
    let temp = max_by_sum(plan, flat, |n| {
        sum_props(
            n,
            &[P::EXCLUSIVE_TEMP_READ_BLOCKS, P::EXCLUSIVE_TEMP_WRITTEN_BLOCKS],
        )
    });
    let local = max_by_sum(plan, flat, |n| {
        sum_props(
            n,
            &[
                P::EXCLUSIVE_LOCAL_HIT_BLOCKS,
                P::EXCLUSIVE_LOCAL_READ_BLOCKS,
                P::EXCLUSIVE_LOCAL_DIRTIED_BLOCKS,
                P::EXCLUSIVE_LOCAL_WRITTEN_BLOCKS,
            ],
        )
    });
    let io = max_by_sum(plan, flat, |n| {
        sum_props(
            n,
            &[P::EXCLUSIVE_SUM_IO_READ_TIME, P::EXCLUSIVE_SUM_IO_WRITE_TIME],
        )
    });
    let mut highest_estimate: Option<f64> = None;
    for e in flat {
        if let Some(f) = flat_node(plan, e).and_then(|n| get_f64(n, P::PLANNER_ESTIMATE_FACTOR)) {
            if f != f64::INFINITY && !f.is_nan() {
                highest_estimate = Some(match highest_estimate {
                    Some(b) if b >= f => b,
                    _ => f,
                });
            }
        }
    }
    let max_estimate_factor = match highest_estimate {
        Some(h) => {
            let x = h * 2.0;
            if x != 0.0 && !x.is_nan() {
                x
            } else {
                1.0
            }
        }
        None => 1.0,
    };

    let ctes_marker = plan.contains_key("content");
    let content = plan.get_mut("content").unwrap().as_object_mut().unwrap();
    if let Some(v) = largest {
        content.insert("maxRows".to_string(), Value::from(v));
    }
    if let Some(v) = costliest {
        content.insert("maxCost".to_string(), Value::from(v));
    }
    if let Some(v) = total_costliest {
        content.insert("maxTotalCost".to_string(), Value::from(v));
    }
    if let Some(v) = slowest {
        content.insert("maxDuration".to_string(), Value::from(v));
    }
    let blocks = content
        .entry("maxBlocks".to_string())
        .or_insert_with(|| Value::Object(Map::new()));
    if let Value::Object(blocks) = blocks {
        if let Some(v) = shared {
            if v != 0.0 {
                blocks.insert("Shared".to_string(), Value::from(v));
            }
        }
        if let Some(v) = temp {
            if v != 0.0 {
                blocks.insert("Temp".to_string(), Value::from(v));
            }
        }
        if let Some(v) = local {
            if v != 0.0 {
                blocks.insert("Local".to_string(), Value::from(v));
            }
        }
    }
    if !content.contains_key("maxIo") {
        content.insert("maxIo".to_string(), Value::from(0));
    }
    if let Some(v) = io {
        if v != 0.0 {
            content.insert("maxIo".to_string(), Value::from(v));
        }
    }
    content.insert("maxEstimateFactor".to_string(), Value::from(max_estimate_factor));
    let _ = ctes_marker;
}

fn get_bool_opt(plan: &JsonMap, key: &str) -> Option<bool> {
    plan.get(key).and_then(|v| v.as_bool())
}

fn get_f64_obj(map: &Value, key: &str) -> Option<f64> {
    map.as_object()?.get(key)?.as_f64()
}

fn get_str_obj<'a>(map: &'a Value, key: &str) -> Option<&'a str> {
    map.as_object()?.get(key)?.as_str()
}
