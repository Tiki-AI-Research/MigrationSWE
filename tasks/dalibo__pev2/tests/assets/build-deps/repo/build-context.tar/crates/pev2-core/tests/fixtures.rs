//! Rust-native regression tests that read the protected TypeScript fixtures
//! (read-only) and compare against the `*-expect` baselines using the same
//! subset semantics as the Vitest `toMatchObject` assertions.

use std::fs;
use std::path::{Path, PathBuf};

use pev2_core::{create_plan, find_node_by_id, from_source, split_balanced};
use serde_json::Value;

fn tests_dir() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR")).join("../../src/services/__tests__")
}

/// `toMatchObject`-style subset match. `Inner Unique` is ignored to mirror the
/// `removeKeys` helper in `from-text.spec.ts`.
fn subset(actual: &Value, expected: &Value) -> bool {
    match expected {
        Value::Object(em) => {
            let am = match actual {
                Value::Object(m) => m,
                _ => return false,
            };
            em.iter().all(|(k, v)| {
                if k == "Inner Unique" {
                    return true;
                }
                am.get(k).map(|av| subset(av, v)).unwrap_or(false)
            })
        }
        Value::Array(ea) => {
            let aa = match actual {
                Value::Array(a) => a,
                _ => return false,
            };
            ea.len() == aa.len() && ea.iter().zip(aa.iter()).all(|(e, a)| subset(a, e))
        }
        Value::Number(en) => match actual {
            Value::Number(an) => match (an.as_f64(), en.as_f64()) {
                (Some(a), Some(b)) => a == b || (a.is_nan() && b.is_nan()),
                _ => false,
            },
            _ => false,
        },
        other => actual == other,
    }
}

fn read_json(path: &Path) -> Value {
    let text = fs::read_to_string(path).unwrap_or_else(|e| panic!("read {:?}: {}", path, e));
    serde_json::from_str(&text).unwrap_or_else(|e| panic!("parse {:?}: {}", path, e))
}

#[test]
fn from_text_fixtures() {
    let dir = tests_dir().join("from-text");
    let mut failures = Vec::new();
    let mut count = 0;
    for entry in fs::read_dir(&dir).unwrap() {
        let path = entry.unwrap().path();
        let name = path.file_name().unwrap().to_string_lossy().to_string();
        if !name.ends_with("-plan") {
            continue;
        }
        count += 1;
        let stem = name.strip_suffix("-plan").unwrap();
        let expect_path = path.with_file_name(format!("{}-expect", stem));
        let plan_text = fs::read_to_string(&path).unwrap();
        let mut expected = read_json(&expect_path);
        if let Value::Array(arr) = &expected {
            expected = arr.first().cloned().unwrap_or(Value::Null);
        }
        match from_source(&plan_text) {
            Ok(actual) => {
                let actual = serde_json::to_value(&actual).unwrap();
                if !subset(&actual, &expected) {
                    failures.push(format!("{}: mismatch", name));
                }
            }
            Err(e) => failures.push(format!("{}: error {}", name, e)),
        }
    }
    assert!(count > 0, "no fixtures found at {:?}", dir);
    assert!(failures.is_empty(), "{} failures:\n{}", failures.len(), failures.join("\n"));
}

#[test]
fn line_wrapped_fixtures() {
    let dir = tests_dir().join("12-line-wrapped-plans");
    let mut failures = Vec::new();
    for i in 1..=10 {
        let base = format!("{:02}", i);
        let plan_text = fs::read_to_string(dir.join(format!("{}-plan", base))).unwrap();
        let expected = read_json(&dir.join(format!("{}-expect", base)));
        match from_source(&plan_text) {
            Ok(actual) => {
                let actual = serde_json::to_value(&actual).unwrap();
                if !subset(&actual, &expected) {
                    failures.push(format!("{}: mismatch", base));
                }
            }
            Err(e) => failures.push(format!("{}: error {}", base, e)),
        }
    }
    assert!(failures.is_empty(), "{} failures:\n{}", failures.len(), failures.join("\n"));
}

#[test]
fn io_timings_fixtures() {
    let dir = tests_dir().join("21-io-timings");
    let mut failures = Vec::new();
    let mut entries: Vec<_> = fs::read_dir(&dir)
        .unwrap()
        .map(|e| e.unwrap().path())
        .filter(|p| p.extension().map(|x| x == "plan").unwrap_or(false))
        .collect();
    entries.sort();
    for path in entries {
        let name = path.file_name().unwrap().to_string_lossy().to_string();
        let expect_path = path.with_extension("expect");
        let plan_text = fs::read_to_string(&path).unwrap();
        let expected = read_json(&expect_path);
        match from_source(&plan_text) {
            Ok(content) => {
                let plan = create_plan("", content, "").unwrap();
                let plan_json = serde_json::to_value(&plan).unwrap();
                let actual = plan_json.get("content").and_then(|c| c.get("Plan")).cloned();
                match actual {
                    Some(actual) if subset(&actual, &expected) => {}
                    _ => failures.push(format!("{}: mismatch", name)),
                }
            }
            Err(e) => failures.push(format!("{}: error {}", name, e)),
        }
    }
    assert!(failures.is_empty(), "{} failures:\n{}", failures.len(), failures.join("\n"));
}

#[test]
fn cte_exclusive_time_fixtures() {
    let dir = tests_dir().join("cte-exclusive-time");
    let mut failures = Vec::new();
    for entry in fs::read_dir(&dir).unwrap() {
        let path = entry.unwrap().path();
        if path.extension().map(|x| x != "plan").unwrap_or(true) {
            continue;
        }
        let name = path.file_name().unwrap().to_string_lossy().to_string();
        let plan_text = fs::read_to_string(&path).unwrap();
        let content = match from_source(&plan_text) {
            Ok(c) => c,
            Err(e) => {
                failures.push(format!("{}: error {}", name, e));
                continue;
            }
        };
        let root_time = content
            .get("Plan")
            .and_then(|p| p.get("Actual Total Time"))
            .and_then(|v| v.as_f64())
            .unwrap_or(0.0);
        let plan = create_plan("", content, "").unwrap();
        let plan_json = serde_json::to_value(&plan).unwrap();
        let sum = sum_exclusive(
            plan_json.get("content").and_then(|c| c.get("Plan")),
        ) + plan_json
            .get("ctes")
            .and_then(|c| c.as_array())
            .map(|a| a.iter().map(|c| sum_exclusive(Some(c))).sum::<f64>())
            .unwrap_or(0.0);
        let min = root_time * 0.99;
        let max = root_time * 1.01;
        if !(sum > min && sum < max) {
            failures.push(format!("{}: sum {} not in ({}, {})", name, sum, min, max));
        }
    }
    assert!(failures.is_empty(), "{} failures:\n{}", failures.len(), failures.join("\n"));
}

fn sum_exclusive(node: Option<&Value>) -> f64 {
    match node {
        Some(Value::Object(m)) => {
            let base = m
                .get("*Duration (exclusive)")
                .and_then(|v| v.as_f64())
                .unwrap_or(0.0);
            let children = m
                .get("Plans")
                .and_then(|v| v.as_array())
                .map(|a| a.iter().map(|c| sum_exclusive(Some(c))).sum())
                .unwrap_or(0.0);
            base + children
        }
        _ => 0.0,
    }
}

#[test]
fn plan_service_spec_cases() {
    // planned rows revised
    let content = from_source("Seq Scan on foo  (cost=0.00..18334.00 rows=1000000 width=37)").unwrap();
    let plan = create_plan("", content, "").unwrap();
    let plan_json = serde_json::to_value(&plan).unwrap();
    let node = find_node_by_id(&plan, 1).unwrap();
    assert_eq!(node.get("*Plan Rows Revised").and_then(|v| v.as_f64()), Some(1000000.0));
    let _ = plan_json;

    // never executed
    let content = from_source("Hash  (cost=6.12..6.12 rows=212 width=1346) (never executed)").unwrap();
    let plan = create_plan("", content, "").unwrap();
    let node = find_node_by_id(&plan, 1).unwrap();
    assert_eq!(node.get("Actual Total Time").and_then(|v| v.as_f64()), Some(0.0));

    // fractional rows
    let source = r#"
 Nested Loop  (cost=0.00..12.97 rows=4 width=16) (actual time=0.017..0.025 rows=1.00 loops=1)
   ->  Function Scan on unnest w  (cost=0.00..0.04 rows=4 width=12) (actual time=0.006..0.007 rows=4.00 loops=1)
   ->  Limit  (cost=0.00..3.22 rows=1 width=4) (actual time=0.003..0.004 rows=0.25 loops=4)
         ->  Seq Scan on data  (cost=0.00..41.88 rows=13 width=4) (actual time=0.003..0.003 rows=0.25 loops=4)
"#;
    let content = from_source(source).unwrap();
    let plan = create_plan("", content, "").unwrap();
    let plan_json = serde_json::to_value(&plan).unwrap();
    let root = plan_json
        .get("content")
        .and_then(|c| c.get("Plan"))
        .unwrap();
    let seq = root
        .get("Plans")
        .and_then(|p| p.as_array())
        .and_then(|p| p.get(1))
        .and_then(|p| p.get("Plans"))
        .and_then(|p| p.as_array())
        .and_then(|p| p.get(0))
        .unwrap();
    assert_eq!(seq.get("Actual Rows").and_then(|v| v.as_f64()), Some(0.25));
    assert_eq!(seq.get("*Actual Rows Is Fractional").and_then(|v| v.as_bool()), Some(true));
}

#[test]
fn split_balanced_cases() {
    assert_eq!(split_balanced("a,b", ","), vec!["a".to_string(), "b".to_string()]);
    assert_eq!(
        split_balanced("t.meter_id, t.frame_date, t.num_ligne DESC", ","),
        vec![
            "t.meter_id".to_string(),
            " t.frame_date".to_string(),
            " t.num_ligne DESC".to_string()
        ]
    );
    assert_eq!(
        split_balanced("a,(b,c),d", ","),
        vec!["a".to_string(), "(b,c)".to_string(), "d".to_string()]
    );
}
