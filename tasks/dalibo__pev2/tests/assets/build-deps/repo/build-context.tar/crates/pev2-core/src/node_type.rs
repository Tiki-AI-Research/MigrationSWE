//! Port of the TypeScript `Node` constructor type-string parsing.
//! See `src/interfaces.ts` (class Node).

use std::sync::OnceLock;

use regex::Regex;

use crate::model::{obj, set_bool, set_str, Node};
use crate::property as P;

fn scan_and_operations_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        Regex::new(
            r"^((?:Parallel\s+)?(?:Seq|Tid.*|Bitmap\s+Heap|WorkTable|(Async\s+)?Foreign)\s+Scan|Update|Insert|Delete|Merge)\son\s(\S+)(?:\s+(\S+))?$",
        )
        .unwrap()
    })
}

fn bitmap_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| Regex::new(r"^(Bitmap\s+Index\s+Scan)\son\s(\S+)$").unwrap())
}

fn index_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        Regex::new(
            r"^((?:Parallel\s+)?Index(?:\sOnly)?\sScan)(\sBackward)?\susing\s(\S+)\son\s(\S+)(?:\s+(\S+))?$",
        )
        .unwrap()
    })
}

fn cte_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| Regex::new(r"^(CTE\sScan)\son\s(\S+)(?:\s+(\S+))?$").unwrap())
}

fn function_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| Regex::new(r"^(Function\sScan)\son\s(\S+)(?:\s+(\S+))?$").unwrap())
}

fn subquery_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| Regex::new(r"^(Subquery\sScan)\son\s(.+)$").unwrap())
}

fn aggregate_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| Regex::new(r"^(Partial|Finalize)*\s*(Group|Hash|Mixed|[A-z]*)*Aggregate$").unwrap())
}

fn parallel_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| Regex::new(r"^(Parallel\s+)(.*)").unwrap())
}

fn async_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| Regex::new(r"^(Async\s+)(.*)").unwrap())
}

fn join_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        Regex::new(r"^(Nested Loop|Hash|Merge)(?:\s+(Right Semi|Right Anti|Left|Right|Full|Semi|Anti))?\s+Join$")
            .unwrap()
    })
}

/// Build a node map from a node-type string, mirroring `new Node(type)`.
pub fn parse_node_type(type_str: &str) -> Node {
    let mut node = obj();
    set_str(&mut node, P::NODE_TYPE, type_str);
    // Class field defaults from the TS `Node` class.
    set_bool(&mut node, P::ASYNC_CAPABLE, false);
    set_bool(&mut node, P::PARALLEL_AWARE, false);
    set_bool(&mut node, P::DISABLED, false);

    let scan = scan_and_operations_regex().captures(type_str);
    let bitmap = bitmap_regex().captures(type_str);
    let index = index_regex().captures(type_str);
    let cte = cte_regex().captures(type_str);
    let function = function_regex().captures(type_str);
    let subquery = subquery_regex().captures(type_str);
    let aggregate = aggregate_regex().captures(type_str);

    if let Some(m) = &scan {
        let node_type = m.get(1).map(|x| x.as_str()).unwrap_or("").to_string();
        let async_capable = m.get(2).map(|x| x.as_str()).unwrap_or("");
        let relation = m.get(3).map(|x| x.as_str()).unwrap_or("").to_string();
        let alias = m.get(4).map(|x| x.as_str()).map(|s| s.to_string());
        set_str(&mut node, P::NODE_TYPE, node_type.clone());
        set_str(&mut node, P::RELATION_NAME, relation.clone());
        set_str(&mut node, P::ALIAS, alias.unwrap_or(relation));
        if !async_capable.is_empty() {
            set_bool(&mut node, P::ASYNC_CAPABLE, true);
            let nt = crate::model::get_str(&node, P::NODE_TYPE).unwrap_or("").to_string();
            let replaced = nt.replacen("Async ", "", 1);
            set_str(&mut node, P::NODE_TYPE, replaced);
        }
    } else if let Some(m) = &bitmap {
        set_str(&mut node, P::NODE_TYPE, m.get(1).unwrap().as_str());
        set_str(&mut node, P::INDEX_NAME, m.get(2).unwrap().as_str());
    } else if let Some(m) = &index {
        set_str(&mut node, P::NODE_TYPE, m.get(1).unwrap().as_str());
        set_str(&mut node, P::INDEX_NAME, m.get(3).unwrap().as_str());
        let backward = m.get(2).is_some();
        set_str(&mut node, P::SCAN_DIRECTION, if backward { "Backward" } else { "Forward" });
        set_str(&mut node, P::RELATION_NAME, m.get(4).unwrap().as_str());
        if let Some(alias) = m.get(5) {
            set_str(&mut node, P::ALIAS, alias.as_str());
        }
    } else if let Some(m) = &cte {
        set_str(&mut node, P::NODE_TYPE, m.get(1).unwrap().as_str());
        set_str(&mut node, P::CTE_NAME, m.get(2).unwrap().as_str());
        if let Some(alias) = m.get(3) {
            set_str(&mut node, P::ALIAS, alias.as_str());
        }
    } else if let Some(m) = &function {
        set_str(&mut node, P::NODE_TYPE, m.get(1).unwrap().as_str());
        set_str(&mut node, P::FUNCTION_NAME, m.get(2).unwrap().as_str());
        if let Some(alias) = m.get(3) {
            set_str(&mut node, P::ALIAS, alias.as_str());
        }
    } else if let Some(m) = &subquery {
        set_str(&mut node, P::NODE_TYPE, m.get(1).unwrap().as_str());
        set_str(&mut node, P::ALIAS, m.get(2).unwrap().as_str());
    } else if let Some(m) = &aggregate {
        set_str(&mut node, P::NODE_TYPE, "Aggregate");
        let partial = m.get(1).map(|x| x.as_str()).filter(|s| !s.is_empty()).unwrap_or("Simple");
        set_str(&mut node, P::PARTIAL_MODE, partial);

        let raw_strategy = m.get(2).map(|x| x.as_str());
        let strategy = match raw_strategy {
            None => "Plain".to_string(),
            Some("Group") => "Sorted".to_string(),
            Some("Hash") => "Hashed".to_string(),
            Some("Mixed") => "Mixed".to_string(),
            Some(other) => other.to_string(),
        };
        if raw_strategy == Some("Hash") || raw_strategy == Some("Mixed") {
            let existing = crate::model::get_f64(&node, P::PLANNED_PARTITIONS).unwrap_or(0.0);
            set_num_planned(&mut node, existing);
        }
        set_str(&mut node, P::STRATEGY, strategy);
    }

    // Parallel prefix
    let node_type_now = crate::model::get_str(&node, P::NODE_TYPE).unwrap_or("").to_string();
    if let Some(m) = parallel_regex().captures(&node_type_now) {
        set_str(&mut node, P::NODE_TYPE, m.get(2).unwrap().as_str());
        set_bool(&mut node, P::PARALLEL_AWARE, true);
    }
    // Async prefix
    let node_type_now = crate::model::get_str(&node, P::NODE_TYPE).unwrap_or("").to_string();
    if let Some(m) = async_regex().captures(&node_type_now) {
        set_str(&mut node, P::NODE_TYPE, m.get(2).unwrap().as_str());
        set_bool(&mut node, P::ASYNC_CAPABLE, true);
    }
    // Join suffix
    let node_type_now = crate::model::get_str(&node, P::NODE_TYPE).unwrap_or("").to_string();
    if let Some(m) = join_regex().captures(&node_type_now) {
        let base = m.get(1).unwrap().as_str().to_string();
        let join_type = m.get(2).map(|x| x.as_str()).unwrap_or("Inner").to_string();
        set_str(&mut node, P::NODE_TYPE, base.clone());
        set_str(&mut node, P::JOIN_TYPE, join_type);
        let suffix = if base == "Nested Loop" { "" } else { " Join" };
        set_str(&mut node, P::NODE_TYPE, format!("{}{}", base, suffix));
    }

    node
}

fn set_num_planned(node: &mut Node, value: f64) {
    crate::model::set_num(node, P::PLANNED_PARTITIONS, value);
}
