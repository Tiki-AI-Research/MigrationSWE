//! Ports of the inline `PlanService` Vitest specs that exercise parsing and
//! derived metrics.

use pev2_core::{create_plan, find_node_by_id, from_source, from_text};
use serde_json::Value;

fn plan_of(source: &str) -> Value {
    let content = from_source(source).expect("parse");
    let plan = create_plan("", content, "").expect("createPlan");
    serde_json::to_value(&plan).unwrap()
}

fn root_of(source: &str) -> Value {
    plan_of(source)
        .get("content")
        .and_then(|c| c.get("Plan"))
        .cloned()
        .unwrap()
}

fn f(v: &Value, key: &str) -> f64 {
    v.get(key).and_then(|x| x.as_f64()).unwrap_or(f64::NAN)
}

fn approx(a: f64, b: f64) {
    assert!((a - b).abs() < 1e-6, "expected {b}, got {a}");
}

#[test]
fn actual_durations_loops() {
    let source = r#"
 Nested Loop  (cost=0.00..611.27 rows=13400 width=8) (actual time=0.025..10.198 rows=34956 loops=1)
   Join Filter: (t1.c1 > t2.c2)
   Rows Removed by Join Filter: 5244
   ->  Seq Scan on t1  (cost=0.00..6.02 rows=402 width=4) (actual time=0.013..0.058 rows=402 loops=1)
   ->  Materialize  (cost=0.00..2.50 rows=100 width=4) (actual time=0.000..0.008 rows=100 loops=402)
         ->  Seq Scan on t2  (cost=0.00..2.00 rows=100 width=4) (actual time=0.005..0.015 rows=100 loops=1)
 Planning Time: 0.083 ms
 Execution Time: 12.035 ms
"#;
    let root = root_of(source);
    let plans = root.get("Plans").unwrap().as_array().unwrap();
    let m = 0.008 * 402.0 - 0.015;
    approx(f(&plans[1], "*Duration (exclusive)"), m);
    let nl = 10.198 - (m + 0.015) - 0.058;
    approx(f(&root, "*Duration (exclusive)"), nl);
}

#[test]
fn actual_durations_parallel_from_json() {
    let source = r#"
[
  { "Plan": {
      "Node Type": "Gather Merge",
      "Parallel Aware": false,
      "Startup Cost": 735306.27,
      "Total Cost": 1707599.95,
      "Plan Rows": 8333364,
      "Actual Startup Time": 1592.880,
      "Actual Total Time": 3805.404,
      "Actual Rows": 10000000,
      "Actual Loops": 1,
      "Workers Planned": 2,
      "Workers Launched": 2,
      "Plans": [
        { "Node Type": "Sort", "Parent Relationship": "Outer",
          "Startup Cost": 734306.25, "Total Cost": 744722.95,
          "Plan Rows": 4166682,
          "Actual Startup Time": 1517.978, "Actual Total Time": 2020.558,
          "Actual Rows": 3333333, "Actual Loops": 3,
          "Plans": [
            { "Node Type": "Seq Scan", "Parent Relationship": "Outer",
              "Parallel Aware": true, "Relation Name": "t1",
              "Startup Cost": 0.00, "Total Cost": 105264.82,
              "Plan Rows": 4166682,
              "Actual Startup Time": 0.214, "Actual Total Time": 400.681,
              "Actual Rows": 3333333, "Actual Loops": 3 } ] } ] },
    "Planning Time": 0.158, "Triggers": [], "Execution Time": 4225.445 }
]
"#;
    let root = root_of(source);
    let sort = &root.get("Plans").unwrap().as_array().unwrap()[0];
    let seq = &sort.get("Plans").unwrap().as_array().unwrap()[0];
    approx(f(seq, "*Duration (exclusive)"), 400.681);
    approx(f(sort, "*Duration (exclusive)"), 2020.558 - 400.681);
}

#[test]
fn parallel_children_loops() {
    let source = r#"
Gather  (cost=1782.55..53030.40 rows=3 width=72) (actual time=70.029..383125.490 rows=367315 loops=1)
    Workers Planned: 3
    Workers Launched: 3
  ->  Nested Loop Left Join  (cost=782.55..52030.10 rows=1 width=72) (actual time=58.605..382365.760 rows=91829 loops=4)
        ->  Parallel Index Scan using bravo_papa_tango on victor_sierra  (cost=0.43..51194.00 rows=1 width=50) (actual time=3.162..122.561 rows=20339 loops=4)
              Index Cond: (whiskey = 'sierra_five'::date)
        ->  Index Scan using yankee on tango  (cost=0.42..2.65 rows=1 width=20) (actual time=0.013..0.013 rows=1 loops=81357)
              Index Cond: (whiskey = 'sierra_five'::date)
        ->  Bitmap Heap Scan on golf  (cost=780.29..826.90 rows=1 width=37) (actual time=17.007..18.601 rows=2 loops=81357)
                ->  BitmapAnd  (cost=780.29..780.29 rows=1583 width=0) (actual time=15.192..15.192 rows=0 loops=81357)
                      ->  Bitmap Index Scan on echo  (cost=0.00..254.44 rows=15129 width=0) (actual time=1.009..1.009 rows=16719 loops=81357)
                            Index Cond: ((whiskey = 'sierra_five'::date))
                      ->  Bitmap Index Scan on mike_uniform  (cost=0.00..523.24 rows=52187 width=0) (actual time=14.023..14.023 rows=284399 loops=81357)
                            Index Cond: ((hotel = tango.hotel))
"#;
    let content = from_source(source).unwrap();
    let plan = create_plan("", content, "").unwrap();
    let node = find_node_by_id(&plan, 6).expect("node 6");
    let d = node.get("*Duration (exclusive)").and_then(|v| v.as_f64()).unwrap();
    assert!(d > 0.0, "duration should be positive, got {}", d);
}

#[test]
fn wal_parsing() {
    let source = r#"
 Limit  (cost=96.31..96.51 rows=10 width=4) (actual time=0.059..0.086 rows=10 loops=1)
   Buffers: shared hit=21
   WAL: records=20 bytes=1320
   CTE x1
     ->  Update on titi  (cost=0.00..96.31 rows=5865 width=10) (actual time=0.056..11.377 rows=5000 loops=1)
           WAL: records=10000 bytes=660000
   ->  CTE Scan on x1  (cost=0.00..117.30 rows=5865 width=4) (actual time=0.058..0.082 rows=10 loops=1)
         WAL: records=20 bytes=1320
 Planning Time: 0.098 ms
 Execution Time: 11.797 ms
"#;
    let root = root_of(source);
    assert_eq!(root.get("WAL Records").and_then(|v| v.as_i64()), Some(20));
    assert_eq!(root.get("WAL Bytes").and_then(|v| v.as_i64()), Some(1320));
    assert_eq!(root.get("WAL FPI").and_then(|v| v.as_i64()), Some(0));
}

#[test]
fn subquery_scan_alias() {
    let source = r#"
 Subquery Scan on foo  (cost=0.00..2.27 rows=1 width=265)
   Filter: (foo.relname = 'aa'::name)
   ->  Limit  (cost=0.00..1.77 rows=40 width=265)
         ->  Seq Scan on pg_class  (cost=0.00..18.10 rows=410 width=265)
(4 rows)
"#;
    let root = root_of(source);
    assert_eq!(root.get("Node Type").and_then(|v| v.as_str()), Some("Subquery Scan"));
    assert_eq!(root.get("Alias").and_then(|v| v.as_str()), Some("foo"));
}

#[test]
fn quoted_last_line() {
    let source = "\"Aggregate  (cost=24729994.62..24729994.63 rows=1 width=8) (actual time=126922.755..126980.072 rows=1 loops=1)\"\n\"  Buffers: shared hit=31033317 read=640327, temp read=271916 written=271928\"\n\"Planning:\"\n\"  Buffers: shared hit=227 read=9\"\n\"Planning Time: 14.620 ms\"\n\"JIT:\"\n\"  Functions: 829\"\n\"  Options: Inlining true, Optimization true, Expressions true, Deforming true\"\n\"  Timing: Generation 113.965 ms, Inlining 706.405 ms, Optimization 7838.603 ms, Emission 7380.843 ms, Total 16039.815 ms\"\n\"Execution Time: 127241.780 ms\"";
    let content = from_source(source).unwrap();
    assert_eq!(content.get("Execution Time").and_then(|v| v.as_f64()), Some(127241.78));
}

#[test]
fn insert_modifytable_text_and_json() {
    let source = r#"
      Insert on foo  (cost=0.00..0.01 rows=1 width=24) (actual time=0.504..0.505 rows=0 loops=1)
        ->  Result  (cost=0.00..0.01 rows=1 width=24) (actual time=0.019..0.020 rows=1 loops=1)
      Planning Time: 0.072 ms
      Trigger foo_system_time_generated_always: time=0.401 calls=1
      Trigger foo_system_time_write_history: time=0.260 calls=1
      Execution Time: 0.842 ms
    "#;
    let root = root_of(source);
    assert_eq!(root.get("Node Type").and_then(|v| v.as_str()), Some("Insert"));

    let source_json = r#"
      [ { "Plan": { "Node Type": "ModifyTable", "Operation": "Insert",
            "Relation Name": "foo", "Alias": "foo",
            "Startup Cost": 0.00, "Total Cost": 0.01, "Plan Rows": 1, "Plan Width": 24,
            "Actual Startup Time": 0.568, "Actual Total Time": 0.568,
            "Actual Rows": 0, "Actual Loops": 1,
            "Plans": [ { "Node Type": "Result", "Parent Relationship": "Member" } ] } } ]
    "#;
    let root2 = root_of(source_json);
    assert_eq!(root2.get("Node Type").and_then(|v| v.as_str()), Some("Insert"));
}

#[test]
fn triggers_parsed() {
    let source = r#"
       Delete on emailmessages  (cost=224.85..38989.92 rows=5000 width=34) (actual time=217158.570..217158.570 rows=0 loops=1)
       ->  Nested Loop  (cost=224.85..38989.92 rows=5000 width=34) (actual time=7.105..4576.019 rows=5000 loops=1)
     Planning time: 2.482 ms
     Trigger for constraint headeremessageref: time=4038.247 calls=5000
     Trigger for constraint formdataemessageref: time=81.415 calls=5000
     Trigger for constraint attachemessageref: time=158945.774 calls=5000
     Trigger for constraint outgoingemessageref: time=332.316 calls=5000
     Trigger for constraint incomingemessageref: time=125.492 calls=5000
     Trigger for constraint eventemessageref: time=251.365 calls=5000
     Trigger for constraint filteredemessageref: time=125.894 calls=5000
     Execution time: 381072.164 ms
    "#;
    let plan = plan_of(source);
    let triggers = plan.get("content").and_then(|c| c.get("Triggers")).and_then(|t| t.as_array()).unwrap();
    assert_eq!(triggers.len(), 7);
}

#[test]
fn parallel_aware_flag() {
    let root = root_of("Seq Scan on tenk1  (cost=0.00..333.00 rows=10000 width=148)");
    assert_eq!(root.get("Parallel Aware").and_then(|v| v.as_bool()), Some(false));
    let root2 = root_of("Parallel Seq Scan on tenk1  (cost=0.00..333.00 rows=10000 width=148)");
    assert_eq!(root2.get("Parallel Aware").and_then(|v| v.as_bool()), Some(true));
}

#[test]
fn planned_partitions_parsing() {
    let source = r#"
      HashAggregate  (cost=13760592.78..14872410.30 rows=1736877 width=61)
        Group Key: ml.offer_type
        Planned Partitions: 128
        ->  Seq Scan on post_merged_listings ml  (cost=0.00..11025300.36 rows=32660208 width=33)
              Filter: (duplicate_id IS NULL)
    "#;
    let content = from_text(source).unwrap();
    let root = content.get("Plan").unwrap();
    assert_eq!(root.get("Planned Partitions").and_then(|v| v.as_i64()), Some(128));
    assert!(root.get("HashAgg Batches").is_none());

    let source2 = r#"
 HashAggregate  (cost=79468.50..98636.70 rows=940257 width=11) (actual time=231.946..413.626 rows=970675 loops=1)
   Group Key: name
   Planned Partitions: 32  Batches: 193  Memory Usage: 4153kB  Disk Usage: 31752kB
   ->  Seq Scan on t1  (cost=0.00..15406.00 rows=1000000 width=11) (actual time=0.118..36.474 rows=1000000 loops=1)
 Planning Time: 0.201 ms
 Execution Time: 438.186 ms
(6 rows)
    "#;
    let content2 = from_text(source2).unwrap();
    let root2 = content2.get("Plan").unwrap();
    assert_eq!(root2.get("Planned Partitions").and_then(|v| v.as_i64()), Some(32));
    assert_eq!(root2.get("HashAgg Batches").and_then(|v| v.as_i64()), Some(193));
    assert_eq!(root2.get("Peak Memory Usage").and_then(|v| v.as_i64()), Some(4153));
    assert_eq!(root2.get("Disk Usage").and_then(|v| v.as_i64()), Some(31752));
}

#[test]
fn plan_without_cost() {
    let source = "Seq Scan on pg_class (actual time=0.013..0.181 rows=645 loops=1)";
    let content = from_source(source).unwrap();
    let plan = create_plan("", content, "").unwrap();
    let content = plan.get("content").unwrap();
    assert_eq!(content.get("maxDuration").and_then(|v| v.as_f64()), Some(0.181));
    assert!(content.get("maxCost").is_none());

    let bad = "Bitmap Heap Scan on a\n   Recheck Cond: ((id = 42))\n";
    let err = from_text(bad).unwrap_err();
    assert_eq!(err, "Unable to parse plan");
}

#[test]
fn json_double_quotes() {
    let source = "\"[\n  {\n    \"\"Plan\"\": {\n      \"\"Node Type\"\": \"\"Seq Scan\"\",\n      \"\"Plan Rows\"\": 5\n    }\n  }\n]\"";
    let content = pev2_core::from_json(source).unwrap();
    let root = content.get("Plan").unwrap();
    assert_eq!(root.get("Node Type").and_then(|v| v.as_str()), Some("Seq Scan"));
}

#[test]
fn query_text_parsing() {
    let source = r#"
  Query Text: SELECT count(*)
              FROM pg_class, pg_index
              WHERE oid = indrelid AND indisunique;
  Aggregate  (cost=16.79..16.80 rows=1 width=0) (actual time=3.626..3.627 rows=1 loops=1)
    ->  Hash Join  (cost=4.17..16.55 rows=92 width=0) (actual time=3.349..3.594 rows=92 loops=1)
          Hash Cond: (pg_class.oid = pg_index.indrelid)
"#;
    let content = from_source(source).unwrap();
    let qt = content.get("Query Text").and_then(|v| v.as_str()).unwrap();
    assert!(qt.contains("WHERE oid = indrelid AND indisunique"), "{}", qt);
}

#[test]
fn io_timings_exclusive_speed() {
    let source = r#"
     Update on a  (cost=0.00..266690.72 rows=0 width=0) (actual time=10.00..11.00 rows=0 loops=1)
         Buffers: shared hit=2 read=4 dirtied=6 written=8
         I/O Timings: read=2 write=4
         ->  Seq Scan on a  (cost=0.00..0.00 rows=10 width=1) (actual time=9.00..10.00 rows=10000000 loops=1)
               Buffers: shared hit=1 read=2 written=4
               I/O Timings: read=1 write=2
    "#;
    let root = root_of(source);
    approx(f(&root, "*I/O Read Time (exclusive)"), 1.0);
    approx(f(&root, "*I/O Read Speed (exclusive)"), 2000.0);
    approx(f(&root, "*I/O Write Time (exclusive)"), 2.0);
    approx(f(&root, "*I/O Write Speed (exclusive)"), 2000.0);
}

#[test]
fn serialization_and_planning() {
    let source = r#"
 Seq Scan on people  (cost=0.00..22.70 rows=1270 width=32) (actual time=0.012..0.030 rows=100.00 loops=1)
   Buffers: shared hit=1
 Planning:
   Buffers: shared hit=6
   Memory: used=6kB  allocated=8kB
 Planning Time: 0.065 ms
 Serialization: time=4.690 ms  output=31251kB  format=text
   Buffers: shared hit=200
 Execution Time: 4.812 ms
(9 rows)
    "#;
    let plan = plan_of(source);
    let content = plan.get("content").unwrap();
    assert_eq!(content.get("Planning Time").and_then(|v| v.as_f64()), Some(0.065));
    let ser = content.get("Serialization").unwrap();
    assert_eq!(ser.get("Time").and_then(|v| v.as_f64()), Some(4.69));
    assert_eq!(ser.get("Output Volume").and_then(|v| v.as_i64()), Some(31251));
    let planning = content.get("Planning").unwrap();
    assert_eq!(planning.get("Shared Hit Blocks").and_then(|v| v.as_i64()), Some(6));
    assert_eq!(planning.get("Shared Read Blocks").and_then(|v| v.as_i64()), Some(0));
    assert_eq!(planning.get("Memory Used").and_then(|v| v.as_i64()), Some(6));
    assert_eq!(planning.get("Memory Allocated").and_then(|v| v.as_i64()), Some(8));
}

#[test]
fn planner_estimate_and_maximums() {
    let source = "Seq Scan on foo  (cost=0.00..1.00 rows=10 width=4) (actual time=0.1..0.2 rows=100 loops=1)";
    let root = root_of(source);
    approx(f(&root, "*Planner Row Estimate Factor"), 10.0);
    approx(f(&root, "*Planner Row Estimate Direction"), 2.0); // under
    let plan = plan_of(source);
    let content = plan.get("content").unwrap();
    approx(f(content, "maxEstimateFactor"), 20.0);

    // estimate default when not analyzed
    let plan2 = plan_of("Seq Scan on foo  (cost=0.00..1.00 rows=10 width=4)");
    let content2 = plan2.get("content").unwrap();
    approx(f(content2, "maxEstimateFactor"), 1.0);
}

#[test]
fn max_blocks_and_max_io() {
    let source = r#"
     Update on a  (cost=0.00..266690.72 rows=0 width=0) (actual time=10.00..11.00 rows=0 loops=1)
         Buffers: shared hit=2 read=4 dirtied=6 written=8
         I/O Timings: read=2 write=4
         ->  Seq Scan on a  (cost=0.00..0.00 rows=10 width=1) (actual time=9.00..10.00 rows=10000000 loops=1)
               Buffers: shared hit=1 read=2 written=4
               I/O Timings: read=1 write=2
    "#;
    let plan = plan_of(source);
    let content = plan.get("content").unwrap();
    approx(f(content, "maxIo"), 3.0);
    let blocks = content.get("maxBlocks").unwrap();
    approx(f(blocks, "Shared"), 13.0);
}

#[test]
fn cte_helpers_and_visibility() {
    let source = r#"
                            QUERY PLAN
------------------------------------------------------------------
 Aggregate  (cost=38.51..38.52 rows=1 width=4)
   CTE e
     ->  Seq Scan on employes  (cost=0.00..38.25 rows=11 width=8)
           Filter: (num_service = 4)
   ->  CTE Scan on e  (cost=0.00..0.25 rows=4 width=4)
         Filter: (date_embauche < '2006-01-01'::date)
(6 rows)
"#;
    let content = from_source(source).unwrap();
    let plan = create_plan("", content, "").unwrap();
    assert!(pev2_core::find_node_by_subplan_name(&plan, "e").is_some());
    assert!(pev2_core::find_node_by_subplan_name(&plan, "missing").is_none());
    assert!(pev2_core::find_node_by_id(&plan, 1).is_some());
    assert!(pev2_core::should_show_prop("Filter", &serde_json::json!("(a = 1)")));
    assert!(!pev2_core::should_show_prop("Filter", &serde_json::json!("")));
    assert!(!pev2_core::should_show_prop("Node Type", &serde_json::json!("Seq Scan")));
    assert!(!pev2_core::should_show_prop("Actual Rows", &serde_json::json!(0)));
}

#[test]
fn psql_frames_all_parse() {
    let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../../src/services/__tests__/11-psql-frames");
    let mut failures = Vec::new();
    for entry in std::fs::read_dir(&dir).unwrap() {
        let path = entry.unwrap().path();
        let text = std::fs::read_to_string(&path).unwrap();
        if let Err(e) = from_source(&text) {
            failures.push(format!("{:?}: {}", path.file_name().unwrap(), e));
        }
    }
    assert!(failures.is_empty(), "{}", failures.join("\n"));
}

#[test]
fn invalid_plan_errors() {
    assert_eq!(from_text("not a plan").unwrap_err(), "Unable to parse plan");
    let err = pev2_core::get_plan_content(&serde_json::json!({"foo": 1})).unwrap_err();
    assert_eq!(err, "Invalid plan");
}

#[test]
fn is_verbose_sees_output_inside_cte_subplan() {
    let source = r#"
[
  { "Plan": {
      "Node Type": "Aggregate",
      "Startup Cost": 38.51, "Total Cost": 38.52,
      "Plan Rows": 1, "Plan Width": 4,
      "Plans": [
        { "Node Type": "Seq Scan", "Parent Relationship": "InitPlan",
          "Subplan Name": "CTE e", "Relation Name": "employes",
          "Startup Cost": 0.00, "Total Cost": 38.25,
          "Plan Rows": 11, "Plan Width": 8,
          "Output": ["num_service"] },
        { "Node Type": "CTE Scan", "Parent Relationship": "Outer",
          "CTE Name": "e",
          "Startup Cost": 0.00, "Total Cost": 0.25,
          "Plan Rows": 4, "Plan Width": 4 }
      ] } }
]
"#;
    let plan = plan_of(source);
    assert_eq!(plan.get("isVerbose").and_then(|v| v.as_bool()), Some(true));
    let ctes = plan.get("ctes").unwrap().as_array().unwrap();
    assert_eq!(ctes.len(), 1);
    let root_plans = plan
        .get("content")
        .unwrap()
        .get("Plan")
        .unwrap()
        .get("Plans")
        .unwrap()
        .as_array()
        .unwrap();
    assert!(!root_plans.iter().any(|c| c.get("Output").is_some()));
}

#[test]
fn hash_key_splits_on_comma_without_space() {
    let source = r#"
 Nested Loop  (cost=0.00..1.00 rows=1 width=4)
   ->  Seq Scan on t  (cost=0.00..1.00 rows=1 width=4)
         Hash Key: a,b
"#;
    let root = root_of(source);
    let child = &root.get("Plans").unwrap().as_array().unwrap()[0];
    let hash_keys = child
        .get("Grouping Sets")
        .and_then(|v| v.as_array())
        .and_then(|a| a.first())
        .and_then(|s| s.get("Hash Keys"))
        .and_then(|v| v.as_array())
        .and_then(|a| a.first())
        .and_then(|v| v.as_array())
        .expect("hash keys");
    assert_eq!(hash_keys.len(), 2);
    assert_eq!(hash_keys[0].as_str(), Some("a"));
    assert_eq!(hash_keys[1].as_str(), Some("b"));
}
