//! Port of `cleanupSource`, `splitIntoLines`, `fromSource`, `fromJson` and
//! `getPlanContent` from `plan-service.ts`.

use std::sync::OnceLock;

use fancy_regex::Regex as FancyRegex;
use regex::Regex;
use serde_json::Value;

use crate::model::PlanContent;
use crate::parse_text::from_text;

fn fancy(pattern: &str) -> FancyRegex {
    FancyRegex::new(pattern).expect("valid regex")
}

fn plain(pattern: &str) -> Regex {
    Regex::new(pattern).expect("valid regex")
}

/// Ordered source cleanup, faithfully reproducing `cleanupSource`.
pub fn cleanup_source(source: &str) -> String {
    // Remove frames around the line (handles |, ║), using a backreference.
    static FRAME_AROUND: OnceLock<FancyRegex> = OnceLock::new();
    let re = FRAME_AROUND.get_or_init(|| fancy(r"(?m)^(\||║|│)(.*)\1\r?\n"));
    let source = re.replace_all(source, "$2\n");

    // Remove frames at the end of the line.
    static FRAME_END: OnceLock<Regex> = OnceLock::new();
    let re = FRAME_END.get_or_init(|| plain(r"(?m)^(.*)(\||║|│)$\r?\n"));
    let source = re.replace_all(&source, "$1\n");

    // Remove separator lines from various types of borders.
    static SEP1: OnceLock<Regex> = OnceLock::new();
    let re = SEP1.get_or_init(|| plain(r"(?m)^\+-+\+\r?\n"));
    let source = re.replace_all(&source, "");

    static SEP2: OnceLock<FancyRegex> = OnceLock::new();
    let re = SEP2.get_or_init(|| fancy(r"(?m)^(-|─|═)\1+\r?\n"));
    let source = re.replace_all(&source, "");

    static SEP3: OnceLock<FancyRegex> = OnceLock::new();
    let re = SEP3.get_or_init(|| fancy(r"(?m)^(├|╟|╠|╞)(─|═)\2*(┤|╢|╣|╡)\r?\n"));
    let source = re.replace_all(&source, "");

    // Remove more horizontal lines.
    static SEP4: OnceLock<Regex> = OnceLock::new();
    let re = SEP4.get_or_init(|| plain(r"(?m)^\+-+\+\r?\n"));
    let source = re.replace_all(&source, "");

    static SEP5: OnceLock<Regex> = OnceLock::new();
    let re = SEP5.get_or_init(|| plain(r"(?m)^└(─)+┘\r?\n"));
    let source = re.replace_all(&source, "");

    static SEP6: OnceLock<Regex> = OnceLock::new();
    let re = SEP6.get_or_init(|| plain(r"(?m)^╚(═)+╝\r?\n"));
    let source = re.replace_all(&source, "");

    static SEP7: OnceLock<Regex> = OnceLock::new();
    let re = SEP7.get_or_init(|| plain(r"(?m)^┌(─)+┐\r?\n"));
    let source = re.replace_all(&source, "");

    static SEP8: OnceLock<Regex> = OnceLock::new();
    let re = SEP8.get_or_init(|| plain(r"(?m)^╔(═)+╗\r?\n"));
    let source = re.replace_all(&source, "");

    // Remove quotes around lines, both ' and ", using a backreference.
    static QUOTES: OnceLock<FancyRegex> = OnceLock::new();
    let re = QUOTES.get_or_init(|| fancy(r#"(?m)^(["'])(.*)\1\r?"#));
    let source = re.replace_all(&source, "$2");

    // Remove "+" line continuations.
    static PLUS: OnceLock<Regex> = OnceLock::new();
    let re = PLUS.get_or_init(|| plain(r"\s*\+\r?\n"));
    let source = re.replace_all(&source, "\n");

    // Remove "↵" line continuations.
    static CR: OnceLock<Regex> = OnceLock::new();
    let re = CR.get_or_init(|| plain(r"(?m)↵\r?"));
    let source = re.replace_all(&source, "\n");

    // Remove "query plan" header.
    static HEADER: OnceLock<Regex> = OnceLock::new();
    let re = HEADER.get_or_init(|| plain(r"(?m)^\s*QUERY PLAN\s*\r?\n"));
    let source = re.replace_all(&source, "");

    // Remove trailing rowcount line, e.g. "(8 rows)".
    static ROWCOUNT: OnceLock<Regex> = OnceLock::new();
    let re = ROWCOUNT.get_or_init(|| plain(r"(?m)^\(\d+\s+[a-z]*s?\)(\r?\n|$)"));
    let source = re.replace_all(&source, "\n");

    source.into_owned()
}

fn json_like(source: &str) -> bool {
    static RE: OnceLock<FancyRegex> = OnceLock::new();
    let re = RE.get_or_init(|| fancy(r"(?ms)^(\s*)(\[|\{)\s*\n.*?\1(\]|\})\s*"));
    re.is_match(source).unwrap_or(false)
}

/// Parse `EXPLAIN` output as text or JSON, mirroring `fromSource`.
pub fn from_source(source: &str) -> Result<PlanContent, String> {
    let source = cleanup_source(source);
    if let Ok(data) = serde_json::from_str::<Value>(&source) {
        if let Ok(content) = get_plan_content(&data) {
            return Ok(content);
        }
    }
    if json_like(&source) {
        return from_json(&source);
    }
    from_text(&source)
}

/// Extract the plan content from a parsed JSON value, mirroring `getPlanContent`.
pub fn get_plan_content(mut value: &Value) -> Result<PlanContent, String> {
    if let Value::Array(arr) = value {
        value = arr.first().ok_or_else(|| "Invalid plan".to_string())?;
    }
    match get_obj_truthy(value) {
        Some(obj) => Ok(obj.clone()),
        None => Err("Invalid plan".to_string()),
    }
}

fn get_obj_truthy(value: &Value) -> Option<&crate::model::JsonMap> {
    let obj = get_obj_value(value)?;
    match obj.get("Plan") {
        Some(p) => match p {
            Value::Null => None,
            Value::Bool(b) => {
                if *b {
                    Some(obj)
                } else {
                    None
                }
            }
            _ => Some(obj),
        },
        None => None,
    }
}

fn get_obj_value(value: &Value) -> Option<&crate::model::JsonMap> {
    match value {
        Value::Object(o) => Some(o),
        _ => None,
    }
}

/// Build plan content from JSON embedded in text, mirroring `fromJson`.
pub fn from_json(source: &str) -> Result<PlanContent, String> {
    let source_lines: Vec<&str> = split_js_lines(source);

    let open_re = plain(r"^(\s*)(\[|\{)\s*$");
    let mut prefix = String::new();
    let mut first_line_index = 0usize;
    for (index, line) in source_lines.iter().enumerate() {
        if let Some(caps) = open_re.captures(line) {
            prefix = caps.get(1).map(|m| m.as_str().to_string()).unwrap_or_default();
            first_line_index = index;
            break;
        }
    }

    // Note: the TypeScript code builds `new RegExp("^" + prefix + "(]|})s*$")`,
    // i.e. the `s*` is a literal 's' run (not \s*). Reproduce that exactly.
    let close_pattern = format!(r"^{}(]|}})s*$", regex::escape(&prefix));
    let close_re = plain(&close_pattern);
    let mut last_line_index = 0usize;
    for (index, line) in source_lines.iter().enumerate() {
        if close_re.is_match(line) {
            last_line_index = index;
            break;
        }
    }

    let slice = if first_line_index <= last_line_index && last_line_index < source_lines.len() {
        source_lines[first_line_index..=last_line_index].join("\n")
    } else {
        String::new()
    };
    let use_source = slice.replace("\"\"", "\"");
    let data: Value = serde_json::from_str(&use_source).map_err(|e| e.to_string())?;
    get_plan_content(&data)
}

fn split_js_lines(text: &str) -> Vec<&str> {
    // JS `source.split(/[\r\n]+/)` splits on runs of \r or \n.
    let mut result = Vec::new();
    let mut start = 0usize;
    let bytes = text.as_bytes();
    let mut i = 0usize;
    while i < bytes.len() {
        if bytes[i] == b'\r' || bytes[i] == b'\n' {
            result.push(&text[start..i]);
            while i < bytes.len() && (bytes[i] == b'\r' || bytes[i] == b'\n') {
                i += 1;
            }
            start = i;
        } else {
            i += 1;
        }
    }
    result.push(&text[start..]);
    result
}

/// Split text into logical lines, rejoining force-wrapped lines.
pub fn split_into_lines(text: &str) -> Vec<String> {
    let lines: Vec<String> = text
        .split('\n')
        .map(|l| l.strip_suffix('\r').unwrap_or(l).to_string())
        .collect();

    let info_re = plain(
        r"^(?:Total\s+runtime|Planning(\s+time)?|Execution\s+time|Time|Filter|Output|JIT|Trigger|Settings|Serialization)",
    );
    let info_re_i = Regex::new(&format!("(?i){}", info_re.as_str())).unwrap();
    let starts_nonblank = plain(r"^\S");
    let starts_paren = plain(r"^\s*\(");
    let prev_list = plain(r"^.*,\s*$");
    let arrow = plain(r"(?i)^\s*->");

    let mut out: Vec<String> = Vec::new();
    for line in &lines {
        let previous = out.last().cloned();
        if let Some(prev) = &previous {
            if count(prev, ')') != count(prev, '(') {
                out.last_mut().unwrap().push_str(line);
                continue;
            }
        }
        if info_re_i.is_match(line) {
            out.push(line.clone());
        } else if starts_nonblank.is_match(line) || starts_paren.is_match(line) || closing_first(line)
        {
            if !out.is_empty() {
                out.last_mut().unwrap().push_str(line);
            } else {
                out.push(line.clone());
            }
        } else if let Some(prev) = &previous {
            if !out.is_empty()
                && prev_list.is_match(prev)
                && !same_indent(prev, line)
                && !arrow.is_match(line)
            {
                out.last_mut().unwrap().push_str(line);
            } else {
                out.push(line.clone());
            }
        } else {
            out.push(line.clone());
        }
    }
    out
}

fn count(s: &str, c: char) -> usize {
    s.chars().filter(|&x| x == c).count()
}

fn closing_first(s: &str) -> bool {
    let closing = s.find(')');
    let opening = s.find('(');
    match closing {
        Some(c) => match opening {
            Some(o) => c < o,
            None => false,
        },
        None => false,
    }
}

fn same_indent(l1: &str, l2: &str) -> bool {
    first_non_ws(l1) == first_non_ws(l2)
}

fn first_non_ws(s: &str) -> i64 {
    for (i, c) in s.chars().enumerate() {
        if !c.is_whitespace() {
            return i as i64;
        }
    }
    -1
}
