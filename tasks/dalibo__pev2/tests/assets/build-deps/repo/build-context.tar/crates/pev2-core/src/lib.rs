//! pev2-core: native Rust reimplementation of the pev2 plan parsing and metric
//! computation currently provided by `src/services/plan-service.ts`,
//! `src/services/help-service.ts`, `src/enums.ts` and `src/interfaces.ts`.

pub mod help;
pub mod metrics;
pub mod model;
pub mod node_type;
pub mod parse_text;
pub mod property;
pub mod source;

#[cfg(target_arch = "wasm32")]
pub mod wasm;

pub use help::{
    find_node_by_id, find_node_by_subplan_name, find_output_property, should_show_prop,
    split_balanced,
};
pub use metrics::create_plan;
pub use model::{JsonMap, Node, Plan, PlanContent};
pub use node_type::parse_node_type;
pub use parse_text::from_text;
pub use source::{cleanup_source, from_json, from_source, get_plan_content, split_into_lines};

/// Mirror of `PlanService.fromSource`.
pub fn from_source_text(source: &str) -> Result<PlanContent, String> {
    from_source(source)
}

/// Mirror of `PlanService.createPlan`.
pub fn create_plan_envelope(
    plan_name: &str,
    plan_content: PlanContent,
    plan_query: &str,
) -> Result<Plan, String> {
    create_plan(plan_name, plan_content, plan_query)
}
