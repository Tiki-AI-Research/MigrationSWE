//! Dynamic JSON model. The TypeScript implementation relies on plain objects
//! with arbitrary string keys; the closest faithful Rust representation is a
//! `serde_json::Map`, which also guarantees JSON-serializable output with the
//! exact key strings.

use serde_json::{Map, Value};

pub type JsonMap = Map<String, Value>;
/// A plan node is a dynamic property bag.
pub type Node = JsonMap;
/// The parsed plan content (`IPlanContent`).
pub type PlanContent = JsonMap;
/// The `IPlan` envelope returned by `createPlan`.
pub type Plan = JsonMap;

pub fn obj() -> JsonMap {
    Map::new()
}

pub fn get<'a>(m: &'a JsonMap, key: &str) -> Option<&'a Value> {
    m.get(key)
}

pub fn get_f64(m: &JsonMap, key: &str) -> Option<f64> {
    match m.get(key) {
        Some(Value::Number(n)) => n.as_f64(),
        _ => None,
    }
}

pub fn get_i64(m: &JsonMap, key: &str) -> Option<i64> {
    match m.get(key) {
        Some(Value::Number(n)) => {
            if let Some(i) = n.as_i64() {
                Some(i)
            } else {
                n.as_f64().map(|f| f as i64)
            }
        }
        _ => None,
    }
}

pub fn get_str<'a>(m: &'a JsonMap, key: &str) -> Option<&'a str> {
    match m.get(key) {
        Some(Value::String(s)) => Some(s.as_str()),
        _ => None,
    }
}

pub fn get_bool(m: &JsonMap, key: &str) -> Option<bool> {
    match m.get(key) {
        Some(Value::Bool(b)) => Some(*b),
        _ => None,
    }
}

pub fn get_arr<'a>(m: &'a JsonMap, key: &str) -> Option<&'a Vec<Value>> {
    match m.get(key) {
        Some(Value::Array(a)) => Some(a),
        _ => None,
    }
}

pub fn get_obj<'a>(m: &'a JsonMap, key: &str) -> Option<&'a JsonMap> {
    match m.get(key) {
        Some(Value::Object(o)) => Some(o),
        _ => None,
    }
}

pub fn set_num(m: &mut JsonMap, key: &str, v: f64) {
    m.insert(key.to_string(), Value::from(v));
}

pub fn set_i64(m: &mut JsonMap, key: &str, v: i64) {
    m.insert(key.to_string(), Value::from(v));
}

pub fn set_str(m: &mut JsonMap, key: &str, v: impl Into<String>) {
    m.insert(key.to_string(), Value::String(v.into()));
}

pub fn set_bool(m: &mut JsonMap, key: &str, v: bool) {
    m.insert(key.to_string(), Value::Bool(v));
}

pub fn set_value(m: &mut JsonMap, key: &str, v: Value) {
    m.insert(key.to_string(), v);
}

/// Returns true when the key is present, regardless of the (possibly null)
/// value, mirroring `_.has`.
pub fn has(m: &JsonMap, key: &str) -> bool {
    m.contains_key(key)
}

/// `startCase` equivalent from lodash: split words on non-alphanumeric
/// boundaries and camelCase transitions, then capitalise each word.
pub fn start_case(input: &str) -> String {
    let mut words: Vec<String> = Vec::new();
    let mut current = String::new();
    let chars: Vec<char> = input.chars().collect();
    for (i, &c) in chars.iter().enumerate() {
        if c.is_alphanumeric() {
            // camelCase transition: lower/digit followed by upper
            if c.is_uppercase() {
                if let Some(prev) = current.chars().last() {
                    if prev.is_lowercase() || prev.is_numeric() {
                        words.push(current.clone());
                        current.clear();
                    }
                }
            }
            current.push(c);
        } else {
            if !current.is_empty() {
                words.push(current.clone());
                current.clear();
            }
        }
        let _ = i;
    }
    if !current.is_empty() {
        words.push(current);
    }
    words
        .into_iter()
        .map(|w| {
            let mut cs = w.chars();
            match cs.next() {
                Some(first) => {
                    let mut s = String::new();
                    s.extend(first.to_uppercase());
                    s.push_str(&cs.as_str().to_lowercase());
                    s
                }
                None => String::new(),
            }
        })
        .collect::<Vec<_>>()
        .join(" ")
}

/// lodash `capitalize`: first char upper-cased, remaining lower-cased.
pub fn capitalize(input: &str) -> String {
    let mut cs = input.chars();
    match cs.next() {
        Some(first) => {
            let mut s = String::new();
            s.extend(first.to_uppercase());
            s.push_str(&cs.as_str().to_lowercase());
            s
        }
        None => String::new(),
    }
}

/// lodash `upperCase` is only used to build `SCREAMING_SNAKE` property lookup
/// keys: upper-case and split words with underscores.
pub fn upper_case(input: &str) -> String {
    let mut words: Vec<String> = Vec::new();
    let mut current = String::new();
    for c in input.chars() {
        if c.is_alphanumeric() {
            if c.is_uppercase() {
                if let Some(prev) = current.chars().last() {
                    if prev.is_lowercase() || prev.is_numeric() {
                        words.push(current.clone());
                        current.clear();
                    }
                }
            }
            current.push(c);
        } else if !current.is_empty() {
            words.push(current.clone());
            current.clear();
        }
    }
    if !current.is_empty() {
        words.push(current);
    }
    words
        .into_iter()
        .map(|w| w.to_uppercase())
        .collect::<Vec<_>>()
        .join(" ")
}

/// Equivalent of `Number(x.toFixed(3))`: round half away from zero to three
/// decimals, matching JavaScript's `toFixed` for the positive values used here.
pub fn to_fixed3(v: f64) -> f64 {
    if !v.is_finite() {
        return v;
    }
    let rounded = format!("{:.3}", v);
    rounded.parse::<f64>().unwrap_or(v)
}

/// Parse a leading float like JavaScript `parseFloat` (returns None when no
/// numeric prefix exists).
pub fn parse_float(s: &str) -> Option<f64> {
    let t = s.trim_start();
    let bytes = t.as_bytes();
    let mut seen_digit = false;
    let mut i = 0;
    if i < bytes.len() && (bytes[i] == b'+' || bytes[i] == b'-') {
        i += 1;
    }
    // Infinity / NaN
    if t[i..].starts_with("Infinity") || t[i..].starts_with("NaN") {
        return match t[i..].chars().next() {
            Some('I') => Some(f64::INFINITY),
            Some('N') => Some(f64::NAN),
            _ => None,
        };
    }
    while i < bytes.len() && bytes[i].is_ascii_digit() {
        seen_digit = true;
        i += 1;
    }
    if i < bytes.len() && bytes[i] == b'.' {
        i += 1;
        while i < bytes.len() && bytes[i].is_ascii_digit() {
            seen_digit = true;
            i += 1;
        }
    }
    if !seen_digit {
        return None;
    }
    if i < bytes.len() && (bytes[i] == b'e' || bytes[i] == b'E') {
        let mut j = i + 1;
        if j < bytes.len() && (bytes[j] == b'+' || bytes[j] == b'-') {
            j += 1;
        }
        let mut exp_digit = false;
        while j < bytes.len() && bytes[j].is_ascii_digit() {
            exp_digit = true;
            j += 1;
        }
        if exp_digit {
            i = j;
        }
    }
    t[..i].parse::<f64>().ok()
}

/// JavaScript `parseInt(value, 0)`: parse leading integer, ignore trailing junk.
pub fn parse_int(s: &str) -> Option<i64> {
    let t = s.trim_start();
    let bytes = t.as_bytes();
    let mut i = 0;
    if i < bytes.len() && (bytes[i] == b'+' || bytes[i] == b'-') {
        i += 1;
    }
    let start_digits = i;
    while i < bytes.len() && bytes[i].is_ascii_digit() {
        i += 1;
    }
    if i == start_digits {
        return None;
    }
    t[..i].parse::<i64>().ok()
}
