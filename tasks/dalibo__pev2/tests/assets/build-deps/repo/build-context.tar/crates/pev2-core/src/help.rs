//! Port of the in-scope exported helpers from `src/services/help-service.ts`.

use serde_json::Value;

use crate::model::{get_arr, get_obj, get_str, JsonMap, Node, Plan};
use crate::property as P;

/// Split `input` on `split` while keeping bracketed and quoted regions intact.
/// Faithful port of the regex-driven tokenizer in `help-service.ts`.
pub fn split_balanced(input: &str, split: &str) -> Vec<String> {
    let split_chars: Vec<char> = split.chars().collect();
    let chars: Vec<char> = input.chars().collect();
    let n = chars.len();
    let mut stack: Vec<char> = Vec::new();
    let mut buffer = String::new();
    let mut results: Vec<String> = Vec::new();
    let mut i = 0usize;

    let is_token = |c: char| -> bool {
        matches!(c, '(' | '{' | '[' | ')' | '}' | ']' | '\'' | '"') || split_chars.contains(&c)
    };
    let is_open = |c: char| matches!(c, '(' | '{' | '[');
    let is_close = |c: char| matches!(c, ')' | '}' | ']');
    let is_quote = |c: char| matches!(c, '\'' | '"');

    while i <= n {
        if i == n {
            results.push(buffer.clone());
            buffer.clear();
            break;
        }
        // Find the next token at or after i.
        let mut j = i;
        let mut found: Option<(usize, bool, char)> = None;
        while j < n {
            let c = chars[j];
            if c == '\\' && j + 1 < n && is_token(chars[j + 1]) {
                found = Some((j, true, chars[j + 1]));
                break;
            }
            if is_token(c) {
                found = Some((j, false, c));
                break;
            }
            j += 1;
        }

        match found {
            None => {
                buffer.push_str(&chars[i..n].iter().collect::<String>());
                results.push(buffer.clone());
                buffer.clear();
                break;
            }
            Some((pos, escape, tok)) => {
                if escape {
                    buffer.push_str(&chars[i..pos].iter().collect::<String>());
                    buffer.push(tok);
                    i = pos + 2;
                } else if is_open(tok) {
                    stack.push(tok);
                    buffer.push_str(&chars[i..=pos].iter().collect::<String>());
                    i = pos + 1;
                } else if is_close(tok) {
                    stack.pop();
                    buffer.push_str(&chars[i..=pos].iter().collect::<String>());
                    i = pos + 1;
                } else if is_quote(tok) {
                    if stack.last() != Some(&tok) {
                        stack.push(tok);
                    } else {
                        stack.pop();
                    }
                    buffer.push_str(&chars[i..=pos].iter().collect::<String>());
                    i = pos + 1;
                } else if stack.is_empty() {
                    buffer.push_str(&chars[i..pos].iter().collect::<String>());
                    results.push(buffer.clone());
                    buffer.clear();
                    i = pos + 1;
                } else {
                    buffer.push_str(&chars[i..=pos].iter().collect::<String>());
                    i = pos + 1;
                }
            }
        }
    }

    results
}

fn node_children(node: &Node) -> Option<&Vec<Value>> {
    get_arr(node, P::PLANS)
}

fn search_children(children: &[Value], id: i64) -> Option<Node> {
    for child in children {
        if let Value::Object(c) = child {
            if crate::model::get_f64(c, P::NODE_ID).map(|v| v as i64) == Some(id) {
                return Some(c.clone());
            }
            if let Some(grand) = node_children(c) {
                if let Some(found) = search_children(grand, id) {
                    return Some(found);
                }
            }
        }
    }
    None
}

/// Recursive `nodeId` lookup including CTEs.
pub fn find_node_by_id(plan: &Plan, id: i64) -> Option<Node> {
    let content = get_obj(plan, "content")?;
    let root = get_obj(content, "Plan")?;
    if crate::model::get_f64(root, P::NODE_ID).map(|v| v as i64) == Some(id) {
        return Some(root.clone());
    }
    if let Some(children) = get_arr(root, P::PLANS) {
        if let Some(found) = search_children(children, id) {
            return Some(found);
        }
    }
    if let Some(ctes) = get_arr(plan, "ctes") {
        for cte in ctes {
            if let Value::Object(c) = cte {
                if crate::model::get_f64(c, P::NODE_ID).map(|v| v as i64) == Some(id) {
                    return Some(c.clone());
                }
                if let Some(children) = get_arr(c, P::PLANS) {
                    if let Some(found) = search_children(children, id) {
                        return Some(found);
                    }
                }
            }
        }
    }
    None
}

/// CTE subplan name lookup.
pub fn find_node_by_subplan_name(plan: &Plan, subplan_name: &str) -> Option<Node> {
    let ctes = get_arr(plan, "ctes")?;
    let wanted = format!("CTE {}", subplan_name);
    for cte in ctes {
        if let Value::Object(c) = cte {
            if get_str(c, P::SUBPLAN_NAME) == Some(wanted.as_str()) {
                return Some(c.clone());
            }
        }
    }
    None
}

/// Returns the list of properties that have already been displayed elsewhere.
pub fn not_misc_properties() -> &'static [&'static str] {
    &[
        P::NODE_TYPE,
        P::CTE_NAME,
        P::EXCLUSIVE_DURATION,
        P::EXCLUSIVE_COST,
        P::TOTAL_COST,
        P::PLAN_ROWS,
        P::ACTUAL_ROWS,
        P::ACTUAL_LOOPS,
        P::OUTPUT,
        P::WORKERS,
        P::WORKERS_PLANNED,
        P::WORKERS_LAUNCHED,
        P::WORKERS_PLANNED_BY_GATHER,
        P::WORKERS_LAUNCHED_BY_GATHER,
        P::READ_BLOCKS,
        P::WRITTEN_BLOCKS,
        P::EXCLUSIVE_SHARED_HIT_BLOCKS,
        P::EXCLUSIVE_SHARED_READ_BLOCKS,
        P::EXCLUSIVE_SHARED_DIRTIED_BLOCKS,
        P::EXCLUSIVE_SHARED_WRITTEN_BLOCKS,
        P::EXCLUSIVE_TEMP_READ_BLOCKS,
        P::EXCLUSIVE_TEMP_WRITTEN_BLOCKS,
        P::EXCLUSIVE_LOCAL_HIT_BLOCKS,
        P::EXCLUSIVE_LOCAL_READ_BLOCKS,
        P::EXCLUSIVE_LOCAL_DIRTIED_BLOCKS,
        P::EXCLUSIVE_LOCAL_WRITTEN_BLOCKS,
        P::EXCLUSIVE_READ_BLOCKS,
        P::EXCLUSIVE_WRITTEN_BLOCKS,
        P::SHARED_HIT_BLOCKS,
        P::SHARED_READ_BLOCKS,
        P::SHARED_DIRTIED_BLOCKS,
        P::SHARED_WRITTEN_BLOCKS,
        P::TEMP_READ_BLOCKS,
        P::TEMP_WRITTEN_BLOCKS,
        P::LOCAL_HIT_BLOCKS,
        P::LOCAL_READ_BLOCKS,
        P::LOCAL_DIRTIED_BLOCKS,
        P::LOCAL_WRITTEN_BLOCKS,
        P::PLANNER_ESTIMATE_FACTOR,
        P::PLANNER_ESTIMATE_DIRECTION,
        P::SUBPLAN_NAME,
        P::GROUP_KEY,
        P::HASH_CONDITION,
        P::JOIN_TYPE,
        P::INDEX_NAME,
        P::HASH_CONDITION,
        P::EXCLUSIVE_IO_READ_TIME,
        P::EXCLUSIVE_IO_WRITE_TIME,
        P::EXCLUSIVE_SHARED_IO_READ_TIME,
        P::EXCLUSIVE_SHARED_IO_WRITE_TIME,
        P::EXCLUSIVE_LOCAL_IO_READ_TIME,
        P::EXCLUSIVE_LOCAL_IO_WRITE_TIME,
        P::EXCLUSIVE_TEMP_IO_READ_TIME,
        P::EXCLUSIVE_TEMP_IO_WRITE_TIME,
        P::EXCLUSIVE_AVERAGE_IO_READ_SPEED,
        P::EXCLUSIVE_AVERAGE_IO_WRITE_SPEED,
        P::EXCLUSIVE_AVERAGE_SHARED_IO_READ_SPEED,
        P::EXCLUSIVE_AVERAGE_SHARED_IO_WRITE_SPEED,
        P::EXCLUSIVE_AVERAGE_LOCAL_IO_READ_SPEED,
        P::EXCLUSIVE_AVERAGE_LOCAL_IO_WRITE_SPEED,
        P::EXCLUSIVE_AVERAGE_TEMP_IO_READ_SPEED,
        P::EXCLUSIVE_AVERAGE_TEMP_IO_WRITE_SPEED,
        P::EXCLUSIVE_AVERAGE_IO_READ_SPEED,
        P::EXCLUSIVE_AVERAGE_IO_WRITE_SPEED,
        P::EXCLUSIVE_SUM_IO_READ_TIME,
        P::EXCLUSIVE_SUM_IO_WRITE_TIME,
        P::EXCLUSIVE_AVERAGE_SUM_IO_READ_SPEED,
        P::EXCLUSIVE_AVERAGE_SUM_IO_WRITE_SPEED,
        P::AVERAGE_IO_READ_SPEED,
        P::AVERAGE_IO_WRITE_SPEED,
        P::AVERAGE_SHARED_IO_READ_SPEED,
        P::AVERAGE_SHARED_IO_WRITE_SPEED,
        P::AVERAGE_LOCAL_IO_READ_SPEED,
        P::AVERAGE_LOCAL_IO_WRITE_SPEED,
        P::AVERAGE_TEMP_IO_READ_SPEED,
        P::AVERAGE_TEMP_IO_WRITE_SPEED,
        P::IO_READ_TIME,
        P::IO_WRITE_TIME,
        P::SHARED_IO_READ_TIME,
        P::SHARED_IO_WRITE_TIME,
        P::LOCAL_IO_READ_TIME,
        P::LOCAL_IO_WRITE_TIME,
        P::TEMP_IO_READ_TIME,
        P::TEMP_IO_WRITE_TIME,
        P::SUM_IO_READ_TIME,
        P::SUM_IO_WRITE_TIME,
        P::AVERAGE_SUM_IO_READ_SPEED,
        P::AVERAGE_SUM_IO_WRITE_SPEED,
        P::HEAP_FETCHES,
        P::WAL_RECORDS,
        P::WAL_BYTES,
        P::WAL_FPI,
        P::NODE_ID,
        P::ROWS_REMOVED_BY_FILTER,
        P::ROWS_REMOVED_BY_JOIN_FILTER,
        P::ROWS_REMOVED_BY_INDEX_RECHECK,
        P::ACTUAL_ROWS_REVISED,
        P::PLAN_ROWS_REVISED,
        P::ROWS_REMOVED_BY_FILTER_REVISED,
        P::ROWS_REMOVED_BY_JOIN_FILTER_REVISED,
        P::ROWS_REMOVED_BY_INDEX_RECHECK_REVISED,
        "size",
        P::RELATION_NAME,
        P::ALIAS,
        P::FUNCTION_NAME,
        P::STRATEGY,
        P::PARTIAL_MODE,
        P::SCAN_DIRECTION,
        P::ACTUAL_ROWS_FRACTIONAL,
        P::DISABLED,
        P::WORKER_NUMBER,
        P::ASYNC_CAPABLE,
    ]
}

pub fn js_truthy(value: &Value) -> bool {
    match value {
        Value::Null => false,
        Value::Bool(b) => *b,
        Value::Number(n) => n.as_f64().map(|f| f != 0.0 && !f.is_nan()).unwrap_or(false),
        Value::String(s) => !s.is_empty(),
        Value::Array(_) | Value::Object(_) => true,
    }
}

/// Visibility filtering used by the misc property panel.
pub fn should_show_prop(key: &str, value: &Value) -> bool {
    (js_truthy(value) || key == P::WORKER_NUMBER || key == P::ACTUAL_ROWS)
        && !not_misc_properties().contains(&key)
}

/// Recursively look for an "Output" property among descendants.
pub fn find_output_property(node: &JsonMap) -> bool {
    let children = match get_arr(node, P::PLANS) {
        Some(c) => c,
        None => return false,
    };
    for child in children {
        if let Value::Object(c) = child {
            if crate::model::has(c, P::OUTPUT) || find_output_property(c) {
                return true;
            }
        }
    }
    false
}
