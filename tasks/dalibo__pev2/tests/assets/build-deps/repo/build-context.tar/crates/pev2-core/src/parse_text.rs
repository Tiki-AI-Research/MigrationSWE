//! Port of `fromText` and every `parse*` helper from `plan-service.ts`.

use std::cell::RefCell;
use std::collections::HashMap;
use std::rc::Rc;
use std::sync::OnceLock;

use regex::Regex;
use serde_json::{Map, Value};

use crate::help::split_balanced;
use crate::model::{
    capitalize, get_arr, get_str, parse_float, parse_int, start_case, JsonMap, PlanContent,
};
use crate::node_type::parse_node_type;
use crate::property as P;
use crate::source::split_into_lines;

const REF_KEY: &str = "\u{0}ref";

type Obj = Rc<RefCell<JsonMap>>;

fn re(pattern: &str) -> Regex {
    Regex::new(pattern).expect("valid regex")
}

fn split_comma_ws(value: &str) -> Vec<String> {
    static RE: OnceLock<Regex> = OnceLock::new();
    let regex = RE.get_or_init(|| re(r"\s*,\s*"));
    regex.split(value).map(|s| s.to_string()).collect()
}

fn split_comma_space(value: &str) -> Vec<String> {
    static RE: OnceLock<Regex> = OnceLock::new();
    let regex = RE.get_or_init(|| re(r",\s+"));
    regex.split(value).map(|s| s.to_string()).collect()
}

fn indentation_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| re(r"^\s*"))
}
fn empty_line_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| re(r"^s*$"))
}
fn header_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| re(r"^\\s*(QUERY|---|#).*$"))
}
fn trailing_quote_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| re(r#""\s*$"#))
}
fn leading_quote_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| re(r#"^\s*""#))
}
fn tab_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| re(r"\t"))
}

fn actual_pattern() -> &'static str {
    r"(?:actual(?:\stime=(\d+\.\d+)\.\.(\d+\.\d+))?\srows=(\d+(?:\.\d+)?)\sloops=(\d+)|(never\s+executed))"
}

fn node_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        let p = format!(
            r"^(\s*->\s*|\s*)(Finalize|Simple|Partial)*\s*([^\r\n\t\x0C\x0B\(]*?)\s*(?:(?:\(cost=(\d+\.\d+)\.\.(\d+\.\d+)\s+rows=(\d+)\s+width=(\d+)\)\s+\({}\))|(?:\(cost=(\d+\.\d+)\.\.(\d+\.\d+)\s+rows=(\d+)\s+width=(\d+)\))|(?:\({}\)))\s*$",
            actual_pattern(),
            actual_pattern()
        );
        Regex::new(&p).unwrap()
    })
}

fn sub_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| re(r"^(\s*)((?:Sub|Init)Plan)\s*(?:\d+\s*)?\s*(?:\(returns.*\)\s*)?$"))
}
fn cte_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| re(r"^(\s*)CTE\s+(\S+)\s*$"))
}
fn trigger_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| re(r"^(\s*)Trigger\s+(.*):\s+time=(\d+\.\d+)\s+calls=(\d+)\s*$"))
}
fn worker_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        let p = format!(
            r"^(\s*)Worker\s+(\d+):\s+(?:{})?(.*)\s*$",
            actual_pattern()
        );
        Regex::new(&p).unwrap()
    })
}
fn jit_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| re(r"^(\s*)JIT:\s*$"))
}
fn planning_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| re(r"^(\s*)Planning:$"))
}
fn serialization_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| re(r"^(\s*)Serialization:\s+time=(\d+\.\d+) ms.*output=(\d+).*$"))
}
fn extra_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| re(r"^(\s*)(\S.*\S)\s*$"))
}

#[derive(Clone)]
struct Element {
    node_id: Option<usize>,
    subelement_type: Option<String>,
    name: Option<String>,
}

struct Builder {
    arena: Vec<Obj>,
    children: HashMap<usize, Vec<usize>>,
}

impl Builder {
    fn new() -> Self {
        Builder {
            arena: Vec::new(),
            children: HashMap::new(),
        }
    }

    fn new_obj(&mut self, m: JsonMap) -> usize {
        self.arena.push(Rc::new(RefCell::new(m)));
        self.arena.len() - 1
    }

    fn add_child(&mut self, parent: usize, child: usize) {
        self.children.entry(parent).or_default().push(child);
    }

    fn set(&mut self, id: usize, key: &str, value: Value) {
        self.arena[id].borrow_mut().insert(key.to_string(), value);
    }

    fn marker(&mut self, id: usize) -> Value {
        let mut m = Map::new();
        m.insert(REF_KEY.to_string(), Value::from(id as u64));
        Value::Object(m)
    }

    fn materialize(&self, id: usize) -> Value {
        let mut value = Value::Object(self.arena[id].borrow().clone());
        if let Some(ch) = self.children.get(&id) {
            let arr: Vec<Value> = ch.iter().map(|c| self.materialize(*c)).collect();
            if let Value::Object(ref mut m) = value {
                m.insert(P::PLANS.to_string(), Value::Array(arr));
            }
        }
        self.resolve(value)
    }

    fn resolve(&self, value: Value) -> Value {
        match value {
            Value::Object(m) => {
                if m.len() == 1 && m.contains_key(REF_KEY) {
                    if let Some(Value::Number(n)) = m.get(REF_KEY) {
                        return self.materialize(n.as_u64().unwrap_or(0) as usize);
                    }
                }
                let mut out = Map::new();
                for (k, v) in m {
                    out.insert(k, self.resolve(v));
                }
                Value::Object(out)
            }
            Value::Array(a) => Value::Array(a.into_iter().map(|v| self.resolve(v)).collect()),
            other => other,
        }
    }
}

/// Build plan content and node tree from text input.
pub fn from_text(text: &str) -> Result<PlanContent, String> {
    let lines = split_into_lines(text);
    let mut b = Builder::new();
    let root_id = b.new_obj(Map::new());
    let mut elements_at_depth: Vec<(i64, Element)> = Vec::new();

    for raw_line in &lines {
        let mut line = trailing_quote_regex().replace(raw_line, "").to_string();
        line = leading_quote_regex().replace(&line, "").to_string();
        line = tab_regex().replace_all(&line, "    ").to_string();

        let depth = indentation_regex()
            .find(&line)
            .map(|m| m.as_str().len() as i64)
            .unwrap_or(0);
        line = indentation_regex().replace(&line, "").to_string();

        let empty = empty_line_regex().is_match(&line);
        let header = header_regex().is_match(&line);
        let node_matches = node_regex().captures(&line);
        let sub_matches = sub_regex().captures(&line);
        let cte_matches = cte_regex().captures(&line);
        let trigger_matches = trigger_regex().captures(&line);
        let worker_matches = worker_regex().captures(&line);
        let jit_matches = jit_regex().is_match(&line);
        let planning_matches = planning_regex().is_match(&line);
        let serialization_matches = serialization_regex().captures(&line);
        let extra_matches = extra_regex().captures(&line);

        let is_cte_line = cte_matches.is_some();
        let is_sub_line = sub_matches.is_some();

        if empty || header {
            continue;
        } else if let Some(nm) = node_matches {
            if !is_cte_line && !is_sub_line {
                let ty = nm.get(3).map(|m| m.as_str()).unwrap_or("");
                let mut new_node = parse_node_type(ty);

                let est1 = nm.get(4).map(|m| m.as_str());
                let estt1 = nm.get(5).map(|m| m.as_str());
                let est2 = nm.get(13).map(|m| m.as_str());
                let estt2 = nm.get(14).map(|m| m.as_str());
                if (est1.is_some() && estt1.is_some()) || (est2.is_some() && estt2.is_some()) {
                    let sc = est1.or(est2).unwrap();
                    let tc = estt1.or(estt2).unwrap();
                    let rows = nm
                        .get(6)
                        .map(|m| m.as_str())
                        .or_else(|| nm.get(15).map(|m| m.as_str()))
                        .unwrap_or("0");
                    let width = nm
                        .get(7)
                        .map(|m| m.as_str())
                        .or_else(|| nm.get(16).map(|m| m.as_str()))
                        .unwrap_or("0");
                    crate::model::set_num(&mut new_node, P::STARTUP_COST, parse_float(sc).unwrap_or(f64::NAN));
                    crate::model::set_num(&mut new_node, P::TOTAL_COST, parse_float(tc).unwrap_or(f64::NAN));
                    crate::model::set_i64(&mut new_node, P::PLAN_ROWS, parse_int(rows).unwrap_or(0));
                    crate::model::set_i64(&mut new_node, P::PLAN_WIDTH, parse_int(width).unwrap_or(0));
                }

                let atf1 = nm.get(8).map(|m| m.as_str());
                let atl1 = nm.get(9).map(|m| m.as_str());
                let atf2 = nm.get(17).map(|m| m.as_str());
                let atl2 = nm.get(18).map(|m| m.as_str());
                if (atf1.is_some() && atl1.is_some()) || (atf2.is_some() && atl2.is_some()) {
                    let af = atf1.or(atf2).unwrap();
                    let al = atl1.or(atl2).unwrap();
                    crate::model::set_num(&mut new_node, P::ACTUAL_STARTUP_TIME, parse_float(af).unwrap_or(f64::NAN));
                    crate::model::set_num(&mut new_node, P::ACTUAL_TOTAL_TIME, parse_float(al).unwrap_or(f64::NAN));
                }

                let ar1 = nm.get(10).map(|m| m.as_str());
                let alo1 = nm.get(11).map(|m| m.as_str());
                let ar2 = nm.get(19).map(|m| m.as_str());
                let alo2 = nm.get(20).map(|m| m.as_str());
                if (ar1.is_some() && alo1.is_some()) || (ar2.is_some() && alo2.is_some()) {
                    let actual_rows = ar1.or(ar2).unwrap();
                    if actual_rows.contains('.') {
                        crate::model::set_bool(&mut new_node, P::ACTUAL_ROWS_FRACTIONAL, true);
                    }
                    crate::model::set_num(&mut new_node, P::ACTUAL_ROWS, parse_float(actual_rows).unwrap_or(f64::NAN));
                    let loops = alo1.or(alo2).unwrap();
                    crate::model::set_i64(&mut new_node, P::ACTUAL_LOOPS, parse_int(loops).unwrap_or(0));
                }

                if let Some(pm) = nm.get(2) {
                    crate::model::set_str(&mut new_node, P::PARTIAL_MODE, pm.as_str());
                }

                let never = nm.get(12).is_some();
                if never {
                    crate::model::set_i64(&mut new_node, P::ACTUAL_LOOPS, 0);
                    crate::model::set_i64(&mut new_node, P::ACTUAL_ROWS, 0);
                    crate::model::set_i64(&mut new_node, P::ACTUAL_TOTAL_TIME, 0);
                    crate::model::set_i64(&mut new_node, P::ACTUAL_STARTUP_TIME, 0);
                }

                let node_id = b.new_obj(new_node);
                if elements_at_depth.is_empty() {
                    elements_at_depth.push((
                        depth,
                        Element {
                            node_id: Some(node_id),
                            subelement_type: Some("subnode".to_string()),
                            name: None,
                        },
                    ));
                    let marker = b.marker(node_id);
                    b.set(root_id, "Plan", marker);
                    continue;
                }

                elements_at_depth.retain(|(d, _)| *d < depth);
                let previous = elements_at_depth.last().cloned();
                let previous = match previous {
                    Some(p) => p.1,
                    None => continue,
                };
                elements_at_depth.push((
                    depth,
                    Element {
                        node_id: Some(node_id),
                        subelement_type: Some("subnode".to_string()),
                        name: None,
                    },
                ));

                if let Some(pid) = previous.node_id {
                    if previous.subelement_type.as_deref() == Some("initplan") {
                        b.set(node_id, P::PARENT_RELATIONSHIP, Value::from("InitPlan"));
                        b.set(
                            node_id,
                            P::SUBPLAN_NAME,
                            Value::from(previous.name.clone().unwrap_or_default()),
                        );
                    } else if previous.subelement_type.as_deref() == Some("subplan") {
                        b.set(node_id, P::PARENT_RELATIONSHIP, Value::from("SubPlan"));
                        b.set(
                            node_id,
                            P::SUBPLAN_NAME,
                            Value::from(previous.name.clone().unwrap_or_default()),
                        );
                    }
                    b.add_child(pid, node_id);
                }
            }
        } else if let Some(sm) = sub_matches {
            let ty = sm.get(2).map(|m| m.as_str()).unwrap_or("").to_lowercase();
            let full = sm.get(0).map(|m| m.as_str()).unwrap_or("").to_string();
            elements_at_depth.retain(|(d, _)| *d < depth);
            let previous = elements_at_depth.last().cloned();
            let node_id = previous.as_ref().and_then(|p| p.1.node_id);
            elements_at_depth.push((
                depth,
                Element {
                    node_id,
                    subelement_type: Some(ty),
                    name: Some(full),
                },
            ));
        } else if let Some(cm) = cte_matches {
            let cte_name = cm.get(2).map(|m| m.as_str()).unwrap_or("").to_string();
            elements_at_depth.retain(|(d, _)| *d < depth);
            let previous = elements_at_depth.last().cloned();
            let node_id = previous.as_ref().and_then(|p| p.1.node_id);
            elements_at_depth.push((
                depth,
                Element {
                    node_id,
                    subelement_type: Some("initplan".to_string()),
                    name: Some(format!("CTE {}", cte_name)),
                },
            ));
        } else if let Some(wm) = worker_matches {
            let worker_number = wm
                .get(2)
                .and_then(|m| parse_int(m.as_str()))
                .unwrap_or(0);
            let previous = match elements_at_depth.last().cloned() {
                Some(p) => p.1,
                None => continue,
            };
            let nid = match previous.node_id {
                Some(n) => n,
                None => continue,
            };
            // ensure Workers array and find/create worker
            {
                let mut node = b.arena[nid].borrow_mut();
                if !node.contains_key(P::WORKERS) {
                    node.insert(P::WORKERS.to_string(), Value::Array(Vec::new()));
                }
                let worker = {
                    let workers = node
                        .get_mut(P::WORKERS)
                        .and_then(|v| v.as_array_mut())
                        .unwrap();
                    let existing = workers.iter().position(|w| {
                        w.get(P::WORKER_NUMBER)
                            .and_then(|n| n.as_i64())
                            == Some(worker_number)
                    });
                    match existing {
                        Some(i) => &mut workers[i],
                        None => {
                            let mut w = Map::new();
                            w.insert(P::WORKER_NUMBER.to_string(), Value::from(worker_number));
                            workers.push(Value::Object(w));
                            let len = workers.len();
                            &mut workers[len - 1]
                        }
                    }
                };
                if let Some(wobj) = worker.as_object_mut() {
                    let atf = wm.get(3).map(|m| m.as_str());
                    let atl = wm.get(4).map(|m| m.as_str());
                    if atf.is_some() && atl.is_some() {
                        crate::model::set_num(wobj, P::ACTUAL_STARTUP_TIME, parse_float(atf.unwrap()).unwrap_or(f64::NAN));
                        crate::model::set_num(wobj, P::ACTUAL_TOTAL_TIME, parse_float(atl.unwrap()).unwrap_or(f64::NAN));
                        crate::model::set_i64(wobj, P::ACTUAL_ROWS, wm.get(5).and_then(|m| parse_int(m.as_str())).unwrap_or(0));
                        crate::model::set_i64(wobj, P::ACTUAL_LOOPS, wm.get(6).and_then(|m| parse_int(m.as_str())).unwrap_or(0));
                    }
                    let extra = wm.get(8).map(|m| m.as_str()).unwrap_or("");
                    if !parse_sort(extra, wobj) {
                        let info = split_info(extra);
                        if info.len() >= 2 {
                            set_str(wobj, &start_case(&info[0]), info[1].clone());
                        }
                    }
                }
            }
        } else if let Some(tm) = trigger_matches {
            elements_at_depth.retain(|(d, _)| *d < depth);
            let trig = {
                let mut t = Map::new();
                t.insert(
                    "Trigger Name".to_string(),
                    Value::from(tm.get(2).map(|m| m.as_str()).unwrap_or("")),
                );
                t.insert(
                    "Time".to_string(),
                    Value::from(parse_time(tm.get(3).map(|m| m.as_str()).unwrap_or(""))),
                );
                t.insert(
                    "Calls".to_string(),
                    Value::from(tm.get(4).map(|m| m.as_str()).unwrap_or("")),
                );
                Value::Object(t)
            };
            let mut root = b.arena[root_id].borrow_mut();
            let triggers = root
                .entry("Triggers".to_string())
                .or_insert_with(|| Value::Array(Vec::new()));
            if let Value::Array(a) = triggers {
                a.push(trig);
            }
        } else if jit_matches {
            if elements_at_depth.is_empty() {
                let jit_id = b.new_obj(Map::new());
                let marker = b.marker(jit_id);
                b.set(root_id, P::JIT, marker);
                elements_at_depth.push((
                    1,
                    Element {
                        node_id: Some(jit_id),
                        subelement_type: None,
                        name: None,
                    },
                ));
            } else {
                let last = elements_at_depth.last().cloned().unwrap().1;
                if let Some(lid) = last.node_id {
                    let has_worker = {
                        let node = b.arena[lid].borrow();
                        get_arr(&node, P::WORKERS)
                            .and_then(|w| w.last())
                            .is_some()
                    };
                    if has_worker {
                        let jit_id = b.new_obj(Map::new());
                        {
                            let mut node = b.arena[lid].borrow_mut();
                            if let Some(workers) =
                                node.get_mut(P::WORKERS).and_then(|v| v.as_array_mut())
                            {
                                if let Some(last_worker) = workers.last_mut() {
                                    if let Some(wobj) = last_worker.as_object_mut() {
                                        let mut m = Map::new();
                                        m.insert(REF_KEY.to_string(), Value::from(jit_id as u64));
                                        wobj.insert(P::JIT.to_string(), Value::Object(m));
                                    }
                                }
                            }
                        }
                        elements_at_depth.push((
                            depth,
                            Element {
                                node_id: Some(jit_id),
                                subelement_type: None,
                                name: None,
                            },
                        ));
                    }
                }
            }
        } else if planning_matches {
            let planning_id = b.new_obj(Map::new());
            let marker = b.marker(planning_id);
            b.set(root_id, "Planning", marker);
            elements_at_depth.push((
                1,
                Element {
                    node_id: Some(planning_id),
                    subelement_type: None,
                    name: None,
                },
            ));
        } else if let Some(sm) = serialization_matches {
            let mut ser = Map::new();
            ser.insert(
                "Time".to_string(),
                Value::from(parse_float(sm.get(2).map(|m| m.as_str()).unwrap_or("")).unwrap_or(f64::NAN)),
            );
            ser.insert(
                "Output Volume".to_string(),
                Value::from(parse_int(sm.get(3).map(|m| m.as_str()).unwrap_or("")).unwrap_or(0)),
            );
            let ser_id = b.new_obj(ser);
            let marker = b.marker(ser_id);
            b.set(root_id, "Serialization", marker);
            elements_at_depth.push((
                1,
                Element {
                    node_id: Some(ser_id),
                    subelement_type: None,
                    name: None,
                },
            ));
        } else if let Some(em) = extra_matches {
            elements_at_depth.retain(|(d, _)| !(*d >= depth || depth == 1));

            let element_id = if elements_at_depth.is_empty() {
                root_id
            } else {
                elements_at_depth
                    .last()
                    .and_then(|e| e.1.node_id)
                    .unwrap_or(root_id)
            };

            let is_query_text_append = {
                let m = b.arena[element_id].borrow();
                !m.contains_key("Plan") && m.contains_key("Query Text")
            };
            if is_query_text_append {
                let mut m = b.arena[element_id].borrow_mut();
                let prev = m
                    .get("Query Text")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();
                m.insert(
                    "Query Text".to_string(),
                    Value::from(format!("{}\n{}", prev, line)),
                );
                continue;
            }

            let content = em.get(2).map(|m| m.as_str()).unwrap_or("");
            let info = split_info(content);
            if info.len() < 2 {
                continue;
            }

            let handled = {
                let mut m = b.arena[element_id].borrow_mut();
                parse_sort(content, &mut m)
                    || parse_group_hash_sort_key(content, &mut m)
                    || parse_buffers(content, &mut m)
                    || parse_buckets(content, &mut m)
                    || parse_planned_partitions(content, &mut m)
                    || parse_wal(content, &mut m)
                    || parse_iotimings(content, &mut m)
                    || parse_options(content, &mut m)
                    || parse_timing(content, &mut m)
                    || parse_settings(content, &mut m)
                    || parse_sort_groups(content, &mut m)
                    || parse_sort_key(content, &mut m)
                    || parse_disabled(content, &mut m)
                    || parse_memory(content, &mut m)
                    || parse_cache(content, &mut m)
            };
            if handled {
                continue;
            }

            let cleaned = strip_ms(&info[1]);
            let value = match parse_float(&cleaned) {
                Some(f) if f != 0.0 && !f.is_nan() => Value::from(f),
                _ => Value::from(cleaned),
            };
            let property = if info[0].contains(" runtime") || info[0].contains(" time") {
                start_case(&info[0])
            } else {
                info[0].clone()
            };
            let mut m = b.arena[element_id].borrow_mut();
            m.insert(property, value);
        }
    }

    let root_value = b.materialize(root_id);
    let mut root_map = match root_value {
        Value::Object(m) => m,
        _ => Map::new(),
    };
    if !root_map.contains_key("Plan") {
        return Err("Unable to parse plan".to_string());
    }
    if let Some(Value::Object(plan)) = root_map.get_mut("Plan") {
        set_parent_relationship(plan, None, 0);
    }
    Ok(root_map)
}

fn set_str(m: &mut JsonMap, key: &str, v: String) {
    m.insert(key.to_string(), Value::from(v));
}

fn split_info(text: &str) -> Vec<String> {
    // Equivalent of `text.split(/: (.+)/).filter(x => x)`.
    if let Some(pos) = text.find(": ") {
        let after = &text[pos + 2..];
        if !after.is_empty() {
            let before = &text[..pos];
            let mut out = Vec::new();
            if !before.is_empty() {
                out.push(before.to_string());
            }
            out.push(after.to_string());
            return out;
        }
    }
    if text.is_empty() {
        Vec::new()
    } else {
        vec![text.to_string()]
    }
}

fn strip_ms(text: &str) -> String {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| re(r"(\s*ms)$"));
    re.replace(text, "").to_string()
}

fn parse_time(text: &str) -> f64 {
    parse_float(&strip_ms(text)).unwrap_or(f64::NAN)
}

fn set_parent_relationship(node: &mut JsonMap, parent_type: Option<String>, index: usize) {
    let my_type = get_str(node, P::NODE_TYPE).map(|s| s.to_string());
    if let Some(Value::Array(children)) = node.get_mut(P::PLANS) {
        for (i, child) in children.iter_mut().enumerate() {
            if let Value::Object(c) = child {
                set_parent_relationship(c, my_type.clone(), i);
            }
        }
    }
    if parent_type.is_none() || node.contains_key(P::PARENT_RELATIONSHIP) {
        return;
    }
    let t = parent_type.unwrap();
    let r = if ["Nested Loop", "Hash Join", "Merge Join"].contains(&t.as_str()) {
        if index == 0 {
            "Outer"
        } else {
            "Inner"
        }
    } else if ["Append", "MergeAppend", "BitmapAnd", "BitmapOr"].contains(&t.as_str()) {
        "Member"
    } else if t == "Subquery Scan" {
        "Subquery"
    } else {
        "Outer"
    };
    node.insert(P::PARENT_RELATIONSHIP.to_string(), Value::from(r));
}

// ---------------------------------------------------------------------------
// Info-line parsers
// ---------------------------------------------------------------------------

fn parse_sort_key(text: &str, el: &mut JsonMap) -> bool {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| re(r"^\s*((?:Sort|Presorted) Key):\s+(.*)"));
    if let Some(c) = re.captures(text) {
        let key = c.get(1).unwrap().as_str();
        let value = c.get(2).unwrap().as_str();
        let arr: Vec<Value> = split_balanced(value, ",")
            .into_iter()
            .map(|s| Value::from(s.trim().to_string()))
            .collect();
        el.insert(key.to_string(), Value::Array(arr));
        return true;
    }
    false
}

fn parse_sort(text: &str, el: &mut JsonMap) -> bool {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| re(r"^(\s*)Sort Method:\s+(.*)\s+(Memory|Disk):\s+(?:(\S*)kB)\s*$"));
    if let Some(c) = re.captures(text) {
        set_str(el, P::SORT_METHOD, c.get(2).unwrap().as_str().trim().to_string());
        set_str(el, P::SORT_SPACE_USED, c.get(4).map(|m| m.as_str()).unwrap_or("").to_string());
        set_str(el, P::SORT_SPACE_TYPE, c.get(3).map(|m| m.as_str()).unwrap_or("").to_string());
        return true;
    }
    false
}

fn parse_buffers(text: &str, el: &mut JsonMap) -> bool {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| re(r"Buffers:\s+(.*)\s*$"));
    let c = match re.captures(text) {
        Some(c) => c,
        None => return false,
    };
    let group = c.get(1).map(|m| m.as_str()).unwrap_or("");
    for infos in split_comma_space(group) {
        if let Some(m) = Regex::new(r"(shared|temp|local)\s+(.*)$").unwrap().captures(&infos) {
            let ty = m.get(1).unwrap().as_str();
            for method in ["hit", "read", "written", "dirtied"] {
                let key = format!("{} {} Blocks", capitalize(ty), capitalize(method));
                el.insert(key, Value::from(0));
            }
            for buffer in m.get(2).unwrap().as_str().split_whitespace() {
                parse_buffer(buffer, ty, el);
            }
        }
    }
    true
}

fn parse_buffer(text: &str, ty: &str, el: &mut JsonMap) {
    let parts: Vec<&str> = text.split('=').collect();
    let method = parts.first().copied().unwrap_or("");
    let value = parts
        .get(1)
        .and_then(|v| parse_int(v))
        .unwrap_or(0);
    let key = format!("{} {} Blocks", capitalize(ty), capitalize(method));
    el.insert(key, Value::from(value));
}

fn parse_buckets(text: &str, el: &mut JsonMap) -> bool {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| {
        re(r"Buckets:\s+([0-9]*)(?:\s*\(originally\s+([0-9]*)\))*\s+Batches:\s+([0-9]*)(?:\s*\(originally\s+([0-9]*)\))*\s+Memory Usage:\s+([0-9]*)kB\s*$")
    });
    let c = match re.captures(text) {
        Some(c) => c,
        None => return false,
    };
    let buckets = c.get(1).and_then(|m| parse_int(m.as_str())).unwrap_or(0);
    let batches = c.get(3).and_then(|m| parse_int(m.as_str())).unwrap_or(0);
    let original_buckets = c.get(2).and_then(|m| parse_int(m.as_str())).unwrap_or(0);
    let original_batches = c.get(4).and_then(|m| parse_int(m.as_str())).unwrap_or(0);
    let mem = c.get(5).and_then(|m| parse_int(m.as_str())).unwrap_or(0);
    crate::model::set_i64(el, P::HASH_BUCKETS, buckets);
    crate::model::set_i64(el, P::HASH_BATCHES, batches);
    crate::model::set_i64(el, P::ORIGINAL_HASH_BUCKETS, if original_buckets != 0 { original_buckets } else { buckets });
    crate::model::set_i64(el, P::ORIGINAL_HASH_BATCHES, if original_batches != 0 { original_batches } else { batches });
    crate::model::set_i64(el, P::PEAK_MEMORY_USAGE, mem);
    true
}

fn parse_planned_partitions(text: &str, el: &mut JsonMap) -> bool {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| {
        re(r"Planned Partitions:\s+([0-9]*)(?:\s+Batches:\s+([0-9]*))*(?:\s+Memory Usage:\s+([0-9]*)kB)*(?:\s*Disk Usage:\s+([0-9]*)kB)*\s*$")
    });
    let c = match re.captures(text) {
        Some(c) => c,
        None => return false,
    };
    let partitions = c.get(1).and_then(|m| parse_int(m.as_str())).unwrap_or(0);
    crate::model::set_i64(el, P::PLANNED_PARTITIONS, partitions);
    if let Some(b) = c.get(2).and_then(|m| parse_int(m.as_str())) {
        crate::model::set_i64(el, P::HASHAGG_BATCHES, b);
    }
    if let Some(mem) = c.get(3).and_then(|m| parse_int(m.as_str())) {
        crate::model::set_i64(el, P::PEAK_MEMORY_USAGE, mem);
    }
    if let Some(disk) = c.get(4).and_then(|m| parse_int(m.as_str())) {
        crate::model::set_i64(el, P::DISK_USAGE, disk);
    }
    true
}

fn parse_wal(text: &str, el: &mut JsonMap) -> bool {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| re(r"WAL:\s+(.*)\s*$"));
    let c = match re.captures(text) {
        Some(c) => c,
        None => return false,
    };
    for ty in ["Records", "Bytes", "FPI"] {
        el.insert(format!("WAL {}", ty), Value::from(0));
    }
    for token in c.get(1).map(|m| m.as_str()).unwrap_or("").split_whitespace() {
        let parts: Vec<&str> = token.split('=').collect();
        let ty = parts.first().copied().unwrap_or("");
        let value = parts.get(1).and_then(|v| parse_int(v)).unwrap_or(0);
        let type_caps = if ty == "fpi" {
            "FPI".to_string()
        } else {
            capitalize(ty)
        };
        el.insert(format!("WAL {}", type_caps), Value::from(value));
    }
    true
}

fn parse_iotimings(text: &str, el: &mut JsonMap) -> bool {
    if !text.contains("I/O Timings:") {
        return false;
    }
    static SCOPE_RE: OnceLock<Regex> = OnceLock::new();
    static OP_RE: OnceLock<Regex> = OnceLock::new();
    let scope_re = SCOPE_RE.get_or_init(|| re(r"\b(shared/local|shared|local|temp)((?:\s+(?:read|write)=\d+(?:\.\d+)?)+)"));
    let op_re = OP_RE.get_or_init(|| re(r"(read|write)=(\d+(?:\.\d+)?)"));

    struct Entry {
        scope: Option<String>,
        read: f64,
        write: f64,
    }
    let mut results: Vec<Entry> = Vec::new();

    let mut scoped_spans: Vec<(usize, usize)> = Vec::new();
    for cm in scope_re.captures_iter(text) {
        let m = cm.get(0).unwrap();
        scoped_spans.push((m.start(), m.end()));
        let scope = cm.get(1).unwrap().as_str().to_string();
        let operations = cm.get(2).unwrap().as_str();
        let mut entry = Entry {
            scope: Some(scope),
            read: 0.0,
            write: 0.0,
        };
        for om in op_re.captures_iter(operations) {
            let op = om.get(1).unwrap().as_str();
            let val = parse_float(om.get(2).unwrap().as_str()).unwrap_or(0.0);
            if op == "read" {
                entry.read = val;
            } else {
                entry.write = val;
            }
        }
        results.push(entry);
    }

    // Build `rest` by removing scoped spans, mirroring `text.replace(scopeRegex, "")`.
    let mut rest = String::new();
    let mut last = 0usize;
    for (s, e) in &scoped_spans {
        rest.push_str(&text[last..*s]);
        last = *e;
    }
    rest.push_str(&text[last..]);

    let mut unscoped = Entry {
        scope: None,
        read: 0.0,
        write: 0.0,
    };
    let mut found = false;
    for om in op_re.captures_iter(&rest) {
        let op = om.get(1).unwrap().as_str();
        let val = parse_float(om.get(2).unwrap().as_str()).unwrap_or(0.0);
        if op == "read" {
            unscoped.read = val;
        } else {
            unscoped.write = val;
        }
        found = true;
    }
    if found {
        results.push(unscoped);
    }

    let scope_is_detailed = results
        .iter()
        .any(|r| r.scope.as_deref() == Some("shared") || r.scope.as_deref() == Some("local"));
    let scope_is_partially_detailed = results.iter().any(|r| r.scope.as_deref() == Some("shared/local"));

    if scope_is_detailed {
        crate::model::set_i64(el, P::SHARED_IO_READ_TIME, 0);
        crate::model::set_i64(el, P::SHARED_IO_WRITE_TIME, 0);
        crate::model::set_i64(el, P::LOCAL_IO_READ_TIME, 0);
        crate::model::set_i64(el, P::LOCAL_IO_WRITE_TIME, 0);
    } else {
        crate::model::set_i64(el, P::IO_READ_TIME, 0);
        crate::model::set_i64(el, P::IO_WRITE_TIME, 0);
    }
    if scope_is_partially_detailed || scope_is_detailed {
        crate::model::set_i64(el, P::TEMP_IO_READ_TIME, 0);
        crate::model::set_i64(el, P::TEMP_IO_WRITE_TIME, 0);
    }

    for entry in &results {
        for op in ["read", "write"] {
            let key = io_timing_key(entry.scope.as_deref(), op);
            let val = if op == "read" { entry.read } else { entry.write };
            crate::model::set_num(el, key, val);
        }
    }
    true
}

fn io_timing_key(scope: Option<&str>, op: &str) -> &'static str {
    match (scope, op) {
        (Some("shared"), "read") => P::SHARED_IO_READ_TIME,
        (Some("shared"), _) => P::SHARED_IO_WRITE_TIME,
        (Some("local"), "read") => P::LOCAL_IO_READ_TIME,
        (Some("local"), _) => P::LOCAL_IO_WRITE_TIME,
        (Some("temp"), "read") => P::TEMP_IO_READ_TIME,
        (Some("temp"), _) => P::TEMP_IO_WRITE_TIME,
        (_, "read") => P::IO_READ_TIME,
        (_, _) => P::IO_WRITE_TIME,
    }
}

fn parse_options(text: &str, el: &mut JsonMap) -> bool {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| re(r"^(\s*)Options:\s+(.*)$"));
    let c = match re.captures(text) {
        Some(c) => c,
        None => return false,
    };
    let mut options = Map::new();
    for option in split_comma_ws(c.get(2).map(|m| m.as_str()).unwrap_or("")) {
        if let Some(m) = Regex::new(r"^(\S*)\s+(.*)$").unwrap().captures(&option) {
            let key = m.get(1).unwrap().as_str().to_string();
            let raw = m.get(2).unwrap().as_str();
            let value = serde_json::from_str::<Value>(raw).unwrap_or(Value::from(raw));
            options.insert(key, value);
        }
    }
    el.insert("Options".to_string(), Value::Object(options));
    true
}

fn parse_timing(text: &str, el: &mut JsonMap) -> bool {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| re(r"^(\s*)Timing:\s+(.*)$"));
    let c = match re.captures(text) {
        Some(c) => c,
        None => return false,
    };
    let mut timing = Map::new();
    for option in split_comma_ws(c.get(2).map(|m| m.as_str()).unwrap_or("")) {
        if let Some(m) = Regex::new(r"^(\S*)\s+(.*)$").unwrap().captures(&option) {
            let key = m.get(1).unwrap().as_str().to_string();
            let value = parse_time(m.get(2).unwrap().as_str());
            timing.insert(key, Value::from(value));
        }
    }
    el.insert("Timing".to_string(), Value::Object(timing));
    true
}

fn parse_settings(text: &str, el: &mut JsonMap) -> bool {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| re(r"^(\s*)Settings:\s*(.*)$"));
    let c = match re.captures(text) {
        Some(c) => c,
        None => return false,
    };
    let mut settings = Map::new();
    for option in split_balanced(c.get(2).map(|m| m.as_str()).unwrap_or(""), ",") {
        if let Some(m) = Regex::new(r"^(\S*)\s+=\s+(.*)$").unwrap().captures(option.trim()) {
            let key = m.get(1).unwrap().as_str().to_string();
            let value = m.get(2).unwrap().as_str().replace('\'', "");
            settings.insert(key, Value::from(value));
        }
    }
    el.insert("Settings".to_string(), Value::Object(settings));
    true
}

fn parse_sort_groups(text: &str, el: &mut JsonMap) -> bool {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| {
        re(r"^\s*(Full-sort|Pre-sorted) Groups:\s+([0-9]*)\s+Sort Method[s]*:\s+(.*)\s+Average Memory:\s+(\S*)kB\s+Peak Memory:\s+(\S*)kB.*$")
    });
    let c = match re.captures(text) {
        Some(c) => c,
        None => return false,
    };
    let mut groups = Map::new();
    groups.insert(
        P::GROUP_COUNT.to_string(),
        Value::from(c.get(2).and_then(|m| parse_int(m.as_str())).unwrap_or(0)),
    );
    let methods: Vec<Value> = c
        .get(3)
        .map(|m| m.as_str())
        .unwrap_or("")
        .split(',')
        .map(|s| Value::from(s.trim().to_string()))
        .collect();
    groups.insert(P::SORT_METHODS_USED.to_string(), Value::Array(methods));
    let mut space = Map::new();
    space.insert(
        P::AVERAGE_SORT_SPACE_USED.to_string(),
        Value::from(c.get(4).and_then(|m| parse_int(m.as_str())).unwrap_or(0)),
    );
    space.insert(
        P::PEAK_SORT_SPACE_USED.to_string(),
        Value::from(c.get(5).and_then(|m| parse_int(m.as_str())).unwrap_or(0)),
    );
    groups.insert(P::SORT_SPACE_MEMORY.to_string(), Value::Object(space));

    match c.get(1).unwrap().as_str() {
        "Full-sort" => {
            el.insert(P::FULL_SORT_GROUPS.to_string(), Value::Object(groups));
        }
        "Pre-sorted" => {
            el.insert(P::PRE_SORTED_GROUPS.to_string(), Value::Object(groups));
        }
        _ => return false,
    }
    true
}

fn parse_disabled(text: &str, el: &mut JsonMap) -> bool {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| re(r"^\s*(Disabled)\s*:\s*(true)$"));
    if re.is_match(text) {
        el.insert(P::DISABLED.to_string(), Value::from(true));
        return true;
    }
    false
}

fn parse_cache(text: &str, el: &mut JsonMap) -> bool {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| {
        re(r"^(\s*)Hits:\s+(\d+)\s+Misses:\s+(\d+)\s+Evictions:\s+(\d+)\s+Overflows:\s+(\d+)\s+Memory Usage:\s+(\d+)kB\s*$")
    });
    let c = match re.captures(text) {
        Some(c) => c,
        None => return false,
    };
    crate::model::set_i64(el, P::CACHE_HITS, c.get(2).and_then(|m| parse_int(m.as_str())).unwrap_or(0));
    crate::model::set_i64(el, P::CACHE_MISSES, c.get(3).and_then(|m| parse_int(m.as_str())).unwrap_or(0));
    crate::model::set_i64(el, P::CACHE_EVICTIONS, c.get(4).and_then(|m| parse_int(m.as_str())).unwrap_or(0));
    crate::model::set_i64(el, P::CACHE_OVERFLOWS, c.get(5).and_then(|m| parse_int(m.as_str())).unwrap_or(0));
    crate::model::set_i64(el, P::PEAK_MEMORY_USAGE, c.get(6).and_then(|m| parse_int(m.as_str())).unwrap_or(0));
    true
}

fn parse_memory(text: &str, el: &mut JsonMap) -> bool {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| re(r"^(\s*)Memory:\s+used=(\d+)kB.*allocated=(\d+)kB.*$"));
    let c = match re.captures(text) {
        Some(c) => c,
        None => return false,
    };
    crate::model::set_i64(el, P::MEMORY_USED, c.get(2).and_then(|m| parse_int(m.as_str())).unwrap_or(0));
    crate::model::set_i64(el, P::MEMORY_ALLOCATED, c.get(3).and_then(|m| parse_int(m.as_str())).unwrap_or(0));
    true
}

fn parse_group_hash_sort_key(text: &str, el: &mut JsonMap) -> bool {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| re(r"^\s*(Group|Hash|Sort) Key:\s+(.*)$"));
    let c = match re.captures(text) {
        Some(c) => c,
        None => return false,
    };
    let key_type = c.get(1).unwrap().as_str();
    let raw_value = c.get(2).unwrap().as_str();
    let values: Vec<Value> = if raw_value == "()" {
        Vec::new()
    } else {
        split_comma_ws(raw_value)
            .into_iter()
            .map(Value::from)
            .collect()
    };

    match key_type {
        "Hash" => {
            let entry = el
                .entry(P::GROUPING_SETS.to_string())
                .or_insert_with(|| Value::Array(Vec::new()));
            if let Value::Array(arr) = entry {
                let mut set = Map::new();
                set.insert(P::HASH_KEYS.to_string(), Value::Array(vec![Value::Array(values)]));
                arr.push(Value::Object(set));
            }
            true
        }
        "Sort" => {
            if !el.contains_key(P::GROUPING_SETS) {
                return false;
            }
            if let Some(Value::Array(arr)) = el.get_mut(P::GROUPING_SETS) {
                let mut set = Map::new();
                set.insert(P::SORT_KEY.to_string(), Value::Array(values));
                arr.push(Value::Object(set));
            }
            true
        }
        "Group" => {
            let last_is_sort = el
                .get(P::GROUPING_SETS)
                .and_then(|v| v.as_array())
                .and_then(|a| a.last())
                .and_then(|s| s.as_object())
                .map(|o| o.contains_key(P::SORT_KEY))
                .unwrap_or(false);
            let last_is_hash = el
                .get(P::GROUPING_SETS)
                .and_then(|v| v.as_array())
                .and_then(|a| a.last())
                .and_then(|s| s.as_object())
                .map(|o| o.contains_key(P::HASH_KEYS))
                .unwrap_or(false);
            if last_is_sort {
                if let Some(Value::Array(arr)) = el.get_mut(P::GROUPING_SETS) {
                    if let Some(Value::Object(last)) = arr.last_mut() {
                        last.insert(P::GROUP_KEYS.to_string(), Value::Array(vec![Value::Array(values)]));
                    }
                }
            } else if last_is_hash {
                let entry = el
                    .entry(P::GROUPING_SETS.to_string())
                    .or_insert_with(|| Value::Array(Vec::new()));
                if let Value::Array(arr) = entry {
                    let mut set = Map::new();
                    set.insert(P::GROUP_KEYS.to_string(), Value::Array(vec![Value::Array(values)]));
                    arr.push(Value::Object(set));
                }
            } else if el
                .get(P::GROUPING_SETS)
                .and_then(|v| v.as_array())
                .map(|a| !a.is_empty())
                .unwrap_or(false)
            {
                if let Some(Value::Array(arr)) = el.get_mut(P::GROUPING_SETS) {
                    if let Some(Value::Object(last)) = arr.last_mut() {
                        let keys = last
                            .entry(P::GROUP_KEYS.to_string())
                            .or_insert_with(|| Value::Array(Vec::new()));
                        if let Value::Array(k) = keys {
                            k.push(Value::Array(values));
                        }
                    }
                }
            } else if let Some(existing) = el.get(P::GROUP_KEY).cloned() {
                let mut set = Map::new();
                set.insert(
                    P::GROUP_KEYS.to_string(),
                    Value::Array(vec![existing, Value::Array(values)]),
                );
                el.insert(P::GROUPING_SETS.to_string(), Value::Array(vec![Value::Object(set)]));
            } else {
                el.insert(P::GROUP_KEY.to_string(), Value::Array(values));
            }
            true
        }
        _ => false,
    }
}


