//! String constants mirroring the TypeScript `Property` enum. The string values
//! are the output keys of the parsed plan.

pub const ACTUAL_LOOPS: &str = "Actual Loops";
pub const ACTUAL_ROWS: &str = "Actual Rows";
pub const ACTUAL_ROWS_FRACTIONAL: &str = "*Actual Rows Is Fractional";
pub const ACTUAL_ROWS_REVISED: &str = "*Actual Rows Revised";
pub const ACTUAL_STARTUP_TIME: &str = "Actual Startup Time";
pub const ACTUAL_STARTUP_TIME_REVISED: &str = "*Actual Startup Time Revised";
pub const ACTUAL_TOTAL_TIME: &str = "Actual Total Time";
pub const ACTUAL_TOTAL_TIME_REVISED: &str = "*Actual Total Time Revised";
pub const ALIAS: &str = "Alias";
pub const ASYNC_CAPABLE: &str = "Async Capable";
pub const CACHE_EVICTIONS: &str = "Cache Evictions";
pub const CACHE_HITS: &str = "Cache Hits";
pub const CACHE_MISSES: &str = "Cache Misses";
pub const CACHE_OVERFLOWS: &str = "Cache Overflows";
pub const CTE_NAME: &str = "CTE Name";
pub const DISABLED: &str = "Disabled";
pub const DISK_USAGE: &str = "Disk Usage";
pub const EXCLUSIVE_COST: &str = "*Cost (exclusive)";
pub const EXCLUSIVE_DURATION: &str = "*Duration (exclusive)";
pub const EXCLUSIVE_IO_READ_TIME: &str = "*I/O Read Time (exclusive)";
pub const EXCLUSIVE_IO_WRITE_TIME: &str = "*I/O Write Time (exclusive)";
pub const EXCLUSIVE_LOCAL_DIRTIED_BLOCKS: &str = "*Local Dirtied Blocks (exclusive)";
pub const EXCLUSIVE_LOCAL_HIT_BLOCKS: &str = "*Local Hit Blocks (exclusive)";
pub const EXCLUSIVE_LOCAL_IO_READ_TIME: &str = "*Local I/O Read Time (exclusive)";
pub const EXCLUSIVE_LOCAL_IO_WRITE_TIME: &str = "*Local I/O Write Time (exclusive)";
pub const EXCLUSIVE_LOCAL_READ_BLOCKS: &str = "*Local Read Blocks (exclusive)";
pub const EXCLUSIVE_LOCAL_WRITTEN_BLOCKS: &str = "*Local Written Blocks (exclusive)";
pub const EXCLUSIVE_READ_BLOCKS: &str = "*Read Blocks (exclusive)";
pub const EXCLUSIVE_SHARED_DIRTIED_BLOCKS: &str = "*Shared Dirtied Blocks (exclusive)";
pub const EXCLUSIVE_SHARED_HIT_BLOCKS: &str = "*Shared Hit Blocks (exclusive)";
pub const EXCLUSIVE_SHARED_IO_READ_TIME: &str = "*Shared I/O Read Time (exclusive)";
pub const EXCLUSIVE_SHARED_IO_WRITE_TIME: &str = "*Shared I/O Write Time (exclusive)";
pub const EXCLUSIVE_SHARED_READ_BLOCKS: &str = "*Shared Read Blocks (exclusive)";
pub const EXCLUSIVE_SHARED_WRITTEN_BLOCKS: &str = "*Shared Written Blocks (exclusive)";
pub const EXCLUSIVE_SUM_IO_READ_TIME: &str = "*I/O Read Time (exclusive, all scopes)";
pub const EXCLUSIVE_SUM_IO_WRITE_TIME: &str = "*I/O Write Time (exclusive, all scopes)";
pub const EXCLUSIVE_TEMP_IO_READ_TIME: &str = "*Temp I/O Read Time (exclusive)";
pub const EXCLUSIVE_TEMP_IO_WRITE_TIME: &str = "*Temp I/O Write Time (exclusive)";
pub const EXCLUSIVE_TEMP_READ_BLOCKS: &str = "*Temp Read Blocks (exclusive)";
pub const EXCLUSIVE_TEMP_WRITTEN_BLOCKS: &str = "*Temp Written Blocks (exclusive)";
pub const EXCLUSIVE_WRITTEN_BLOCKS: &str = "*Written Blocks (exclusive)";
pub const FILTER: &str = "Filter";
pub const FULL_SORT_GROUPS: &str = "Full-sort Groups";
pub const FUNCTION_NAME: &str = "Function Name";
pub const GROUP_COUNT: &str = "Group Count";
pub const GROUP_KEY: &str = "Group Key";
pub const GROUP_KEYS: &str = "Group Keys";
pub const GROUPING_SETS: &str = "Grouping Sets";
pub const HASHAGG_BATCHES: &str = "HashAgg Batches";
pub const HASH_BATCHES: &str = "Hash Batches";
pub const HASH_BUCKETS: &str = "Hash Buckets";
pub const HASH_CONDITION: &str = "Hash Cond";
pub const HASH_KEY: &str = "Hash Key";
pub const HASH_KEYS: &str = "Hash Keys";
pub const HEAP_FETCHES: &str = "Heap Fetches";
pub const INDEX_NAME: &str = "Index Name";
pub const IO_READ_TIME: &str = "I/O Read Time";
pub const IO_WRITE_TIME: &str = "I/O Write Time";
pub const JIT: &str = "JIT";
pub const JOIN_TYPE: &str = "Join Type";
pub const LOCAL_DIRTIED_BLOCKS: &str = "Local Dirtied Blocks";
pub const LOCAL_HIT_BLOCKS: &str = "Local Hit Blocks";
pub const LOCAL_IO_READ_TIME: &str = "Local I/O Read Time";
pub const LOCAL_IO_WRITE_TIME: &str = "Local I/O Write Time";
pub const LOCAL_READ_BLOCKS: &str = "Local Read Blocks";
pub const LOCAL_WRITTEN_BLOCKS: &str = "Local Written Blocks";
pub const MEMORY_ALLOCATED: &str = "Memory Allocated";
pub const MEMORY_USED: &str = "Memory Used";
pub const NODE_ID: &str = "nodeId";
pub const NODE_TYPE: &str = "Node Type";
pub const OPERATION: &str = "Operation";
pub const ORIGINAL_HASH_BATCHES: &str = "Original Hash Batches";
pub const ORIGINAL_HASH_BUCKETS: &str = "Original Hash Buckets";
pub const OUTPUT: &str = "Output";
pub const PARALLEL_AWARE: &str = "Parallel Aware";
pub const PARENT_RELATIONSHIP: &str = "Parent Relationship";
pub const PARTIAL_MODE: &str = "Partial Mode";
pub const PEAK_MEMORY_USAGE: &str = "Peak Memory Usage";
pub const PEAK_SORT_SPACE_USED: &str = "Peak Sort Space Used";
pub const PEV_PLAN_TAG: &str = "plan_";
pub const PLANNED_PARTITIONS: &str = "Planned Partitions";
pub const PLANNER_ESTIMATE_DIRECTION: &str = "*Planner Row Estimate Direction";
pub const PLANNER_ESTIMATE_FACTOR: &str = "*Planner Row Estimate Factor";
pub const PLANS: &str = "Plans";
pub const PLAN_ROWS: &str = "Plan Rows";
pub const PLAN_ROWS_REVISED: &str = "*Plan Rows Revised";
pub const PLAN_WIDTH: &str = "Plan Width";
pub const PRESORTED_KEY: &str = "Presorted Key";
pub const PRE_SORTED_GROUPS: &str = "Pre-sorted Groups";
pub const READ_BLOCKS: &str = "*Read Blocks";
pub const RELATION_NAME: &str = "Relation Name";
pub const ROWS_REMOVED_BY_FILTER: &str = "Rows Removed by Filter";
pub const ROWS_REMOVED_BY_FILTER_REVISED: &str = "*Rows Removed by Filter";
pub const ROWS_REMOVED_BY_INDEX_RECHECK: &str = "Rows Removed by Index Recheck";
pub const ROWS_REMOVED_BY_INDEX_RECHECK_REVISED: &str = "*Rows Removed by Index Recheck";
pub const ROWS_REMOVED_BY_JOIN_FILTER: &str = "Rows Removed by Join Filter";
pub const ROWS_REMOVED_BY_JOIN_FILTER_REVISED: &str = "*Rows Removed by Join Filter";
pub const SCAN_DIRECTION: &str = "Scan Direction";
pub const SERIALIZATION: &str = "Serialization";
pub const SHARED_DIRTIED_BLOCKS: &str = "Shared Dirtied Blocks";
pub const SHARED_HIT_BLOCKS: &str = "Shared Hit Blocks";
pub const SHARED_IO_READ_TIME: &str = "Shared I/O Read Time";
pub const SHARED_IO_WRITE_TIME: &str = "Shared I/O Write Time";
pub const SHARED_READ_BLOCKS: &str = "Shared Read Blocks";
pub const SHARED_WRITTEN_BLOCKS: &str = "Shared Written Blocks";
pub const SORT_KEY: &str = "Sort Key";
pub const SORT_METHOD: &str = "Sort Method";
pub const SORT_METHODS_USED: &str = "Sort Methods Used";
pub const SORT_SPACE_MEMORY: &str = "Sort Space Memory";
pub const SORT_SPACE_TYPE: &str = "Sort Space Type";
pub const SORT_SPACE_USED: &str = "Sort Space Used";
pub const STARTUP_COST: &str = "Startup Cost";
pub const STRATEGY: &str = "Strategy";
pub const SUBPLAN_NAME: &str = "Subplan Name";
pub const SUM_IO_READ_TIME: &str = "*I/O Read Time (all scopes)";
pub const SUM_IO_WRITE_TIME: &str = "*I/O Write Time (all scopes)";
pub const TEMP_IO_READ_TIME: &str = "Temp I/O Read Time";
pub const TEMP_IO_WRITE_TIME: &str = "Temp I/O Write Time";
pub const TEMP_READ_BLOCKS: &str = "Temp Read Blocks";
pub const TEMP_WRITTEN_BLOCKS: &str = "Temp Written Blocks";
pub const TOTAL_COST: &str = "Total Cost";
pub const WAL_BYTES: &str = "WAL Bytes";
pub const WAL_FPI: &str = "WAL FPI";
pub const WAL_RECORDS: &str = "WAL Records";
pub const WORKERS: &str = "Workers";
pub const WORKERS_LAUNCHED: &str = "Workers Launched";
pub const WORKERS_LAUNCHED_BY_GATHER: &str = "*Workers Launched By Gather";
pub const WORKERS_PLANNED: &str = "Workers Planned";
pub const WORKERS_PLANNED_BY_GATHER: &str = "*Workers Planned By Gather";
pub const WORKER_NUMBER: &str = "Worker Number";
pub const WRITTEN_BLOCKS: &str = "*Written Blocks";

pub const AVERAGE_IO_READ_SPEED: &str = "*I/O Read Speed";
pub const AVERAGE_IO_WRITE_SPEED: &str = "*I/O Write Speed";
pub const AVERAGE_LOCAL_IO_READ_SPEED: &str = "*Local I/O Read Speed";
pub const AVERAGE_LOCAL_IO_WRITE_SPEED: &str = "*Local I/O Write Speed";
pub const AVERAGE_SHARED_IO_READ_SPEED: &str = "*Shared I/O Read Speed";
pub const AVERAGE_SHARED_IO_WRITE_SPEED: &str = "*Shared I/O Write Speed";
pub const AVERAGE_SUM_IO_READ_SPEED: &str = "*I/O Read Time speed (all scopes)";
pub const AVERAGE_SUM_IO_WRITE_SPEED: &str = "*I/O Write Time speed (all scopes)";
pub const AVERAGE_TEMP_IO_READ_SPEED: &str = "*Temp I/O Read Speed";
pub const AVERAGE_TEMP_IO_WRITE_SPEED: &str = "*Temp I/O Write Speed";
pub const EXCLUSIVE_AVERAGE_IO_READ_SPEED: &str = "*I/O Read Speed (exclusive)";
pub const EXCLUSIVE_AVERAGE_IO_WRITE_SPEED: &str = "*I/O Write Speed (exclusive)";
pub const EXCLUSIVE_AVERAGE_LOCAL_IO_READ_SPEED: &str = "*Local I/O Read Speed (exclusive)";
pub const EXCLUSIVE_AVERAGE_LOCAL_IO_WRITE_SPEED: &str = "*Local I/O Write Speed (exclusive)";
pub const EXCLUSIVE_AVERAGE_SHARED_IO_READ_SPEED: &str = "*Shared I/O Read Speed (exclusive)";
pub const EXCLUSIVE_AVERAGE_SHARED_IO_WRITE_SPEED: &str = "*Shared I/O Write Speed (exclusive)";
pub const EXCLUSIVE_AVERAGE_SUM_IO_READ_SPEED: &str = "*I/O Read Time speed (exclusive, all scopes)";
pub const EXCLUSIVE_AVERAGE_SUM_IO_WRITE_SPEED: &str = "*I/O Write Time speed (exclusive, all scopes)";
pub const EXCLUSIVE_AVERAGE_TEMP_IO_READ_SPEED: &str = "*Temp I/O Read Speed (exclusive)";
pub const EXCLUSIVE_AVERAGE_TEMP_IO_WRITE_SPEED: &str = "*Temp I/O Write Speed (exclusive)";
pub const AVERAGE_SORT_SPACE_USED: &str = "Average Sort Space Used";

/// Map an upper-snake constant name (as built by the metric code) to the
/// corresponding output property string. Mirrors `Property[name]` lookups.
pub fn lookup(name: &str) -> Option<&'static str> {
    Some(match name {
        "ACTUAL_LOOPS" => ACTUAL_LOOPS,
        "ACTUAL_ROWS" => ACTUAL_ROWS,
        "ACTUAL_ROWS_FRACTIONAL" => ACTUAL_ROWS_FRACTIONAL,
        "ACTUAL_ROWS_REVISED" => ACTUAL_ROWS_REVISED,
        "ACTUAL_STARTUP_TIME" => ACTUAL_STARTUP_TIME,
        "ACTUAL_STARTUP_TIME_REVISED" => ACTUAL_STARTUP_TIME_REVISED,
        "ACTUAL_TOTAL_TIME" => ACTUAL_TOTAL_TIME,
        "ACTUAL_TOTAL_TIME_REVISED" => ACTUAL_TOTAL_TIME_REVISED,
        "ALIAS" => ALIAS,
        "ASYNC_CAPABLE" => ASYNC_CAPABLE,
        "AVERAGE_IO_READ_SPEED" => AVERAGE_IO_READ_SPEED,
        "AVERAGE_IO_WRITE_SPEED" => AVERAGE_IO_WRITE_SPEED,
        "AVERAGE_LOCAL_IO_READ_SPEED" => AVERAGE_LOCAL_IO_READ_SPEED,
        "AVERAGE_LOCAL_IO_WRITE_SPEED" => AVERAGE_LOCAL_IO_WRITE_SPEED,
        "AVERAGE_SHARED_IO_READ_SPEED" => AVERAGE_SHARED_IO_READ_SPEED,
        "AVERAGE_SHARED_IO_WRITE_SPEED" => AVERAGE_SHARED_IO_WRITE_SPEED,
        "AVERAGE_SUM_IO_READ_SPEED" => AVERAGE_SUM_IO_READ_SPEED,
        "AVERAGE_SUM_IO_WRITE_SPEED" => AVERAGE_SUM_IO_WRITE_SPEED,
        "AVERAGE_TEMP_IO_READ_SPEED" => AVERAGE_TEMP_IO_READ_SPEED,
        "AVERAGE_TEMP_IO_WRITE_SPEED" => AVERAGE_TEMP_IO_WRITE_SPEED,
        "CACHE_EVICTIONS" => CACHE_EVICTIONS,
        "CACHE_HITS" => CACHE_HITS,
        "CACHE_MISSES" => CACHE_MISSES,
        "CACHE_OVERFLOWS" => CACHE_OVERFLOWS,
        "CTE_NAME" => CTE_NAME,
        "DISABLED" => DISABLED,
        "DISK_USAGE" => DISK_USAGE,
        "EXCLUSIVE_COST" => EXCLUSIVE_COST,
        "EXCLUSIVE_DURATION" => EXCLUSIVE_DURATION,
        "EXCLUSIVE_IO_READ_TIME" => EXCLUSIVE_IO_READ_TIME,
        "EXCLUSIVE_IO_WRITE_TIME" => EXCLUSIVE_IO_WRITE_TIME,
        "EXCLUSIVE_LOCAL_DIRTIED_BLOCKS" => EXCLUSIVE_LOCAL_DIRTIED_BLOCKS,
        "EXCLUSIVE_LOCAL_HIT_BLOCKS" => EXCLUSIVE_LOCAL_HIT_BLOCKS,
        "EXCLUSIVE_LOCAL_IO_READ_TIME" => EXCLUSIVE_LOCAL_IO_READ_TIME,
        "EXCLUSIVE_LOCAL_IO_WRITE_TIME" => EXCLUSIVE_LOCAL_IO_WRITE_TIME,
        "EXCLUSIVE_LOCAL_READ_BLOCKS" => EXCLUSIVE_LOCAL_READ_BLOCKS,
        "EXCLUSIVE_LOCAL_WRITTEN_BLOCKS" => EXCLUSIVE_LOCAL_WRITTEN_BLOCKS,
        "EXCLUSIVE_READ_BLOCKS" => EXCLUSIVE_READ_BLOCKS,
        "EXCLUSIVE_SHARED_DIRTIED_BLOCKS" => EXCLUSIVE_SHARED_DIRTIED_BLOCKS,
        "EXCLUSIVE_SHARED_HIT_BLOCKS" => EXCLUSIVE_SHARED_HIT_BLOCKS,
        "EXCLUSIVE_SHARED_IO_READ_TIME" => EXCLUSIVE_SHARED_IO_READ_TIME,
        "EXCLUSIVE_SHARED_IO_WRITE_TIME" => EXCLUSIVE_SHARED_IO_WRITE_TIME,
        "EXCLUSIVE_SHARED_READ_BLOCKS" => EXCLUSIVE_SHARED_READ_BLOCKS,
        "EXCLUSIVE_SHARED_WRITTEN_BLOCKS" => EXCLUSIVE_SHARED_WRITTEN_BLOCKS,
        "EXCLUSIVE_SUM_IO_READ_TIME" => EXCLUSIVE_SUM_IO_READ_TIME,
        "EXCLUSIVE_SUM_IO_WRITE_TIME" => EXCLUSIVE_SUM_IO_WRITE_TIME,
        "EXCLUSIVE_TEMP_IO_READ_TIME" => EXCLUSIVE_TEMP_IO_READ_TIME,
        "EXCLUSIVE_TEMP_IO_WRITE_TIME" => EXCLUSIVE_TEMP_IO_WRITE_TIME,
        "EXCLUSIVE_TEMP_READ_BLOCKS" => EXCLUSIVE_TEMP_READ_BLOCKS,
        "EXCLUSIVE_TEMP_WRITTEN_BLOCKS" => EXCLUSIVE_TEMP_WRITTEN_BLOCKS,
        "EXCLUSIVE_WRITTEN_BLOCKS" => EXCLUSIVE_WRITTEN_BLOCKS,
        "EXCLUSIVE_AVERAGE_IO_READ_SPEED" => EXCLUSIVE_AVERAGE_IO_READ_SPEED,
        "EXCLUSIVE_AVERAGE_IO_WRITE_SPEED" => EXCLUSIVE_AVERAGE_IO_WRITE_SPEED,
        "EXCLUSIVE_AVERAGE_LOCAL_IO_READ_SPEED" => EXCLUSIVE_AVERAGE_LOCAL_IO_READ_SPEED,
        "EXCLUSIVE_AVERAGE_LOCAL_IO_WRITE_SPEED" => EXCLUSIVE_AVERAGE_LOCAL_IO_WRITE_SPEED,
        "EXCLUSIVE_AVERAGE_SHARED_IO_READ_SPEED" => EXCLUSIVE_AVERAGE_SHARED_IO_READ_SPEED,
        "EXCLUSIVE_AVERAGE_SHARED_IO_WRITE_SPEED" => EXCLUSIVE_AVERAGE_SHARED_IO_WRITE_SPEED,
        "EXCLUSIVE_AVERAGE_SUM_IO_READ_SPEED" => EXCLUSIVE_AVERAGE_SUM_IO_READ_SPEED,
        "EXCLUSIVE_AVERAGE_SUM_IO_WRITE_SPEED" => EXCLUSIVE_AVERAGE_SUM_IO_WRITE_SPEED,
        "EXCLUSIVE_AVERAGE_TEMP_IO_READ_SPEED" => EXCLUSIVE_AVERAGE_TEMP_IO_READ_SPEED,
        "EXCLUSIVE_AVERAGE_TEMP_IO_WRITE_SPEED" => EXCLUSIVE_AVERAGE_TEMP_IO_WRITE_SPEED,
        "FILTER" => FILTER,
        "FULL_SORT_GROUPS" => FULL_SORT_GROUPS,
        "FUNCTION_NAME" => FUNCTION_NAME,
        "GROUP_COUNT" => GROUP_COUNT,
        "GROUP_KEY" => GROUP_KEY,
        "GROUP_KEYS" => GROUP_KEYS,
        "GROUPING_SETS" => GROUPING_SETS,
        "HASHAGG_BATCHES" => HASHAGG_BATCHES,
        "HASH_BATCHES" => HASH_BATCHES,
        "HASH_BUCKETS" => HASH_BUCKETS,
        "HASH_CONDITION" => HASH_CONDITION,
        "HASH_KEY" => HASH_KEY,
        "HASH_KEYS" => HASH_KEYS,
        "HEAP_FETCHES" => HEAP_FETCHES,
        "INDEX_NAME" => INDEX_NAME,
        "IO_READ_TIME" => IO_READ_TIME,
        "IO_WRITE_TIME" => IO_WRITE_TIME,
        "JIT" => JIT,
        "JOIN_TYPE" => JOIN_TYPE,
        "LOCAL_DIRTIED_BLOCKS" => LOCAL_DIRTIED_BLOCKS,
        "LOCAL_HIT_BLOCKS" => LOCAL_HIT_BLOCKS,
        "LOCAL_IO_READ_TIME" => LOCAL_IO_READ_TIME,
        "LOCAL_IO_WRITE_TIME" => LOCAL_IO_WRITE_TIME,
        "LOCAL_READ_BLOCKS" => LOCAL_READ_BLOCKS,
        "LOCAL_WRITTEN_BLOCKS" => LOCAL_WRITTEN_BLOCKS,
        "MEMORY_ALLOCATED" => MEMORY_ALLOCATED,
        "MEMORY_USED" => MEMORY_USED,
        "NODE_ID" => NODE_ID,
        "NODE_TYPE" => NODE_TYPE,
        "OPERATION" => OPERATION,
        "ORIGINAL_HASH_BATCHES" => ORIGINAL_HASH_BATCHES,
        "ORIGINAL_HASH_BUCKETS" => ORIGINAL_HASH_BUCKETS,
        "OUTPUT" => OUTPUT,
        "PARALLEL_AWARE" => PARALLEL_AWARE,
        "PARENT_RELATIONSHIP" => PARENT_RELATIONSHIP,
        "PARTIAL_MODE" => PARTIAL_MODE,
        "PEAK_MEMORY_USAGE" => PEAK_MEMORY_USAGE,
        "PEAK_SORT_SPACE_USED" => PEAK_SORT_SPACE_USED,
        "PLANNED_PARTITIONS" => PLANNED_PARTITIONS,
        "PLANNER_ESTIMATE_DIRECTION" => PLANNER_ESTIMATE_DIRECTION,
        "PLANNER_ESTIMATE_FACTOR" => PLANNER_ESTIMATE_FACTOR,
        "PLANS" => PLANS,
        "PLAN_ROWS" => PLAN_ROWS,
        "PLAN_ROWS_REVISED" => PLAN_ROWS_REVISED,
        "PLAN_WIDTH" => PLAN_WIDTH,
        "READ_BLOCKS" => READ_BLOCKS,
        "RELATION_NAME" => RELATION_NAME,
        "ROWS_REMOVED_BY_FILTER" => ROWS_REMOVED_BY_FILTER,
        "ROWS_REMOVED_BY_FILTER_REVISED" => ROWS_REMOVED_BY_FILTER_REVISED,
        "ROWS_REMOVED_BY_INDEX_RECHECK" => ROWS_REMOVED_BY_INDEX_RECHECK,
        "ROWS_REMOVED_BY_INDEX_RECHECK_REVISED" => ROWS_REMOVED_BY_INDEX_RECHECK_REVISED,
        "ROWS_REMOVED_BY_JOIN_FILTER" => ROWS_REMOVED_BY_JOIN_FILTER,
        "ROWS_REMOVED_BY_JOIN_FILTER_REVISED" => ROWS_REMOVED_BY_JOIN_FILTER_REVISED,
        "SCAN_DIRECTION" => SCAN_DIRECTION,
        "SERIALIZATION" => SERIALIZATION,
        "SHARED_DIRTIED_BLOCKS" => SHARED_DIRTIED_BLOCKS,
        "SHARED_HIT_BLOCKS" => SHARED_HIT_BLOCKS,
        "SHARED_IO_READ_TIME" => SHARED_IO_READ_TIME,
        "SHARED_IO_WRITE_TIME" => SHARED_IO_WRITE_TIME,
        "SHARED_READ_BLOCKS" => SHARED_READ_BLOCKS,
        "SHARED_WRITTEN_BLOCKS" => SHARED_WRITTEN_BLOCKS,
        "SORT_KEY" => SORT_KEY,
        "SORT_METHOD" => SORT_METHOD,
        "SORT_METHODS_USED" => SORT_METHODS_USED,
        "SORT_SPACE_MEMORY" => SORT_SPACE_MEMORY,
        "SORT_SPACE_TYPE" => SORT_SPACE_TYPE,
        "SORT_SPACE_USED" => SORT_SPACE_USED,
        "STARTUP_COST" => STARTUP_COST,
        "STRATEGY" => STRATEGY,
        "SUBPLAN_NAME" => SUBPLAN_NAME,
        "SUM_IO_READ_TIME" => SUM_IO_READ_TIME,
        "SUM_IO_WRITE_TIME" => SUM_IO_WRITE_TIME,
        "TEMP_IO_READ_TIME" => TEMP_IO_READ_TIME,
        "TEMP_IO_WRITE_TIME" => TEMP_IO_WRITE_TIME,
        "TEMP_READ_BLOCKS" => TEMP_READ_BLOCKS,
        "TEMP_WRITTEN_BLOCKS" => TEMP_WRITTEN_BLOCKS,
        "TOTAL_COST" => TOTAL_COST,
        "WAL_BYTES" => WAL_BYTES,
        "WAL_FPI" => WAL_FPI,
        "WAL_RECORDS" => WAL_RECORDS,
        "WORKERS" => WORKERS,
        "WORKERS_LAUNCHED" => WORKERS_LAUNCHED,
        "WORKERS_LAUNCHED_BY_GATHER" => WORKERS_LAUNCHED_BY_GATHER,
        "WORKERS_PLANNED" => WORKERS_PLANNED,
        "WORKERS_PLANNED_BY_GATHER" => WORKERS_PLANNED_BY_GATHER,
        "WORKER_NUMBER" => WORKER_NUMBER,
        "WRITTEN_BLOCKS" => WRITTEN_BLOCKS,
        _ => return None,
    })
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum BufferLocation {
    Shared,
    Temp,
    Local,
}

impl BufferLocation {
    pub fn as_str(self) -> &'static str {
        match self {
            BufferLocation::Shared => "Shared",
            BufferLocation::Temp => "Temp",
            BufferLocation::Local => "Local",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Scope {
    Shared,
    Local,
    Temp,
}

impl Scope {
    pub fn as_str(self) -> &'static str {
        match self {
            Scope::Shared => "shared",
            Scope::Local => "local",
            Scope::Temp => "temp",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum EstimateDirection {
    Over = 1,
    Under = 2,
    None = 3,
}
