/**
 * Mock GitLab API Server for Testing
 * Implements minimal GitLab API endpoints for testing remote authorization
 */

import express, { Request, Response, NextFunction, Handler } from "express";
import { Server } from "http";

export interface MockGitLabConfig {
  port: number;
  validTokens: string[];
  /** Artificial delay for all responses (ms) - useful for timeout testing */
  responseDelay?: number;
  /** Simulate rate limiting - return 429 after N requests */
  rateLimitAfter?: number;
}

interface AuthenticatedRequest extends Request {
  gitlabToken?: string;
}

export class MockGitLabServer {
  private app: express.Application;
  private server: Server | null = null;
  private config: MockGitLabConfig;
  private requestCount = 0;
  private customRouter: express.Router;
  private customHandlers = new Map<string, Handler>();
  // Root-level dynamic router (for OAuth paths not under /api/v4)
  private rootRouter: express.Router;
  private rootHandlers = new Map<string, Handler>();
  // In-memory store for mutable resources (issues, etc.)
  private issueStore: Map<string, Record<string, any>> = new Map();

  constructor(config: MockGitLabConfig) {
    this.config = config;
    this.app = express();
    this.customRouter = express.Router();
    this.rootRouter = express.Router();

    // Dynamic dispatcher for /api/v4 handlers
    this.customRouter.use((req, res, next) => {
      // Create a key from method and path (relative to /api/v4)
      // req.path is already relative to the mount point
      const key = `${req.method.toUpperCase()}:${req.path}`;
      console.log(`[CustomRouter] Checking key: '${key}'`);
      const handler = this.customHandlers.get(key);

      if (handler) {
        console.log(`[MockServer] Custom handler hit: ${key}`);
        return handler(req, res, next);
      } else {
        console.log(
          `[CustomRouter] No handler found for key: '${key}'. Available keys: ${Array.from(this.customHandlers.keys()).join(", ")}`
        );
      }
      next();
    });

    // Dynamic dispatcher for root-level handlers (OAuth endpoints, well-known, etc.)
    this.rootRouter.use((req, res, next) => {
      const key = `${req.method.toUpperCase()}:${req.path}`;
      const handler = this.rootHandlers.get(key);
      if (handler) {
        console.log(`[MockServer] Root handler hit: ${key}`);
        return handler(req, res, next);
      }
      next();
    });

    this.setupMiddleware();
    // Root router must be mounted BEFORE setupRoutes() installs the catch-all
    this.app.use(this.rootRouter);
    this.app.use("/api/v4", this.customRouter); // Mount router on API path
    this.setupRoutes();
  }

  public addMockHandler(method: "get" | "post" | "put" | "delete", path: string, handler: Handler) {
    // Note: path should be relative to /api/v4
    const key = `${method.toUpperCase()}:${path}`;
    console.log(`[MockServer] Adding custom handler: ${key}`);
    this.customHandlers.set(key, handler);
  }

  /**
   * Add a route at the instance root (not under /api/v4).
   * Use this for OAuth endpoints (/oauth/*, /.well-known/*) that GitLab
   * serves at the instance root rather than under the API prefix.
   */
  public addRootHandler(method: "get" | "post" | "put" | "delete", path: string, handler: Handler) {
    const key = `${method.toUpperCase()}:${path}`;
    console.log(`[MockServer] Adding root handler: ${key}`);
    this.rootHandlers.set(key, handler);
  }

  public clearCustomHandlers() {
    console.log("[MockServer] Clearing custom handlers");
    this.customHandlers.clear();
  }

  /**
   * Setup middleware including auth validation
   */
  private setupMiddleware() {
    // Request counter for rate limiting tests - Place this FIRST to log everything
    this.app.use((req: Request, res: Response, next: NextFunction) => {
      console.log(`[MockServer] ${req.method} ${req.originalUrl}`);
      this.requestCount++;
      next();
    });

    this.app.use(express.json());

    // Artificial delay middleware (for timeout testing)
    if (this.config.responseDelay) {
      this.app.use((req: Request, res: Response, next: NextFunction) => {
        setTimeout(next, this.config.responseDelay);
      });
    }

    // Rate limiting middleware
    if (this.config.rateLimitAfter) {
      this.app.use((req: Request, res: Response, next: NextFunction) => {
        if (this.requestCount > this.config.rateLimitAfter!) {
          res.status(429).json({
            message: "Rate limit exceeded",
            retry_after: 60,
          });
          return;
        }
        next();
      });
    }

    // Authentication middleware - applies to all /api/v4/* routes
    this.app.use("/api/v4", (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
      const authHeader = req.headers["authorization"] as string | undefined;
      const privateToken = req.headers["private-token"] as string | undefined;
      const jobToken = req.headers["job-token"] as string | undefined;

      let token: string | null = null;

      if (jobToken) {
        token = jobToken.trim();
      } else if (authHeader) {
        // Extract token from "Bearer <token>"
        const match = authHeader.match(/^Bearer\s+(.+)$/i);
        token = match ? match[1].trim() : null;
      } else if (privateToken) {
        token = privateToken.trim();
      }

      if (!token) {
        res.status(401).json({
          message: "Unauthorized",
          error: "Missing authentication token",
        });
        return;
      }

      if (!this.config.validTokens.includes(token)) {
        res.status(401).json({
          message: "Unauthorized",
          error: "Invalid authentication token",
        });
        return;
      }

      // Store validated token in request
      req.gitlabToken = token;
      next();
    });
  }

  private setupRoutes() {
    // GET /api/v4/user - Get current user
    this.app.get("/api/v4/user", (req: AuthenticatedRequest, res: Response) => {
      const token = req.gitlabToken || "unknown";
      res.json({
        id: 1,
        username: `user_${token.substring(0, 8)}`,
        name: "Test User",
        email: "test@example.com",
        state: "active",
      });
    });

    // GET /api/v4/version - GitLab instance version
    this.app.get("/api/v4/version", (_req: AuthenticatedRequest, res: Response) => {
      res.json({
        version: "18.3.1-ee",
        revision: "abc1234",
        enterprise: true,
      });
    });

    // GET /api/v4/projects/:projectId - Get project
    this.app.get("/api/v4/projects/:projectId", (req: AuthenticatedRequest, res: Response) => {
      const projectId = req.params.projectId;
      res.json({
        id: parseInt(projectId) || 123,
        name: "Test Project",
        path: "test-project",
        path_with_namespace: "test-group/test-project",
        description: "A mock test project",
        visibility: "private",
        created_at: "2024-01-01T00:00:00Z",
        web_url: `https://gitlab.mock/project/${projectId}`,
        namespace: {
          id: 1,
          name: "Test Group",
          path: "test-group",
          kind: "group",
          full_path: "test-group",
        },
      });
    });

    // GET /api/v4/merge_requests - List all merge requests (global)
    this.app.get("/api/v4/merge_requests", (req: AuthenticatedRequest, res: Response) => {
      res.json([
        {
          id: 1,
          iid: 1,
          project_id: 123,
          title: "Test MR 1",
          description: "Description for MR 1",
          state: "opened",
          created_at: "2024-01-01T00:00:00Z",
          updated_at: "2024-01-01T00:00:00Z",
          merged_at: null,
          closed_at: null,
          target_branch: "main",
          source_branch: "feature-1",
          web_url: "https://gitlab.mock/project/123/merge_requests/1",
          merge_commit_sha: null,
          author: {
            id: 1,
            username: "test-user",
            name: "Test User",
          },
        },
        {
          id: 2,
          iid: 2,
          project_id: 123,
          title: "Test MR 2",
          description: "Description for MR 2",
          state: "merged",
          created_at: "2024-01-02T00:00:00Z",
          updated_at: "2024-01-03T00:00:00Z",
          merged_at: "2024-01-03T00:00:00Z",
          closed_at: null,
          target_branch: "main",
          source_branch: "feature-2",
          web_url: "https://gitlab.mock/project/123/merge_requests/2",
          merge_commit_sha: "abcdef1234567890",
          author: {
            id: 1,
            username: "test-user",
            name: "Test User",
          },
        },
      ]);
    });

    // GET /api/v4/projects/:projectId/merge_requests - List merge requests
    this.app.get(
      "/api/v4/projects/:projectId/merge_requests",
      (req: AuthenticatedRequest, res: Response) => {
        res.json([
          {
            id: 1,
            iid: 1,
            project_id: 123,
            title: "Test MR 1",
            description: "Description for MR 1",
            state: "opened",
            created_at: "2024-01-01T00:00:00Z",
            updated_at: "2024-01-01T00:00:00Z",
            merged_at: null,
            closed_at: null,
            target_branch: "main",
            source_branch: "feature-1",
            web_url: "https://gitlab.mock/project/123/merge_requests/1",
            merge_commit_sha: null,
            author: {
              id: 1,
              username: "test-user",
              name: "Test User",
            },
          },
          {
            id: 2,
            iid: 2,
            project_id: 123,
            title: "Test MR 2",
            description: "Description for MR 2",
            state: "merged",
            created_at: "2024-01-02T00:00:00Z",
            updated_at: "2024-01-03T00:00:00Z",
            merged_at: "2024-01-03T00:00:00Z",
            closed_at: null,
            target_branch: "main",
            source_branch: "feature-2",
            web_url: "https://gitlab.mock/project/123/merge_requests/2",
            merge_commit_sha: "abcdef1234567890",
            author: {
              id: 1,
              username: "test-user",
              name: "Test User",
            },
          },
        ]);
      }
    );

    // GET /api/v4/projects/:projectId/merge_requests/:mr_iid - Get single MR
    this.app.get(
      "/api/v4/projects/:projectId/merge_requests/:mr_iid",
      (req: AuthenticatedRequest, res: Response) => {
        const mrIid = parseInt(req.params.mr_iid);
        res.json({
          id: mrIid,
          iid: mrIid,
          title: `Test MR ${mrIid}`,
          state: "opened",
          created_at: "2024-01-01T00:00:00Z",
          author: {
            id: 1,
            username: "test-user",
            name: "Test User",
          },
          source_branch: "feature-branch",
          target_branch: "main",
          merge_status: "can_be_merged",
        });
      }
    );

    // GET /api/v4/projects/:projectId/issues - List issues
    this.app.get(
      "/api/v4/projects/:projectId/issues",
      (req: AuthenticatedRequest, res: Response) => {
        const projectId = req.params.projectId;
        res.json([
          {
            id: 1,
            iid: 1,
            project_id: projectId,
            title: "Test Issue 1",
            description: "Test issue description",
            state: "opened",
            created_at: "2024-01-01T00:00:00Z",
            updated_at: "2024-01-02T00:00:00Z",
            closed_at: null,
            web_url: `https://gitlab.mock/project/${projectId}/issues/1`,
            author: {
              id: 1,
              username: "test-user",
              name: "Test User",
              avatar_url: null,
              web_url: "https://gitlab.mock/test-user",
            },
            assignees: [],
            labels: [],
            milestone: null,
          },
        ]);
      }
    );

    // GET /api/v4/projects/:projectId/issues/:issue_iid - Get single issue
    this.app.get(
      "/api/v4/projects/:projectId/issues/:issue_iid",
      (req: AuthenticatedRequest, res: Response) => {
        const issueIid = parseInt(req.params.issue_iid);
        const projectId = req.params.projectId;
        const storeKey = `${projectId}:${issueIid}`;
        const stored = this.issueStore.get(storeKey);
        if (stored) {
          res.json(stored);
          return;
        }
        res.json({
          id: issueIid,
          iid: issueIid,
          project_id: projectId,
          title: `Test Issue ${issueIid}`,
          description: `Description for issue ${issueIid}`,
          state: "opened",
          created_at: "2024-01-01T00:00:00Z",
          updated_at: "2024-01-02T00:00:00Z",
          closed_at: null,
          web_url: `https://gitlab.mock/project/${projectId}/issues/${issueIid}`,
          author: {
            id: 1,
            username: "test-user",
            name: "Test User",
            avatar_url: null,
            web_url: "https://gitlab.mock/test-user",
          },
          assignees: [],
          labels: [],
          milestone:
            issueIid === 100
              ? {
                  id: 42,
                  iid: 7,
                  title: "Sprint 42",
                  description: "A very long milestone description ".repeat(50),
                  state: "active",
                  web_url: `https://gitlab.mock/project/${projectId}/milestones/7`,
                }
              : null,
        });
      }
    );

    // PUT /api/v4/projects/:projectId/issues/:issue_iid - Update issue
    this.app.put(
      "/api/v4/projects/:projectId/issues/:issue_iid",
      (req: AuthenticatedRequest, res: Response) => {
        const issueIid = parseInt(req.params.issue_iid);
        const projectId = req.params.projectId;
        const storeKey = `${projectId}:${issueIid}`;

        // Build response from stored data (if previously updated) or defaults
        const stored = this.issueStore.get(storeKey) || {};
        const description = (req.body?.description as string) ?? stored.description ?? `Description for issue ${issueIid}`;
        const title = (req.body?.title as string) ?? stored.title ?? `Test Issue ${issueIid}`;
        const state = (req.body?.state_event as string) === "close" ? "closed" :
                      (req.body?.state_event as string) === "reopen" ? "opened" :
                      (stored.state ?? "opened");

        const updatedIssue = {
          id: issueIid,
          iid: issueIid,
          project_id: projectId,
          title,
          description,
          state,
          created_at: stored.created_at ?? "2024-01-01T00:00:00Z",
          updated_at: new Date().toISOString(),
          closed_at: state === "closed" ? new Date().toISOString() : null,
          web_url: `https://gitlab.mock/project/${projectId}/issues/${issueIid}`,
          author: {
            id: 1,
            username: "test-user",
            name: "Test User",
            avatar_url: null,
            web_url: "https://gitlab.mock/test-user",
          },
          assignees: [],
          labels: [],
          milestone: null,
        };

        // Store for subsequent GET requests
        this.issueStore.set(storeKey, updatedIssue);

        res.json(updatedIssue);
      }
    );

    // Mock blob search result
    const mockBlobResults = [
      {
        basename: "index",
        data: "const searchResult = true;",
        path: "src/index.ts",
        filename: "index.ts",
        id: null,
        ref: "main",
        startline: 42,
        project_id: 1,
      }
    ];

    // GET /api/v4/search - Global search
    this.app.get('/api/v4/search', (req: AuthenticatedRequest, res: Response) => {
      if (req.query.scope === 'blobs') {
        res.json(mockBlobResults);
      } else {
        res.json([]);
      }
    });

    // GET /api/v4/projects/:id/search - Project-level search
    this.app.get('/api/v4/projects/:id/search', (req: AuthenticatedRequest, res: Response) => {
      if (req.query.scope === 'blobs') {
        // Return req.params.id as string — Express decodes the URL param, so this
        // reflects whether the caller properly single-encoded the path segment.
        const results = mockBlobResults.map(r => ({ ...r, project_id: req.params.id }));
        res.json(results);
      } else {
        res.json([]);
      }
    });

    // GET /api/v4/groups/:id/search - Group-level search
    this.app.get('/api/v4/groups/:id/search', (req: AuthenticatedRequest, res: Response) => {
      if (req.query.scope === 'blobs') {
        // Echo the decoded group ID in the ref field so tests can verify encoding
        const results = mockBlobResults.map(r => ({ ...r, ref: req.params.id }));
        res.json(results);
      } else {
        res.json([]);
      }
    });

    // GET /api/v4/projects - List projects
    this.app.get("/api/v4/projects", (req: AuthenticatedRequest, res: Response) => {
      res.json([
        {
          id: 123,
          name: "Test Project",
          path: "test-project",
          path_with_namespace: "test-group/test-project",
          description: "A mock test project",
          visibility: "private",
          namespace: {
            id: 1,
            name: "Test Group",
            path: "test-group",
            kind: "group",
            full_path: "test-group",
          },
        },
      ]);
    });

    // GET /api/v4/projects/:projectId/merge_requests/:mr_iid/changes - Get MR diffs
    this.app.get(
      "/api/v4/projects/:projectId/merge_requests/:mr_iid/changes",
      (req: AuthenticatedRequest, res: Response) => {
        const mrIid = parseInt(req.params.mr_iid);
        res.json({
          id: mrIid,
          iid: mrIid,
          project_id: parseInt(req.params.projectId),
          title: `Test MR ${mrIid}`,
          state: "opened",
          created_at: "2024-01-01T00:00:00Z",
          changes: [
            {
              old_path: "src/index.ts",
              new_path: "src/index.ts",
              a_mode: "100644",
              b_mode: "100644",
              diff: "@@ -1,1 +1,2 @@\n-line 1\n+line 1 modified\n+new line 2\n",
              new_file: false,
              renamed_file: false,
              deleted_file: false,
            },
            {
              old_path: "vendor/package/file.js",
              new_path: "vendor/package/file.js",
              a_mode: "100644",
              b_mode: "100644",
              diff: "@@ -1,1 +1,1 @@\n-vendor content old\n+vendor content new\n",
              new_file: false,
              renamed_file: false,
              deleted_file: false,
            },
            {
              old_path: "README.md",
              new_path: "README.md",
              a_mode: "100644",
              b_mode: "100644",
              diff: "@@ -1,1 +1,1 @@\n-old readme\n+new readme\n",
              new_file: false,
              renamed_file: false,
              deleted_file: false,
            },
            {
              old_path: "package-lock.json",
              new_path: "package-lock.json",
              a_mode: "100644",
              b_mode: "100644",
              diff: '{\n- "version": "1.0.0"\n+ "version": "1.0.1"\n}\n',
              new_file: false,
              renamed_file: false,
              deleted_file: false,
            },
          ],
        });
      }
    );

    // GET /api/v4/projects/:projectId/merge_requests/:mr_iid/diffs - Get paginated diffs
    this.app.get('/api/v4/projects/:projectId/merge_requests/:mr_iid/diffs', (req: AuthenticatedRequest, res: Response) => {
      const mrIid = parseInt(req.params.mr_iid);
      
      // Paginate results for testing pagination logic
      const allDiffs = [
        { new_path: 'src/index.ts', old_path: 'src/index.ts' },
        { new_path: 'vendor/package/file.js', old_path: 'vendor/package/file.js' },
        { new_path: 'README.md', old_path: 'README.md' },
        { new_path: 'package-lock.json', old_path: 'package-lock.json' },
        { new_path: 'config/settings.yml', old_path: 'config/settings.yml' },
        { new_path: 'lib/utils/helper.rb', old_path: 'lib/utils/helper.rb' },
        { new_path: 'test/unit_test.py', old_path: 'test/unit_test.py' },
        { new_path: 'docs/api.md', old_path: 'docs/api.md' },
        { new_path: 'assets/style.css', old_path: 'assets/style.css' },
        { new_path: 'scripts/build.sh', old_path: 'scripts/build.sh' },
        { new_path: 'src/app.component.ts', old_path: 'src/app.component.ts' },
        { new_path: 'views/layout.ejs', old_path: 'views/layout.eis' },
        { new_path: 'models/user.go', old_path: 'models/user.go' },
        { new_path: 'controllers/controller.rs', old_path: 'controllers/controller.rs' },
        { new_path: 'database/schema.sql', old_path: 'database/schema.sql' }
      ];
      
      // Parse pagination params
      const page = parseInt(req.query.page as string) || 1;
      const perPage = parseInt(req.query.per_page as string) || 20;
      
      const startIdx = (page - 1) * perPage;
      const endIdx = startIdx + perPage;
      const paginatedDiffs = allDiffs.slice(startIdx, endIdx);
      
      res.json(paginatedDiffs);
    });

    // Health check endpoint
    this.app.get("/health", (req: Request, res: Response) => {
      res.json({ status: "ok", message: "Mock GitLab API is running" });
    });

    // Catch-all for unimplemented endpoints
    this.app.use((req: Request, res: Response) => {
      console.log(`Mock GitLab: Unimplemented endpoint: ${req.method} ${req.path}`);
      res.status(404).json({
        message: "404 Not Found",
        error: "Endpoint not implemented in mock server",
      });
    });
  }

  async start(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.server = this.app.listen(this.config.port, "127.0.0.1", () => {
        const address = this.server?.address();
        if (typeof address === "object" && address) {
          this.config.port = address.port;
        }
        console.log(`Mock GitLab API listening on http://127.0.0.1:${this.config.port}`);
        resolve();
      });
      this.server.once("error", reject);
    });
  }

  async stop(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (this.server) {
        this.server.close(err => {
          if (err) reject(err);
          else {
            console.log("Mock GitLab API stopped");
            resolve();
          }
        });
      } else {
        resolve();
      }
    });
  }

  getUrl(): string {
    return `http://127.0.0.1:${this.config.port}`;
  }

  getPort(): number {
    return this.config.port;
  }
}

/**
 * Helper to find available port for mock server (OS-assigned ephemeral port).
 * Returns 0 to signal MockGitLabServer.start() to use OS-assigned port,
 * avoiding TOCTOU race where another test grabs the port before binding.
 */
export async function findMockServerPort(): Promise<number> {
  return 0;
}

/**
 * Reset request counter (useful for rate limit testing)
 */
export function resetMockServerState(server: MockGitLabServer) {
  (server as any).requestCount = 0;
}
