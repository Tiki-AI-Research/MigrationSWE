/**
 * Remote Authorization Test Suite
 * Tests remote auth functionality with mock GitLab server
 */

import { describe, test, after, before } from 'node:test';
import assert from 'node:assert';
import {
  launchServer,
  findAvailablePort,
  cleanupServers,
  ServerInstance,
  TransportMode,
  HOST
} from './utils/server-launcher.js';
import { MockGitLabServer, findMockServerPort } from './utils/mock-gitlab-server.js';
import { CustomHeaderClient } from './clients/custom-header-client.js';

// Test constants
const MOCK_TOKEN = 'glpat-mock-token-12345';
const MOCK_JOB_TOKEN = 'glcbt-mock-job-token-9876';

// Port ranges to avoid collisions
const MOCK_GITLAB_PORT_BASE = 9000;
const MOCK_GITLAB_PORT_OFFSET = 500; // Offset for timeout test suite
const MCP_SERVER_PORT_BASE = 3000;
const MCP_SERVER_PORT_OFFSET = 500; // Offset for timeout test suite

// Timeout settings
const SESSION_TIMEOUT_SECONDS = 3;
const TIMEOUT_BUFFER_MS = 1000; // Extra time beyond timeout to ensure expiration
const TIMEOUT_TEST_WAIT_MS = SESSION_TIMEOUT_SECONDS * 1000 + TIMEOUT_BUFFER_MS;
const KEEPALIVE_INTERVAL_MS = 2000; // Must be less than SESSION_TIMEOUT_SECONDS
const KEEPALIVE_REQUEST_COUNT = 3; // Number of keepalive requests to test

async function getMetrics(mcpUrl: string): Promise<{ activeSessions: number; authenticatedSessions: number }> {
  const metricsUrl = mcpUrl.replace(/\/mcp$/, '/metrics.json');
  const response = await fetch(metricsUrl);
  assert.strictEqual(response.status, 200, 'metrics JSON endpoint should be available');
  return (await response.json()) as { activeSessions: number; authenticatedSessions: number };
}

async function waitForSessionDecrease(
  mcpUrl: string,
  beforeTimeout: { activeSessions: number; authenticatedSessions: number },
  timeoutMs = 3000
): Promise<void> {
  const startedAt = Date.now();
  let last = await getMetrics(mcpUrl);

  while (Date.now() - startedAt < timeoutMs) {
    if (
      last.activeSessions < beforeTimeout.activeSessions &&
      last.authenticatedSessions < beforeTimeout.authenticatedSessions
    ) {
      return;
    }
    await new Promise(resolve => setTimeout(resolve, 100));
    last = await getMetrics(mcpUrl);
  }

  assert.ok(
    last.activeSessions < beforeTimeout.activeSessions,
    `activeSessions should decrease after timeout (${last.activeSessions} !< ${beforeTimeout.activeSessions})`
  );
  assert.ok(
    last.authenticatedSessions < beforeTimeout.authenticatedSessions,
    `authenticatedSessions should decrease after timeout (${last.authenticatedSessions} !< ${beforeTimeout.authenticatedSessions})`
  );
}

console.log('🔐 Remote Authorization Test Suite');
console.log('');

describe('Remote Authorization', { concurrency: 1 }, () => {
describe('Remote Authorization - Basic Functionality', () => {
  let mcpUrl: string;
  let mockGitLab: MockGitLabServer;
  let servers: ServerInstance[] = [];

  before(async () => {
    // Start mock GitLab server
    const mockPort = await findMockServerPort();
    mockGitLab = new MockGitLabServer({
      port: mockPort,
      validTokens: [MOCK_TOKEN, MOCK_JOB_TOKEN],
    });
    await mockGitLab.start();
    const mockGitLabUrl = mockGitLab.getUrl();

    // Start MCP server with remote auth
    const mcpPort = await findAvailablePort(MCP_SERVER_PORT_BASE);
    const server = await launchServer({
      mode: TransportMode.STREAMABLE_HTTP,
      port: mcpPort,
      timeout: 5000,
      env: {
        STREAMABLE_HTTP: 'true',
        REMOTE_AUTHORIZATION: 'true',
        GITLAB_API_URL: `${mockGitLabUrl}/api/v4`,
        GITLAB_READ_ONLY_MODE: 'true',
      }
    });
    servers.push(server);
    mcpUrl = `http://${HOST}:${mcpPort}/mcp`;

    console.log(`Mock GitLab: ${mockGitLabUrl}`);
    console.log(`MCP Server: ${mcpUrl}`);
  });

  after(async () => {
    cleanupServers(servers);
    if (mockGitLab) {
      await mockGitLab.stop();
    }
  });

  test('should reject invalid tokens before creating a session', async () => {
    const before = await getMetrics(mcpUrl);
    const response = await fetch(mcpUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json, text/event-stream',
        'Private-Token': 'aaaaaaaaaaaaaaaaaaaaaaaa',
      },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'initialize',
        params: {
          protocolVersion: '2025-03-26',
          capabilities: {},
          clientInfo: { name: 'invalid-token-test', version: '1.0.0' },
        },
      }),
    });

    assert.strictEqual(response.status, 401);
    const after = await getMetrics(mcpUrl);
    assert.strictEqual(after.activeSessions, before.activeSessions);
    assert.strictEqual(after.authenticatedSessions, before.authenticatedSessions);
  });

  test('should connect with Authorization Bearer header', async () => {
    const client = new CustomHeaderClient({
      'authorization': `Bearer ${MOCK_TOKEN}`
    });

    await client.connect(mcpUrl);
    const tools = await client.listTools();

    assert.ok(tools.tools.length > 0, 'Should have tools');
    console.log(`  ✓ Connected successfully, got ${tools.tools.length} tools`);

    await client.disconnect();
  });

  test('should connect with Private-Token header', async () => {
    const client = new CustomHeaderClient({
      'private-token': MOCK_TOKEN
    });

    await client.connect(mcpUrl);
    const tools = await client.listTools();

    assert.ok(tools.tools.length > 0, 'Should have tools');
    console.log(`  ✓ Connected with Private-Token, got ${tools.tools.length} tools`);

    await client.disconnect();
  });

  test('should connect with JOB-TOKEN header', async () => {
    const client = new CustomHeaderClient({
      'job-token': MOCK_JOB_TOKEN,
    });

    await client.connect(mcpUrl);
    const tools = await client.listTools();

    assert.ok(tools.tools.length > 0, 'Should have tools');
    console.log(`  ✓ Connected with JOB-TOKEN, got ${tools.tools.length} tools`);

    await client.disconnect();
  });

  test('should successfully call listTools with auth', async () => {
    const client = new CustomHeaderClient({
      'authorization': `Bearer ${MOCK_TOKEN}`
    });

    await client.connect(mcpUrl);

    // List tools multiple times to verify auth persists
    const tools1 = await client.listTools();
    const tools2 = await client.listTools();
    const tools3 = await client.listTools();

    assert.ok(tools1.tools.length > 0, 'Should have tools');
    assert.strictEqual(tools1.tools.length, tools2.tools.length, 'Tool count should be consistent');
    assert.strictEqual(tools2.tools.length, tools3.tools.length, 'Tool count should be consistent');
    console.log('  ✓ Multiple tool list calls successful with persistent auth');

    await client.disconnect();
  });

  test('should expose Prometheus metrics at /metrics', async () => {
    const metricsUrl = mcpUrl.replace(/\/mcp$/, '/metrics');
    const response = await fetch(metricsUrl);
    assert.strictEqual(response.status, 200, 'metrics endpoint should be available');
    assert.match(response.headers.get('content-type') || '', /^text\/plain/);

    const body = await response.text();
    assert.match(body, /# HELP gitlab_mcp_requests_processed_total/);
    assert.match(body, /# TYPE gitlab_mcp_active_sessions gauge/);
    assert.match(body, /gitlab_mcp_config_info\{[^}]*remote_auth_enabled="true"/);
    console.log('  ✓ Prometheus metrics available');
  });

  test('should reject connection without auth header', async () => {
    const client = new CustomHeaderClient({});

    try {
      await client.connect(mcpUrl);
      await client.listTools();
      await client.disconnect();
      assert.fail('Should have rejected connection without auth');
    } catch (error) {
      assert.ok(error instanceof Error);
      console.log('  ✓ Correctly rejected connection without auth');
    }
  });
});

describe('Remote Authorization - Session Timeout', () => {
  let mcpUrl: string;
  let mockGitLab: MockGitLabServer;
  let servers: ServerInstance[] = [];

  before(async () => {
    // Use different port ranges to avoid collisions with basic tests
    const mockPort = await findMockServerPort();
    mockGitLab = new MockGitLabServer({
      port: mockPort,
      validTokens: [MOCK_TOKEN]
    });
    await mockGitLab.start();
    const mockGitLabUrl = mockGitLab.getUrl();

    const mcpPort = await findAvailablePort(MCP_SERVER_PORT_BASE + MCP_SERVER_PORT_OFFSET);
    const server = await launchServer({
      mode: TransportMode.STREAMABLE_HTTP,
      port: mcpPort,
      timeout: 5000,
      env: {
        STREAMABLE_HTTP: 'true',
        REMOTE_AUTHORIZATION: 'true',
        GITLAB_API_URL: `${mockGitLabUrl}/api/v4`,
        SESSION_TIMEOUT_SECONDS: String(SESSION_TIMEOUT_SECONDS),
      }
    });
    servers.push(server);
    mcpUrl = `http://${HOST}:${mcpPort}/mcp`;

    console.log(`Session timeout: ${SESSION_TIMEOUT_SECONDS} seconds`);
  });

  after(async () => {
    cleanupServers(servers);
    if (mockGitLab) {
      await mockGitLab.stop();
    }
  });

  test('session timeout verification - activity keeps session alive', async () => {
    const client = new CustomHeaderClient({
      'authorization': `Bearer ${MOCK_TOKEN}`
    });

    // Connect and verify it works
    await client.connect(mcpUrl);
    const tools1 = await client.listTools();
    assert.ok(tools1.tools.length > 0, 'Initial connection should work');
    console.log('  ✓ Initial connection successful');

    // Keep connection alive with periodic requests
    console.log('  Keeping session alive with requests...');
    for (let i = 0; i < KEEPALIVE_REQUEST_COUNT; i++) {
      await new Promise(resolve => setTimeout(resolve, KEEPALIVE_INTERVAL_MS));
      const tools = await client.listTools();
      assert.ok(tools.tools.length > 0, `Request ${i + 1} should succeed`);
      console.log(`  ✓ Request ${i + 1} succeeded (session still alive)`);
    }

    await client.disconnect();
    console.log('  ✓ Session remained active with periodic requests');
  });

  test('session timeout expiration - inactivity expires auth', async () => {
    // Add a small delay to ensure server is ready/clean from previous test
    await new Promise(resolve => setTimeout(resolve, 1000));

    const baseline = await getMetrics(mcpUrl);

    // Step 1: Connect WITH auth header to establish session
    const clientWithAuth = new CustomHeaderClient({
      'authorization': `Bearer ${MOCK_TOKEN}`
    });
    await clientWithAuth.connect(mcpUrl);
    const tools1 = await clientWithAuth.listTools();
    assert.ok(tools1.tools.length > 0, 'Initial connection should work');
    console.log('  ✓ Initial connection successful with auth');

    // Extract session ID using proper API
    const sessionId = clientWithAuth.getSessionId();
    assert.ok(sessionId, 'Session ID should exist');
    console.log(`  ℹ️  Session ID: ${sessionId}`);

    const beforeTimeout = await getMetrics(mcpUrl);
    assert.strictEqual(
      beforeTimeout.activeSessions,
      baseline.activeSessions + 1,
      'Session should occupy one additional active slot'
    );
    assert.strictEqual(
      beforeTimeout.authenticatedSessions,
      baseline.authenticatedSessions + 1,
      'Session should add one authenticated session'
    );

    // Step 2: Wait for timeout WITHOUT making any requests
    console.log(`  ⏳ Waiting ${TIMEOUT_TEST_WAIT_MS/1000}s for timeout without activity...`);
    await new Promise(resolve => setTimeout(resolve, TIMEOUT_TEST_WAIT_MS));

    await waitForSessionDecrease(mcpUrl, beforeTimeout);
    console.log('  ✓ Timeout closed transport and released active session slot');

    // Step 3: A stale stateful session must return the MCP re-initialization signal.
    const response = await fetch(mcpUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'mcp-session-id': sessionId,
      },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'tools/list'
      })
    });

    assert.strictEqual(response.status, 404, 'Should return 404 Session Not Found');
    assert.deepStrictEqual(await response.json(), { error: 'Session not found' });
    console.log('  ✓ Expired session returned 404 so the client can re-initialize');

    await clientWithAuth.disconnect();
  });
});
});
