"""State tool handlers. Python port of the former TypeScript ``state-tools.ts``."""

from __future__ import annotations

import os

from .utils import (
    ensure_dir,
    error_response,
    get_workspace_root,
    json_dumps_compact,
    json_dumps_indent,
    js_or,
    js_string,
    make_text_result,
    now_iso,
    safe_json_parse,
    safe_read_file,
    safe_write_file,
    validate_mode,
)


def get_state_dir() -> str:
    return os.path.join(get_workspace_root(), ".omc", "state")


def get_state_path(mode: str) -> str:
    validate_mode(mode)
    return os.path.join(get_state_dir(), f"{mode}-state.json")


def omg_read_state(args: dict):
    mode = args.get("mode")
    try:
        state_path = get_state_path(mode)
        data = safe_read_file(state_path)
        if not data:
            return make_text_result(
                json_dumps_compact(
                    {"active": False, "mode": mode, "message": "No state found"}
                )
            )
        return make_text_result(data)
    except Exception as err:  # noqa: BLE001 - mirror TS catch-all
        return error_response(str(err))


def omg_write_state(args: dict):
    mode = args.get("mode")
    state = args.get("state")
    try:
        state_dir = get_state_dir()
        ensure_dir(state_dir)
        state_path = get_state_path(mode)

        existing: dict = {}
        existing_data = safe_read_file(state_path)
        if existing_data:
            existing_parsed = safe_json_parse(existing_data)
            if existing_parsed.ok:
                existing = existing_parsed.data
            # Corrupted or polluted state - overwrite

        parsed = safe_json_parse(state)
        if not parsed.ok:
            return error_response(parsed.error)

        new_state = dict(existing)
        new_state.update(parsed.data)
        new_state["updated_at"] = now_iso()
        safe_write_file(state_path, json_dumps_indent(new_state))

        return make_text_result(
            json_dumps_compact({"success": True, "mode": mode, "state": new_state})
        )
    except Exception as err:  # noqa: BLE001 - mirror TS catch-all
        return error_response(str(err))


def omg_clear_state(args: dict):
    mode = args.get("mode")
    try:
        state_dir = get_state_dir()
        if not os.path.exists(state_dir):
            return make_text_result(
                json_dumps_compact({"success": True, "message": "No state directory"})
            )

        if mode:
            state_path = get_state_path(mode)
            if os.path.exists(state_path):
                os.remove(state_path)
            return make_text_result(
                json_dumps_compact({"success": True, "cleared": mode})
            )

        files = [f for f in os.listdir(state_dir) if f.endswith("-state.json")]
        for file in files:
            os.remove(os.path.join(state_dir, file))
        return make_text_result(
            json_dumps_compact(
                {"success": True, "cleared": "all", "files": len(files)}
            )
        )
    except Exception as err:  # noqa: BLE001 - mirror TS catch-all
        return error_response(str(err))


def omg_list_active(args: dict):
    state_dir = get_state_dir()
    if not os.path.exists(state_dir):
        return make_text_result(json_dumps_compact({"active_modes": []}))

    files = [f for f in os.listdir(state_dir) if f.endswith("-state.json")]
    active_modes: list = []

    for file in files:
        try:
            raw = safe_read_file(os.path.join(state_dir, file))
            if not raw:
                continue
            parsed = safe_json_parse(raw)
            if not parsed.ok:
                continue
            data = parsed.data
            if data.get("active"):
                entry = {"mode": file[: -len("-state.json")]}
                phase_raw = js_or(js_or(data.get("current_phase"), data.get("phase")), "")
                phase = js_string(phase_raw)
                if phase:
                    entry["phase"] = phase
                if isinstance(data.get("updated_at"), str):
                    entry["updated_at"] = data["updated_at"]
                active_modes.append(entry)
        except Exception:  # noqa: BLE001 - skip corrupted files
            continue

    return make_text_result(json_dumps_compact({"active_modes": active_modes}))


def register_state_tools(registry: dict) -> None:
    registry.update(
        {
            "omg_read_state": omg_read_state,
            "omg_write_state": omg_write_state,
            "omg_clear_state": omg_clear_state,
            "omg_list_active": omg_list_active,
        }
    )
