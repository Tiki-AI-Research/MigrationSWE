"""Scan production modules for Node/TypeScript delegation patterns.

Ensures the migrated server does not shell out to, dynamically load, or
otherwise delegate to the original TypeScript sources or the Node runtime.
"""

import os
import re
import unittest

MCP_SERVER_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PACKAGE_DIR = os.path.join(MCP_SERVER_DIR, "omg_mcp")

FORBIDDEN_PATTERNS = [
    r"\bsubprocess\b",
    r"\bos\.system\b",
    r"\bos\.popen\b",
    r"\bctypes\b",
    r"\bimportlib\b",
    r"\brunpy\b",
    r"\bchild_process\b",
    r"\bnpx\b",
    r"\btsc\b",
    r"\bnode_modules\b",
    r"\bnode\b",
    r"\brequire\s*\(",
    r"\beval\s*\(",
]


class NoNodeScanTest(unittest.TestCase):
    def test_no_forbidden_delegation_patterns(self):
        compiled = [(p, re.compile(p, re.IGNORECASE)) for p in FORBIDDEN_PATTERNS]
        offenders = []
        for filename in sorted(os.listdir(PACKAGE_DIR)):
            if not filename.endswith(".py"):
                continue
            path = os.path.join(PACKAGE_DIR, filename)
            with open(path, "r", encoding="utf-8") as handle:
                for lineno, line in enumerate(handle, 1):
                    for pattern, regex in compiled:
                        if regex.search(line):
                            offenders.append(f"{filename}:{lineno}: {pattern} -> {line.strip()}")
        self.assertEqual(offenders, [], "forbidden patterns found:\n" + "\n".join(offenders))

    def test_no_javascript_artifacts_in_package(self):
        extensions = {".js", ".mjs", ".cjs", ".ts", ".tsx", ".node"}
        found = [
            f
            for f in os.listdir(PACKAGE_DIR)
            if os.path.splitext(f)[1] in extensions
        ]
        self.assertEqual(found, [])


if __name__ == "__main__":
    unittest.main()
