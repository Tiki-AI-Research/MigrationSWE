"""Process entrypoint for the OMG MCP stdio server."""

from __future__ import annotations

import sys

import anyio
from mcp.server.stdio import stdio_server

from .server import create_server


async def main() -> None:
    server = create_server()
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


def run() -> None:
    try:
        anyio.run(main)
    except Exception as error:  # noqa: BLE001 - mirror TS startup failure
        print(f"OMG MCP Server failed to start: {error}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    run()
