"""Python port of the original ``mcp-server/test/run-tests.mjs`` suite.

All behavioral assertions from the TypeScript runner are preserved
(mode validation, JSON safety, id generation, file safety, and ``.omc``
state paths); an explicit write-to-symlink refusal assertion is added.
Temporary files live in a unique temporary directory that is removed
after the run.
"""

import os
import shutil
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from omg_mcp.state_tools import get_state_path  # noqa: E402
from omg_mcp.utils import (  # noqa: E402
    generate_id,
    safe_json_parse,
    safe_read_file,
    safe_write_file,
    validate_mode,
)


class ValidateModeTest(unittest.TestCase):
    def test_accepts_valid_alphanumeric_mode_names(self):
        for name in ["omg-autopilot", "ralph", "ultra-work", "self_improve", "Mode123"]:
            validate_mode(name)

    def test_rejects_path_traversal_attempts(self):
        for name in ["../../etc", "../passwd", "foo/bar"]:
            with self.assertRaisesRegex(ValueError, "Invalid mode name"):
                validate_mode(name)

    def test_rejects_names_with_special_characters(self):
        for name in ["mode name", "mode;rm", ""]:
            with self.assertRaisesRegex(ValueError, "Invalid mode name"):
                validate_mode(name)

    def test_allows_dunder_proto(self):
        validate_mode("__proto__")


class SafeJsonParseTest(unittest.TestCase):
    def test_parses_valid_json_objects(self):
        result = safe_json_parse('{"a":1}')
        self.assertEqual(result.ok, True)
        self.assertEqual(result.data, {"a": 1})

    def test_strips_dunder_proto_key(self):
        result = safe_json_parse('{"__proto__":{"x":1},"safe":"yes"}')
        self.assertEqual(result.ok, True)
        self.assertEqual(result.data, {"safe": "yes"})
        self.assertFalse("__proto__" in result.data)

    def test_strips_constructor_and_prototype_keys(self):
        result = safe_json_parse('{"constructor":1,"prototype":2,"valid":"ok"}')
        self.assertEqual(result.ok, True)
        self.assertEqual(result.data, {"valid": "ok"})

    def test_returns_not_ok_for_invalid_json(self):
        self.assertEqual(safe_json_parse("invalid").ok, False)

    def test_returns_not_ok_for_json_arrays(self):
        self.assertEqual(safe_json_parse("[1,2,3]").ok, False)

    def test_returns_not_ok_for_json_primitives(self):
        self.assertEqual(safe_json_parse('"just a string"').ok, False)

    def test_returns_not_ok_for_null(self):
        self.assertEqual(safe_json_parse("null").ok, False)


class GenerateIdTest(unittest.TestCase):
    def test_returns_eight_character_string(self):
        value = generate_id()
        self.assertIsInstance(value, str)
        self.assertEqual(len(value), 8)

    def test_returns_unique_values(self):
        self.assertEqual(len({generate_id() for _ in range(20)}), 20)


class SafeFileTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp_dir = tempfile.mkdtemp(prefix="omg-test-")

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp_dir, ignore_errors=True)

    def test_returns_none_for_non_existent_file(self):
        self.assertIsNone(safe_read_file(os.path.join(self.tmp_dir, "nope.txt")))

    def test_roundtrips_write_then_read(self):
        file_path = os.path.join(self.tmp_dir, "test.json")
        content = '{"hello":"world"}'
        safe_write_file(file_path, content)
        self.assertEqual(safe_read_file(file_path), content)

    def test_returns_none_for_symlinks(self):
        real_file = os.path.join(self.tmp_dir, "real.txt")
        symlink = os.path.join(self.tmp_dir, "link.txt")
        with open(real_file, "w", encoding="utf-8") as handle:
            handle.write("data")
        os.symlink(real_file, symlink)
        self.assertIsNone(safe_read_file(symlink))

    def test_refuses_to_write_to_existing_symlink(self):
        real_file = os.path.join(self.tmp_dir, "real-w.txt")
        symlink = os.path.join(self.tmp_dir, "link-w.txt")
        with open(real_file, "w", encoding="utf-8") as handle:
            handle.write("data")
        os.symlink(real_file, symlink)
        with self.assertRaisesRegex(RuntimeError, "Refusing to write to symlink"):
            safe_write_file(symlink, "new")


class GetStatePathTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp_dir = tempfile.mkdtemp(prefix="omg-state-")
        cls.previous_root = os.environ.get("WORKSPACE_ROOT")
        os.environ["WORKSPACE_ROOT"] = cls.tmp_dir

    @classmethod
    def tearDownClass(cls):
        if cls.previous_root is None:
            os.environ.pop("WORKSPACE_ROOT", None)
        else:
            os.environ["WORKSPACE_ROOT"] = cls.previous_root
        shutil.rmtree(cls.tmp_dir, ignore_errors=True)

    def test_returns_path_ending_with_mode_state_json(self):
        result = get_state_path("omg-autopilot")
        self.assertTrue(result.endswith("omg-autopilot-state.json"))
        self.assertIn(".omc", result)

    def test_throws_for_invalid_mode_names(self):
        for name in ["../../etc", "foo bar", ""]:
            with self.assertRaisesRegex(ValueError, "Invalid mode name"):
                get_state_path(name)


if __name__ == "__main__":
    unittest.main()
