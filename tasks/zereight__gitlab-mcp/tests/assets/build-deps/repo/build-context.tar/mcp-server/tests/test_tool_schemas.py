"""Schema-parity tests against the transcribed TypeScript JSON Schema.

``EXPECTED_SCHEMAS`` was transcribed from the exact ``tools/list`` output of
the original TypeScript server (``@modelcontextprotocol/sdk`` 1.30.0 with
zod 4.3.6). Every tool's ``inputSchema`` must match exactly, including
required arrays, primitive types, descriptions, the ``category`` default,
and ``omg_write_state.state`` being typed as a string.
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from omg_mcp.server import INPUT_SCHEMAS, TOOL_ORDER  # noqa: E402

EXPECTED_SCHEMAS = {
    'omg_read_state': {'type': 'object', 'properties': {'mode': {'type': 'string', 'description': 'The mode to read state for (e.g., omg-autopilot, ralph, team)'}}, 'required': ['mode'], '$schema': 'http://json-schema.org/draft-07/schema#'},
    'omg_write_state': {'type': 'object', 'properties': {'mode': {'type': 'string', 'description': 'The mode to write state for'}, 'state': {'type': 'string', 'description': 'JSON string of state to write/merge'}}, 'required': ['mode', 'state'], '$schema': 'http://json-schema.org/draft-07/schema#'},
    'omg_clear_state': {'type': 'object', 'properties': {'mode': {'description': 'Mode to clear. Omit to clear all modes.', 'type': 'string'}}, '$schema': 'http://json-schema.org/draft-07/schema#'},
    'omg_list_active': {'type': 'object', 'properties': {}, '$schema': 'http://json-schema.org/draft-07/schema#'},
    'omg_read_prd': {'type': 'object', 'properties': {}, '$schema': 'http://json-schema.org/draft-07/schema#'},
    'omg_create_prd': {'type': 'object', 'properties': {'title': {'type': 'string', 'description': 'PRD title'}, 'description': {'description': 'PRD description', 'type': 'string'}, 'stories': {'description': 'User stories for the PRD', 'type': 'array', 'items': {'type': 'object', 'properties': {'id': {'description': 'Story ID (auto-generated if omitted)', 'type': 'string'}, 'title': {'type': 'string', 'description': 'Story title'}, 'description': {'description': 'Story description', 'type': 'string'}, 'acceptance_criteria': {'description': 'List of acceptance criteria', 'type': 'array', 'items': {'type': 'string'}}, 'priority': {'description': 'Priority (0 = default)', 'type': 'number'}}, 'required': ['title']}}}, 'required': ['title'], '$schema': 'http://json-schema.org/draft-07/schema#'},
    'omg_update_story': {'type': 'object', 'properties': {'story_id': {'type': 'string', 'description': 'The story ID to update'}, 'passes': {'type': 'boolean', 'description': 'Whether the story passes its acceptance criteria'}, 'evidence': {'description': 'Verification evidence (test output, etc.)', 'type': 'string'}}, 'required': ['story_id', 'passes'], '$schema': 'http://json-schema.org/draft-07/schema#'},
    'omg_verify_story': {'type': 'object', 'properties': {}, '$schema': 'http://json-schema.org/draft-07/schema#'},
    'omg_next_phase': {'type': 'object', 'properties': {'current_phase': {'type': 'number', 'description': 'Current phase number (0-5)'}, 'skip_reason': {'description': 'Reason for skipping to a non-sequential phase', 'type': 'string'}}, 'required': ['current_phase'], '$schema': 'http://json-schema.org/draft-07/schema#'},
    'omg_check_completion': {'type': 'object', 'properties': {'mode': {'description': 'Mode to check (omg-autopilot, ralph, team). Defaults to checking all active modes.', 'type': 'string'}}, '$schema': 'http://json-schema.org/draft-07/schema#'},
    'omg_get_phase_info': {'type': 'object', 'properties': {'phase': {'description': 'Specific phase number (0-5). Omit for all phases.', 'type': 'number'}}, '$schema': 'http://json-schema.org/draft-07/schema#'},
    'omg_read_memory': {'type': 'object', 'properties': {'category': {'description': 'Filter by category (e.g., project, user, feedback, reference)', 'type': 'string'}, 'key': {'description': 'Filter by specific key', 'type': 'string'}}, '$schema': 'http://json-schema.org/draft-07/schema#'},
    'omg_write_memory': {'type': 'object', 'properties': {'key': {'type': 'string', 'description': 'Unique key for this memory entry'}, 'value': {'type': 'string', 'description': 'The memory content'}, 'category': {'default': 'project', 'description': 'Category: project, user, feedback, reference', 'type': 'string'}}, 'required': ['key', 'value'], '$schema': 'http://json-schema.org/draft-07/schema#'},
    'omg_delete_memory': {'type': 'object', 'properties': {'key': {'type': 'string', 'description': 'Key of the memory entry to delete'}}, 'required': ['key'], '$schema': 'http://json-schema.org/draft-07/schema#'},
    'omg_select_model': {'type': 'object', 'properties': {'task': {'type': 'string', 'description': 'Description of the task to route'}, 'file_count': {'description': 'Number of files involved in the task', 'type': 'number'}, 'agent_type': {'description': 'The agent type that will execute (e.g., architect, executor)', 'type': 'string'}}, 'required': ['task'], '$schema': 'http://json-schema.org/draft-07/schema#'},
}


class ToolSchemaParityTest(unittest.TestCase):
    def test_tool_names_and_order(self):
        self.assertEqual(TOOL_ORDER, list(EXPECTED_SCHEMAS.keys()))

    def test_all_schemas_match_transcribed_expected(self):
        self.assertEqual(set(INPUT_SCHEMAS.keys()), set(EXPECTED_SCHEMAS.keys()))
        for name, expected in EXPECTED_SCHEMAS.items():
            self.assertEqual(INPUT_SCHEMAS[name], expected, f"schema mismatch for {name}")

    def test_write_state_is_typed_string(self):
        self.assertEqual(INPUT_SCHEMAS["omg_write_state"]["properties"]["state"]["type"], "string")

    def test_write_memory_category_default(self):
        category = INPUT_SCHEMAS["omg_write_memory"]["properties"]["category"]
        self.assertEqual(category["default"], "project")
        self.assertNotIn("category", INPUT_SCHEMAS["omg_write_memory"]["required"])


if __name__ == "__main__":
    unittest.main()
