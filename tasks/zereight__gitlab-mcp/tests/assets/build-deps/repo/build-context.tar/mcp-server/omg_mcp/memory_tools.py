"""Memory tool handlers. Python port of the former TypeScript ``memory-tools.ts``."""

from __future__ import annotations

import os

from .utils import (
    ensure_dir,
    error_response,
    get_workspace_root,
    json_dumps_compact,
    json_dumps_indent,
    make_text_result,
    now_iso,
    safe_json_parse,
    safe_read_file,
    safe_write_file,
)

MAX_ENTRIES = 500
MAX_VALUE_LENGTH = 10_000


def get_memory_path() -> str:
    return os.path.join(get_workspace_root(), ".omc", "project-memory.json")


def read_memory() -> dict:
    mem_path = get_memory_path()
    data = safe_read_file(mem_path)
    if not data:
        return {"entries": []}
    result = safe_json_parse(data)
    if not result.ok:
        return {"entries": []}
    return result.data


def write_memory(store: dict) -> None:
    mem_path = get_memory_path()
    ensure_dir(os.path.dirname(mem_path))
    safe_write_file(mem_path, json_dumps_indent(store))


def omg_read_memory(args: dict):
    category = args.get("category")
    key = args.get("key")

    store = read_memory()
    entries = list(store.get("entries") or [])

    if category:
        entries = [e for e in entries if e.get("category") == category]
    if key:
        entries = [e for e in entries if e.get("key") == key]

    return make_text_result(
        json_dumps_compact(
            {
                "total": len(entries),
                "entries": [
                    {
                        "key": e.get("key"),
                        "value": e.get("value"),
                        "category": e.get("category"),
                        "updated_at": e.get("updated_at"),
                    }
                    for e in entries
                ],
            }
        )
    )


def omg_write_memory(args: dict):
    key = args.get("key")
    value = args.get("value")
    category = args.get("category", "project")

    if isinstance(value, str) and len(value) > MAX_VALUE_LENGTH:
        return error_response(
            f"Value exceeds maximum length of {MAX_VALUE_LENGTH} characters"
        )

    store = read_memory()
    entries = list(store.get("entries") or [])
    existing = next((i for i, e in enumerate(entries) if e.get("key") == key), -1)
    now = now_iso()

    if existing < 0 and len(entries) >= MAX_ENTRIES:
        return error_response(f"Memory store full (max {MAX_ENTRIES} entries)")

    if existing >= 0:
        entries[existing]["value"] = value
        entries[existing]["category"] = category
        entries[existing]["updated_at"] = now
        action = "updated"
    else:
        entries.append(
            {
                "key": key,
                "value": value,
                "category": category,
                "created_at": now,
                "updated_at": now,
            }
        )
        action = "created"

    store["entries"] = entries
    write_memory(store)

    return make_text_result(
        json_dumps_compact({"success": True, "key": key, "action": action})
    )


def omg_delete_memory(args: dict):
    key = args.get("key")
    store = read_memory()
    entries = list(store.get("entries") or [])
    before = len(entries)
    filtered = [e for e in entries if e.get("key") != key]
    deleted = before - len(filtered) > 0
    if deleted:
        store["entries"] = filtered
        write_memory(store)

    return make_text_result(
        json_dumps_compact({"success": True, "deleted": deleted, "key": key})
    )


def register_memory_tools(registry: dict) -> None:
    registry.update(
        {
            "omg_read_memory": omg_read_memory,
            "omg_write_memory": omg_write_memory,
            "omg_delete_memory": omg_delete_memory,
        }
    )
