"""Workflow tool handlers. Python port of the former TypeScript ``workflow-tools.ts``."""

from __future__ import annotations

import os

from .state_tools import get_state_dir, get_state_path
from .utils import (
    error_response,
    js_or,
    json_dumps_compact,
    json_dumps_indent,
    make_text_result,
    now_iso,
    safe_json_parse,
    safe_read_file,
    safe_write_file,
)

AUTOPILOT_PHASES = [
    {"phase": 0, "name": "expansion", "description": "Requirements analysis and spec generation"},
    {"phase": 1, "name": "planning", "description": "Implementation plan creation"},
    {"phase": 2, "name": "execution", "description": "Code implementation"},
    {"phase": 3, "name": "qa", "description": "Build, lint, and test verification"},
    {"phase": 4, "name": "validation", "description": "Code review and security review"},
    {"phase": 5, "name": "cleanup", "description": "State cleanup and completion"},
]


def _is_number(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _as_phase_index(value):
    if not _is_number(value):
        return None
    if isinstance(value, float):
        if not value.is_integer():
            return None
        return int(value)
    return value


def omg_next_phase(args: dict):
    current_phase = args.get("current_phase")
    skip_reason = args.get("skip_reason")

    state_path = get_state_path("omg-autopilot")
    raw = safe_read_file(state_path)
    if not raw:
        return error_response("No omg-autopilot state found. Start with /omg-autopilot.")

    parsed = safe_json_parse(raw)
    if not parsed.ok:
        return error_response("Autopilot state file is corrupted. Clear and restart.")
    state = dict(parsed.data)

    persisted_phase = state.get("current_phase") if _is_number(state.get("current_phase")) else 0
    if current_phase != persisted_phase:
        return error_response(
            f"Phase mismatch: persisted state is at phase {persisted_phase}, caller claimed {current_phase}"
        )

    next_phase = persisted_phase + 1

    if next_phase > 5:
        state["active"] = False
        state["completed"] = True
        state["completed_at"] = now_iso()
        state["current_phase"] = 5
        safe_write_file(state_path, json_dumps_indent(state))

        return make_text_result(
            json_dumps_compact(
                {
                    "success": True,
                    "completed": True,
                    "message": "OMG Autopilot workflow complete.",
                }
            )
        )

    info = AUTOPILOT_PHASES[next_phase]
    state["current_phase"] = next_phase
    state["phase_name"] = info["name"]
    state["phase_started_at"] = now_iso()
    state["updated_at"] = now_iso()
    if skip_reason:
        state["skip_reason"] = skip_reason

    safe_write_file(state_path, json_dumps_indent(state))

    return make_text_result(
        json_dumps_compact(
            {
                "success": True,
                "phase": next_phase,
                "name": info["name"],
                "description": info["description"],
            }
        )
    )


def omg_check_completion(args: dict):
    mode = args.get("mode")
    state_dir = get_state_dir()
    if not os.path.exists(state_dir):
        return make_text_result(
            json_dumps_compact(
                {"allow_stop": True, "remaining": [], "message": "No active state"}
            )
        )

    remaining: list = []

    def check_mode(m: str) -> None:
        try:
            state_path = get_state_path(m)
            raw = safe_read_file(state_path)
            if not raw:
                return
            parsed = safe_json_parse(raw)
            if not parsed.ok:
                return
            data = parsed.data
            if not data.get("active"):
                return

            if m == "omg-autopilot":
                phase = data.get("current_phase") if _is_number(data.get("current_phase")) else 0
                if phase < 5:
                    name = AUTOPILOT_PHASES[phase]["name"] if 0 <= phase < len(AUTOPILOT_PHASES) else None
                    remaining.append(f"omg-autopilot: phase {phase}/5 ({name})")
            elif m == "ralph":
                remaining.append("ralph: persistence loop active")
            elif m == "team":
                remaining.append(f"team: {_js_str(js_or(data.get('current_phase'), 'active'))}")
            elif m == "ultraqa":
                remaining.append(f"ultraqa: cycle {_js_str(js_or(data.get('current_cycle'), '?'))}/5")
            else:
                remaining.append(f"{m}: active")
        except Exception:  # noqa: BLE001 - skip corrupted
            return

    if mode:
        check_mode(mode)
    else:
        files = [f for f in os.listdir(state_dir) if f.endswith("-state.json")]
        for file in files:
            check_mode(file[: -len("-state.json")])

    if not remaining:
        message = "All tasks complete. Safe to stop."
    else:
        message = f"{len(remaining)} active workflow(s). Continue working."

    return make_text_result(
        json_dumps_compact(
            {"allow_stop": not remaining, "remaining": remaining, "message": message}
        )
    )


def _js_str(value) -> str:
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, str):
        return value
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value)


def omg_get_phase_info(args: dict):
    phase = args.get("phase")

    if phase is not None:
        index = _as_phase_index(phase)
        info = AUTOPILOT_PHASES[index] if index is not None and 0 <= index < len(AUTOPILOT_PHASES) else None
        if info is None:
            return make_text_result(
                json_dumps_compact({"error": f"Invalid phase: {phase}. Valid: 0-5."})
            )
        return make_text_result(json_dumps_compact(info))

    return make_text_result(json_dumps_compact({"phases": AUTOPILOT_PHASES}))


def register_workflow_tools(registry: dict) -> None:
    registry.update(
        {
            "omg_next_phase": omg_next_phase,
            "omg_check_completion": omg_check_completion,
            "omg_get_phase_info": omg_get_phase_info,
        }
    )
