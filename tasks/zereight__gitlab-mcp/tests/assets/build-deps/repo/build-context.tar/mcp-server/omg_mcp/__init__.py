"""OMG MCP server package.

A Python reimplementation of the ``omg-mcp-server`` Model Context Protocol
server (``omg-workflow`` version ``1.0.0``) that runs over stdio.
"""

from .server import INPUT_SCHEMAS, TOOL_DESCRIPTIONS, TOOL_ORDER, create_server, register_all

__all__ = [
    "create_server",
    "register_all",
    "INPUT_SCHEMAS",
    "TOOL_DESCRIPTIONS",
    "TOOL_ORDER",
]
