"""Contract tests for the MCP text-JSON result envelopes.

Asserts that successful tool results keep the MCP envelope
``{content:[{type:"text",text:<JSON string>}]}`` and that tool-layer
failures keep ``{"success":false,"error":<message>}``. Also asserts the
``omg_read_prd`` pretty-print (indent 2) exception versus compact output
for every other tool result.
"""

import json
import os
import shutil
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from omg_mcp.prd_tools import omg_create_prd, omg_read_prd  # noqa: E402
from omg_mcp.state_tools import omg_list_active, omg_read_state  # noqa: E402


class EnvelopeTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp_dir = tempfile.mkdtemp(prefix="omg-contract-")
        cls.previous_root = os.environ.get("WORKSPACE_ROOT")
        os.environ["WORKSPACE_ROOT"] = cls.tmp_dir

    @classmethod
    def tearDownClass(cls):
        if cls.previous_root is None:
            os.environ.pop("WORKSPACE_ROOT", None)
        else:
            os.environ["WORKSPACE_ROOT"] = cls.previous_root
        shutil.rmtree(cls.tmp_dir, ignore_errors=True)

    def test_success_result_is_single_text_block_of_valid_json(self):
        result = omg_list_active({})
        self.assertEqual(len(result.content), 1)
        block = result.content[0]
        self.assertEqual(block.type, "text")
        parsed = json.loads(block.text)
        self.assertEqual(parsed, {"active_modes": []})

    def test_tool_layer_failure_uses_error_envelope(self):
        result = omg_read_state({"mode": "../../etc"})
        self.assertEqual(len(result.content), 1)
        block = result.content[0]
        self.assertEqual(block.type, "text")
        parsed = json.loads(block.text)
        self.assertEqual(parsed["success"], False)
        self.assertIn("Invalid mode name", parsed["error"])

    def test_error_envelope_for_invalid_state_json(self):
        from omg_mcp.state_tools import omg_write_state

        result = omg_write_state({"mode": "ralph", "state": "not json"})
        parsed = json.loads(result.content[0].text)
        self.assertEqual(parsed, {"success": False, "error": "Invalid JSON"})


class ReadPrdSerializationTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp_dir = tempfile.mkdtemp(prefix="omg-contract-prd-")
        cls.previous_root = os.environ.get("WORKSPACE_ROOT")
        os.environ["WORKSPACE_ROOT"] = cls.tmp_dir

    @classmethod
    def tearDownClass(cls):
        if cls.previous_root is None:
            os.environ.pop("WORKSPACE_ROOT", None)
        else:
            os.environ["WORKSPACE_ROOT"] = cls.previous_root
        shutil.rmtree(cls.tmp_dir, ignore_errors=True)

    def test_read_prd_text_is_indent_two(self):
        omg_create_prd(
            {
                "title": "Demo",
                "stories": [
                    {
                        "title": "Story A",
                        "acceptance_criteria": ["one", "two"],
                        "priority": 2,
                    }
                ],
            }
        )
        result = omg_read_prd({})
        text = result.content[0].text
        parsed = json.loads(text)
        self.assertEqual(text, json.dumps(parsed, indent=2, ensure_ascii=False))
        self.assertIn("\n", text)

    def test_other_results_are_compact(self):
        omg_create_prd({"title": "Compact"})
        text = omg_list_active({}).content[0].text
        self.assertNotIn("\n", text)


if __name__ == "__main__":
    unittest.main()
