"""Model recommendation router. Python port of the former ``model-router.ts``."""

from __future__ import annotations

from .utils import json_dumps_compact, make_text_result

COMPLEXITY_THRESHOLDS = {
    "high": {
        "file_count": 10,
        "description_length": 500,
        "keywords": [
            "architect",
            "design",
            "refactor",
            "migrate",
            "security",
            "performance",
            "optimize",
            "complex",
            "critical",
            "system",
        ],
    },
    "medium": {
        "file_count": 5,
        "description_length": 200,
        "keywords": [
            "implement",
            "add",
            "update",
            "feature",
            "component",
            "module",
            "service",
            "test",
            "debug",
        ],
    },
}


def assess_complexity(task: str, file_count=None) -> dict:
    score = 0
    factors: list = []
    task_lower = task.lower()

    for kw in COMPLEXITY_THRESHOLDS["high"]["keywords"]:
        if kw in task_lower:
            score += 3
            factors.append(f'high-complexity keyword: "{kw}"')

    for kw in COMPLEXITY_THRESHOLDS["medium"]["keywords"]:
        if kw in task_lower:
            score += 1
            factors.append(f'medium-complexity keyword: "{kw}"')

    if file_count is not None:
        if file_count >= COMPLEXITY_THRESHOLDS["high"]["file_count"]:
            score += 5
            factors.append(f"high file count: {file_count}")
        elif file_count >= COMPLEXITY_THRESHOLDS["medium"]["file_count"]:
            score += 2
            factors.append(f"moderate file count: {file_count}")

    if len(task) >= COMPLEXITY_THRESHOLDS["high"]["description_length"]:
        score += 2
        factors.append("long task description")

    tier = "high" if score >= 8 else "medium" if score >= 3 else "low"
    return {"tier": tier, "score": score, "factors": factors}


def recommend(tier: str) -> dict:
    if tier == "high":
        return {
            "recommended_model": "claude-sonnet-4.6",
            "tier": "HIGH",
            "reason": "Complex task requiring deep reasoning and architecture decisions",
            "alternatives": ["gpt-4.1"],
        }
    if tier == "medium":
        return {
            "recommended_model": "gpt-4.1",
            "tier": "MEDIUM",
            "reason": "Standard implementation task with moderate complexity",
            "alternatives": ["claude-sonnet-4.6"],
        }
    return {
        "recommended_model": "gpt-4.1-mini",
        "tier": "LOW",
        "reason": "Simple task suitable for fast, lightweight model",
        "alternatives": ["gpt-4.1"],
    }


def omg_select_model(args: dict):
    task = args.get("task")
    file_count = args.get("file_count")
    agent_type = args.get("agent_type")

    complexity = assess_complexity(task, file_count)

    high_tier_agents = ["architect", "critic", "analyst", "planner"]
    low_tier_agents = ["writer", "git-master", "code-simplifier", "explore"]

    if agent_type and agent_type in high_tier_agents:
        recommendation = recommend("high")
        recommendation["reason"] = (
            f'Agent type "{agent_type}" requires high-tier model for quality reasoning'
        )
    elif agent_type and agent_type in low_tier_agents:
        recommendation = recommend("low")
        recommendation["reason"] = (
            f'Agent type "{agent_type}" works well with lightweight model'
        )
    else:
        recommendation = recommend(complexity["tier"])

    result = dict(recommendation)
    result["complexity"] = {
        "tier": complexity["tier"],
        "score": complexity["score"],
        "factors": complexity["factors"],
    }

    return make_text_result(json_dumps_compact(result))


def register_model_router(registry: dict) -> None:
    registry.update({"omg_select_model": omg_select_model})
