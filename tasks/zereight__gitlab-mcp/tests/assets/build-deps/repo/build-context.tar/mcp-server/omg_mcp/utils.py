"""Shared safety, path, JSON, and result helpers.

Python port of the former TypeScript ``utils.ts`` module. Behavior, messages,
and JSON serialization are preserved for parity with the original server.
"""

from __future__ import annotations

import json
import os
import re
import stat as stat_module
import uuid
from datetime import datetime, timezone
from typing import Any, NamedTuple, Optional

from mcp import types

MAX_FILE_SIZE = 5 * 1024 * 1024  # 5 MiB

_MODE_RE = re.compile(r"^[a-zA-Z0-9_-]+$")

_UNSAFE_KEYS = ("__proto__", "constructor", "prototype")


class JsonParseResult(NamedTuple):
    ok: bool
    data: Optional[dict] = None
    error: Optional[str] = None


def get_workspace_root() -> str:
    return os.path.abspath(os.environ.get("WORKSPACE_ROOT") or os.getcwd())


def ensure_dir(directory: str) -> None:
    os.makedirs(directory, exist_ok=True)


def validate_mode(mode: Any) -> None:
    if not isinstance(mode, str) or _MODE_RE.fullmatch(mode) is None:
        raise ValueError(
            f'Invalid mode name: "{mode}". Only alphanumeric, hyphens, and underscores allowed.'
        )


def safe_read_file(file_path: str) -> Optional[str]:
    try:
        st = os.lstat(file_path)
        if stat_module.S_ISLNK(st.st_mode):
            return None
        if st.st_size > MAX_FILE_SIZE:
            return None
        with open(file_path, "r", encoding="utf-8", errors="replace") as handle:
            return handle.read()
    except Exception:
        return None


def safe_write_file(file_path: str, data: str) -> None:
    try:
        st = os.lstat(file_path)
        if stat_module.S_ISLNK(st.st_mode):
            raise RuntimeError("Refusing to write to symlink")
    except FileNotFoundError:
        pass
    with open(file_path, "w", encoding="utf-8") as handle:
        handle.write(data)


def safe_json_parse(input_str: str) -> JsonParseResult:
    try:
        parsed = json.loads(input_str)
    except Exception:
        return JsonParseResult(False, error="Invalid JSON")
    if not isinstance(parsed, dict):
        return JsonParseResult(False, error="Expected a JSON object")
    clean: dict = {}
    for key, value in parsed.items():
        if key in _UNSAFE_KEYS:
            continue
        clean[key] = value
    return JsonParseResult(True, data=clean, error=None)


def generate_id() -> str:
    return str(uuid.uuid4())[:8]


def now_iso() -> str:
    dt = datetime.now(timezone.utc)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond // 1000:03d}Z"


def js_truthy(value: Any) -> bool:
    if value is None or value is False:
        return False
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return value != 0
    if isinstance(value, str):
        return len(value) > 0
    return True


def js_or(a: Any, b: Any) -> Any:
    return a if js_truthy(a) else b


def js_string(value: Any) -> str:
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, str):
        return value
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, list):
        return ",".join(js_string(v) for v in value)
    return str(value)


def json_dumps_compact(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False)


def json_dumps_indent(value: Any) -> str:
    return json.dumps(value, indent=2, ensure_ascii=False)


def make_text_result(text: str) -> types.CallToolResult:
    return types.CallToolResult(content=[types.TextContent(type="text", text=text)])


def error_response(message: str) -> types.CallToolResult:
    return make_text_result(json_dumps_compact({"success": False, "error": message}))
