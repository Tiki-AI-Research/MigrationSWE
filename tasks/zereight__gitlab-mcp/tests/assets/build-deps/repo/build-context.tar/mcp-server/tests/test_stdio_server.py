"""Probe the server over stdio via JSON-RPC.

Starts ``python -m omg_mcp``, exercises ``initialize`` and ``tools/list``,
and asserts the ``omg-workflow`` 1.0.0 identity and the presence of exactly
15 tools. Also asserts the fatal-startup message and exit code 1.
"""

import json
import os
import select
import shutil
import subprocess
import sys
import tempfile
import time
import unittest

MCP_SERVER_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _server_env(extra=None):
    env = dict(os.environ)
    env["PYTHONPATH"] = MCP_SERVER_DIR + os.pathsep + env.get("PYTHONPATH", "")
    env["WORKSPACE_ROOT"] = tempfile.mkdtemp(prefix="omg-stdio-")
    if extra:
        env.update(extra)
    return env


def _send(proc, message):
    proc.stdin.write(json.dumps(message) + "\n")
    proc.stdin.flush()


def _read_until(proc, predicate, timeout=30.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        ready, _, _ = select.select([proc.stdout], [], [], max(0.0, deadline - time.time()))
        if not ready:
            break
        line = proc.stdout.readline()
        if not line:
            break
        line = line.strip()
        if not line:
            continue
        try:
            message = json.loads(line)
        except ValueError:
            continue
        if predicate(message):
            return message
    raise AssertionError("timed out waiting for a matching server message")


class _StdioServerMixin:
    proc = None
    env = None

    @classmethod
    def setUpClass(cls):
        cls.env = _server_env()
        cls.proc = subprocess.Popen(
            [sys.executable, "-m", "omg_mcp"],
            cwd=MCP_SERVER_DIR,
            env=cls.env,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )

    @classmethod
    def tearDownClass(cls):
        if cls.proc is not None:
            try:
                cls.proc.stdin.close()
            except Exception:
                pass
            try:
                cls.proc.terminate()
                cls.proc.wait(timeout=10)
            except Exception:
                cls.proc.kill()
        if cls.env is not None:
            shutil.rmtree(cls.env.get("WORKSPACE_ROOT", ""), ignore_errors=True)

    def _initialize(self):
        _send(
            self.proc,
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "test", "version": "1.0.0"},
                },
            },
        )
        response = _read_until(self.proc, lambda m: m.get("id") == 1)
        _send(self.proc, {"jsonrpc": "2.0", "method": "notifications/initialized"})
        return response

    def _list_tools(self):
        _send(self.proc, {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}})
        return _read_until(self.proc, lambda m: m.get("id") == 2)


class StdioIdentityTest(_StdioServerMixin, unittest.TestCase):
    def test_reports_omg_workflow_identity(self):
        response = self._initialize()
        server_info = response["result"]["serverInfo"]
        self.assertEqual(server_info["name"], "omg-workflow")
        self.assertEqual(server_info["version"], "1.0.0")


class ToolsListTest(_StdioServerMixin, unittest.TestCase):
    def test_lists_exactly_fifteen_tools(self):
        self._initialize()
        response = self._list_tools()
        tools = response["result"]["tools"]
        self.assertEqual(len(tools), 15)
        self.assertEqual(
            [t["name"] for t in tools],
            [
                "omg_read_state",
                "omg_write_state",
                "omg_clear_state",
                "omg_list_active",
                "omg_read_prd",
                "omg_create_prd",
                "omg_update_story",
                "omg_verify_story",
                "omg_next_phase",
                "omg_check_completion",
                "omg_get_phase_info",
                "omg_read_memory",
                "omg_write_memory",
                "omg_delete_memory",
                "omg_select_model",
            ],
        )


class StartupFailureTest(unittest.TestCase):
    def test_prints_failure_message_and_exits_one(self):
        code = (
            "import omg_mcp.__main__ as m\n"
            "m.create_server = lambda: (_ for _ in ()).throw(RuntimeError('boom'))\n"
            "m.run()\n"
        )
        env = _server_env()
        try:
            result = subprocess.run(
                [sys.executable, "-c", code],
                cwd=MCP_SERVER_DIR,
                env=env,
                capture_output=True,
                text=True,
                timeout=30,
            )
        finally:
            shutil.rmtree(env.get("WORKSPACE_ROOT", ""), ignore_errors=True)
        self.assertEqual(result.returncode, 1)
        self.assertIn("OMG MCP Server failed to start: boom", result.stderr)


if __name__ == "__main__":
    unittest.main()
