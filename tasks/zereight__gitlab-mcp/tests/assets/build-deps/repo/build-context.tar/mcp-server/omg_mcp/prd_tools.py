"""PRD tool handlers. Python port of the former TypeScript ``prd-tools.ts``."""

from __future__ import annotations

import os
from typing import Optional

from .utils import (
    ensure_dir,
    generate_id,
    get_workspace_root,
    json_dumps_compact,
    json_dumps_indent,
    make_text_result,
    now_iso,
    safe_json_parse,
    safe_read_file,
    safe_write_file,
)


def get_prd_path() -> str:
    return os.path.join(get_workspace_root(), ".omc", "prd.json")


def read_prd() -> Optional[dict]:
    prd_path = get_prd_path()
    data = safe_read_file(prd_path)
    if not data:
        return None
    result = safe_json_parse(data)
    if not result.ok:
        return None
    return result.data


def write_prd(prd: dict) -> None:
    prd_path = get_prd_path()
    ensure_dir(os.path.dirname(prd_path))
    prd["updated_at"] = now_iso()
    safe_write_file(prd_path, json_dumps_indent(prd))


def omg_read_prd(args: dict):
    prd = read_prd()
    if not prd:
        return make_text_result(
            json_dumps_compact(
                {
                    "exists": False,
                    "message": "No PRD found. Create one with ralph or omg-autopilot.",
                }
            )
        )

    stories = prd.get("stories") or []
    summary = {
        "title": prd.get("title"),
        "total_stories": len(stories),
        "passing": sum(1 for s in stories if s.get("passes")),
        "failing": sum(1 for s in stories if not s.get("passes")),
        "stories": [
            {
                "id": s.get("id"),
                "title": s.get("title"),
                "passes": s.get("passes"),
                "priority": s.get("priority"),
                "criteria_count": len(s.get("acceptance_criteria") or []),
            }
            for s in stories
        ],
    }

    return make_text_result(json_dumps_indent(summary))


def omg_create_prd(args: dict):
    title = args.get("title")
    description = args.get("description")
    if description is None:
        description = ""
    input_stories = args.get("stories")
    if input_stories is None:
        input_stories = []

    stories = []
    for story in input_stories:
        stories.append(
            {
                "id": story.get("id") or f"story-{generate_id()}",
                "title": story.get("title"),
                "description": story.get("description")
                if story.get("description") is not None
                else "",
                "acceptance_criteria": story.get("acceptance_criteria")
                if story.get("acceptance_criteria") is not None
                else [],
                "passes": False,
                "priority": story.get("priority")
                if story.get("priority") is not None
                else 0,
            }
        )

    prd = {
        "title": title,
        "description": description,
        "stories": stories,
        "created_at": now_iso(),
        "updated_at": now_iso(),
    }

    write_prd(prd)

    return make_text_result(
        json_dumps_compact(
            {
                "success": True,
                "title": prd["title"],
                "stories_created": len(prd["stories"]),
            }
        )
    )


def omg_update_story(args: dict):
    story_id = args.get("story_id")
    passes = args.get("passes")
    evidence = args.get("evidence")

    prd = read_prd()
    if not prd:
        return make_text_result(
            json_dumps_compact({"success": False, "error": "No PRD found"})
        )

    stories = prd.get("stories") or []
    story = next((s for s in stories if s.get("id") == story_id), None)
    if story is None:
        return make_text_result(
            json_dumps_compact(
                {"success": False, "error": f"Story {story_id} not found"}
            )
        )

    story["passes"] = passes
    if evidence:
        story["verification_evidence"] = evidence
    write_prd(prd)

    return make_text_result(
        json_dumps_compact(
            {
                "success": True,
                "story_id": story_id,
                "passes": passes,
                "total_passing": sum(1 for s in stories if s.get("passes")),
                "total_stories": len(stories),
            }
        )
    )


def omg_verify_story(args: dict):
    prd = read_prd()
    if not prd:
        return make_text_result(
            json_dumps_compact({"exists": False, "message": "No PRD found"})
        )

    stories = prd.get("stories") or []
    pending = [s for s in stories if not s.get("passes")]
    pending.sort(key=_priority_key, reverse=True)

    if not pending:
        return make_text_result(
            json_dumps_compact(
                {
                    "all_passing": True,
                    "message": "All stories pass. PRD is complete.",
                    "total_stories": len(stories),
                }
            )
        )

    nxt = pending[0]
    return make_text_result(
        json_dumps_compact(
            {
                "story": {
                    "id": nxt.get("id"),
                    "title": nxt.get("title"),
                    "description": nxt.get("description"),
                    "acceptance_criteria": nxt.get("acceptance_criteria"),
                    "priority": nxt.get("priority"),
                },
                "remaining": len(pending),
                "total": len(stories),
            }
        )
    )


def _priority_key(story: dict):
    priority = story.get("priority")
    if isinstance(priority, (int, float)) and not isinstance(priority, bool):
        return priority
    return 0


def register_prd_tools(registry: dict) -> None:
    registry.update(
        {
            "omg_read_prd": omg_read_prd,
            "omg_create_prd": omg_create_prd,
            "omg_update_story": omg_update_story,
            "omg_verify_story": omg_verify_story,
        }
    )
